<?php
class Article_model extends CI_Model{

}