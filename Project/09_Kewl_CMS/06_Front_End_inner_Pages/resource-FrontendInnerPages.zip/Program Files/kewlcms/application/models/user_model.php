<?php
class User_model extends CI_Model{

}