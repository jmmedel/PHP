<?php
class Authenticate_model extends CI_Model{

}