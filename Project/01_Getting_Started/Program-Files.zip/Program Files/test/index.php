<?php
	//$users = array('First Name' => 'Brad','Last Name' => 'Traversy','Email' => 'techguyinfo@gmail.com');
	//$fruits = array('Apple','Orange','Grapes');
	
	function sayIt($words){
		echo $words;
	}
	
	sayIt('Hello Again');
	
?>
	
