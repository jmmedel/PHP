<?php
define('DB_HOST','localhost');
define('DB_USER','root');
define('DB_PASS','121212aa');
define('DB_NAME','blog');