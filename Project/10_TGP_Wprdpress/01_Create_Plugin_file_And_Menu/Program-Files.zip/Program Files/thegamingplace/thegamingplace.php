<?php
	/*
	Plugin Name: The Gaming Place
	Description: A bridge plugin for TheGamingPlace store products
	Author: Brad Traversy
	Version: 1.0
	*/

//Add Settings Menu Item
function tgp_admin_actions(){
	add_options_page("TGP Product Display","TGP Product Display",1, "TGP_Product_Display","tgp_admin");
}	

add_action('admin_menu', 'tgp_admin_actions');

function tgp_admin(){
	echo 'This is the menu item';
}