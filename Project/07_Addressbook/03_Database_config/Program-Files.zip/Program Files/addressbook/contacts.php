<div class="row">
		<div class="large-12 columns">
			<table>
				<thead>
					<tr>
						<th width="200">Name</th>
						<th width="130">Phone</th>
						<th width="200">Email</th>
						<th width="250">Address</th>
						<th width="100">Group</th>
						<th width="150">Actions</th>
					</tr>
				</thead>
				<tbody>
					<tr>
						<td><a href="contact.html">John Doe</a></td>
						<td>978 388-1234</td>
						<td>jdoe@gmail.com</td>
						<td>
						<ul>
							<li>55 Main Street</li>
							<li>Amesbury, MA 01913</li>
						</ul>
						</td>
						<td>Family</td>
						<td>
							<ul class="button-group">
								<li><a href="#" class="button tiny">Edit</a></li>
								<li><a href="#" class="button tiny alert">Delete</a></li>
							</ul>
						</td>
					</tr>
					<tr>
						<td><a href="contact.html">John Doe</a></td>
						<td>978 388-1234</td>
						<td>jdoe@gmail.com</td>
						<td>
						<ul>
							<li>55 Main Street</li>
							<li>Amesbury, MA 01913</li>
						</ul>
						</td>
						<td>Family</td>
						<td>
							<ul class="button-group">
								<li><a href="#" class="button tiny">Edit</a></li>
								<li><a href="#" class="button tiny alert">Delete</a></li>
							</ul>
						</td>
					</tr>
					<tr>
						<td><a href="contact.html">John Doe</a></td>
						<td>978 388-1234</td>
						<td>jdoe@gmail.com</td>
						<td>
						<ul>
							<li>55 Main Street</li>
							<li>Amesbury, MA 01913</li>
						</ul>
						</td>
						<td>Family</td>
						<td>
							<ul class="button-group">
								<li><a href="#" class="button tiny">Edit</a></li>
								<li><a href="#" class="button tiny alert">Delete</a></li>
							</ul>
						</td>
					</tr>
				</tbody>
			</table>
		</div>
	</div>