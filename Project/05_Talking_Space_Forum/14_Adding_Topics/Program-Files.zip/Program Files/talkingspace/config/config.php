<?php
//DB Params
define("DB_HOST", "localhost");
define("DB_USER", "root");
define("DB_PASS", "121212aa");
define("DB_NAME", "talkingspace");

define("SITE_TITLE", "Welcome To TalkingSpace!");

//Paths
define ('BASE_URI', 'http://'.$_SERVER['SERVER_NAME'].'/talkingspace/');