<?php require('core/init.php'); ?>

<?php
//Get Template & Assign Vars
$template = new Template('templates/create.php');

//Assign Vars

//Display template
echo $template;