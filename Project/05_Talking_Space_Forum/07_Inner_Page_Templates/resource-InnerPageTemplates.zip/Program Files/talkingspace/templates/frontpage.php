<?php include('includes/header.php'); ?>		
		<ul id="topics">
							<li class="topic">
							<div class="row">
							<div class="col-md-2">
								<img class="avatar pull-left" src="img/gravatar.jpg" />
							</div>
							<div class="col-md-10">
								<div class="topic-content pull-right">
									<h3><a href="topic.html">How did you learn CSS and HTML?</a></h3>
									<div class="topic-info">
										<a href="category.html">Development</a> >> <a href="profile.html">BradT81</a> >> Posted on: June 12, 2014 
										<span class="badge pull-right">3</span>
									</div>
								</div>
							</div>
						</div>
					</li>
					<li class="topic">
						<div class="row">
							<div class="col-md-2">
								<img class="avatar pull-left" src="img/gravatar.jpg" />
							</div>
							<div class="col-md-10">
								<div class="topic-content pull-right">
									<h3><a href="topic.html">How to create new page dynamically in php</a> </h3>
									<div class="topic-info">
										<a href="category.html">Development</a> >> <a href="profile.html">BradT81</a> >> Posted on: June 12, 2014 
										<span class="badge pull-right">7</span>
									</div>
								</div>
							</div>
						</div>
					</li>
					<li class="topic">
						<div class="row">
							<div class="col-md-2">
								<img class="avatar pull-left" src="img/gravatar.jpg" />
							</div>
							<div class="col-md-10">
								<div class="topic-content pull-right">
									<h3><a href="topic.html">Google Panda - Who's affected?</a></h3>
									<div class="topic-info">
										<a href="category.html">Search Engines</a> >> <a href="profile.html">BradT81</a> >> Posted on: June 12, 2014 
										<span class="badge pull-right">4</span>
									</div>
								</div>
							</div>
						</div>
					</li>
					<li class="topic">
						<div class="row">
							<div class="col-md-2">
								<img class="avatar pull-left" src="img/gravatar.jpg" />
							</div>
							<div class="col-md-10">
								<div class="topic-content pull-right">
									<h3><a href="topic.html">Is Css3 is not working in IE8 and IE9?</a></h3>
									<div class="topic-info">
										<a href="category.html">Design</a> >> <a href="profile.html">BradT81</a> >> Posted on: June 12, 2014 
										<span class="badge pull-right">2</span>
									</div>
								</div>
							</div>
						</div>
					</li>
					<li class="topic">
						<div class="row">
							<div class="col-md-2">
								<img class="avatar pull-left" src="img/gravatar.jpg" />
							</div>
							<div class="col-md-10">
								<div class="topic-content pull-right">
									<h3><a href="topic.html">Best Web Application Frameworks</a></h3>
									<div class="topic-info">
										<a href="category.html">Development</a> >> <a href="profile.html">BradT81</a> >> Posted on: June 12, 2014 
										<span class="badge pull-right">4</span>
									</div>
								</div>
							</div>
						</div>
					</li>
						</ul>
						<h3>Forum Statistics</h3>
					<ul>
						<li>Total Number of Users: <strong>52</strong></li>
						<li>Total Number of Topics: <strong>10</strong></li>
						<li>Total Number of Categories: <strong>5</strong></li>
					</ul>
<?php include('includes/footer.php'); ?>	
