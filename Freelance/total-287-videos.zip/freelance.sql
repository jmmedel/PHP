-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 08, 2018 at 08:34 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `freelance`
--

-- --------------------------------------------------------

--
-- Table structure for table `buyer_reviews`
--

CREATE TABLE `buyer_reviews` (
  `review_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `review_buyer_id` int(10) NOT NULL,
  `buyer_rating` int(10) NOT NULL,
  `buyer_review` text NOT NULL,
  `review_seller_id` int(10) NOT NULL,
  `review_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buyer_reviews`
--

INSERT INTO `buyer_reviews` (`review_id`, `proposal_id`, `order_id`, `review_buyer_id`, `buyer_rating`, `buyer_review`, `review_seller_id`, `review_date`) VALUES
(1, 1, 1, 2, 5, 'Outstanding Work.', 1, 'January 2, 2018'),
(2, 2, 2, 3, 5, 'Great Work.', 2, 'December 30, 2017'),
(3, 2, 4, 4, 5, 'Outstanding Experience.', 2, 'December 28, 2017'),
(4, 4, 6, 1, 3, 'Great Job.', 3, 'December 21, 2017'),
(5, 2, 3, 6, 2, 'Extremely poor outcome. I would never use this supplier again.\r\n', 2, 'December 18, 2017'),
(6, 5, 9, 1, 5, 'Great Job.', 6, 'December 21, 2017'),
(7, 6, 10, 2, 5, 'Great Job.', 5, 'December 21, 2017'),
(8, 7, 11, 3, 5, 'Great Job.', 4, 'December 21, 2017'),
(9, 8, 12, 5, 5, 'Great Job.', 2, 'December 21, 2017'),
(10, 12, 14, 7, 5, 'Great Job.', 5, 'December 21, 2017');

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(10) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_desc` text NOT NULL,
  `cat_image` text NOT NULL,
  `cat_featured` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_desc`, `cat_image`, `cat_featured`) VALUES
(1, 'Graphics & Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'graphic-design.png', 'yes'),
(2, 'Digital Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'digital marketing.jpg', 'yes'),
(3, 'Writing & Translation', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'writting.jpg', 'yes'),
(4, 'Video & Animation\r\n', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'video-animation.jpg', 'yes'),
(5, 'Music & Audio', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'music-audio.jpg', 'yes'),
(6, 'Programming & Tech\r\n', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'program-tech.jpg', 'yes'),
(7, 'Business\r\n', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'business.jpg', 'yes'),
(8, 'Fun & Lifestyle\r\n', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'fun-life-style.jpg', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `categories_childs`
--

CREATE TABLE `categories_childs` (
  `child_id` int(10) NOT NULL,
  `child_parent_id` int(10) NOT NULL,
  `child_title` text NOT NULL,
  `child_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories_childs`
--

INSERT INTO `categories_childs` (`child_id`, `child_parent_id`, `child_title`, `child_desc`) VALUES
(1, 1, 'Logo Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(2, 1, 'Business Cards &amp; Stationery', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(3, 1, 'Illustration', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(4, 1, 'Cartoons Caricatures', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(5, 1, 'Flyers Posters', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(6, 1, 'Book Covers & Packaging', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(7, 1, 'Web &amp; Mobile Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(8, 1, 'Social Media Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(9, 1, 'Banner Ads', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(10, 2, 'Social Media Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(11, 6, 'WordPress', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(12, 1, 'Photoshop Editing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(13, 1, '3D & 2D Models', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(14, 1, 'T-Shirts', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(15, 1, 'Presentation Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(16, 1, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(17, 2, 'SEO', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(18, 2, 'Web Traffic', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(19, 2, 'Content Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(20, 2, 'Video Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(21, 2, 'Email Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(22, 2, 'Search & Display Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(23, 2, 'Marketing Strategy', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(24, 2, 'Web Analytics', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(25, 2, 'Influencer Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(26, 2, 'Local Listings', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(27, 2, 'Domain Research', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(28, 2, 'E-Commerce Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(29, 2, 'Mobile Advertising', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(30, 3, 'Resumes & Cover Letters', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(31, 3, 'Proofreading & Editing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(32, 3, 'Translation', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(33, 3, 'Creative Writing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(34, 3, 'Business Copywriting', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(35, 3, 'Research & Summaries', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(36, 3, 'Articles & Blog Posts', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(37, 3, 'Press Releases', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(38, 3, 'Transcription', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(39, 3, 'Legal Writing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(40, 3, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(41, 4, 'Whiteboard & Explainer Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(42, 4, 'Intros & Animated Logos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(43, 4, 'Promotional & Brand Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(44, 4, 'Editing & Post Production', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(45, 4, 'Lyric & Music Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(46, 4, 'Spokespersons & Testimonials', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(48, 4, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(49, 5, 'Voice Over', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(50, 5, 'Mixing & Mastering', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(51, 5, 'Producers & Composers', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(52, 5, 'Singer-Songwriters', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(53, 5, 'Session Musicians & Singers', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(54, 5, 'Jingles & Drops', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(55, 5, 'Sound Effects', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(56, 6, 'Web Programming', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(58, 6, 'Website Builders & CMS', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(60, 6, 'Ecommerce', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(61, 6, 'Mobile Apps & Web', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(62, 6, 'Desktop applications', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(63, 6, 'Support & IT', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(64, 6, 'Chatbots', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(65, 6, 'Data Analysis & Reports', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(66, 6, 'Convert Files', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(67, 6, 'Databases', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(68, 6, 'User Testing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(69, 6, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(70, 7, 'Virtual Assistant', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(71, 7, 'Market Research', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(72, 7, 'Business Plans', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(73, 7, 'Branding Services', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(74, 7, 'Legal Consulting', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(75, 7, 'Financial Consulting', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(76, 7, 'Business Tips', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(77, 7, 'Presentations', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(78, 7, 'Career Advice', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(79, 7, 'Flyer Distribution', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(80, 7, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(81, 8, 'Online Lessons', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(82, 8, 'Arts & Crafts', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(83, 8, 'Relationship Advice', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(84, 8, 'Health, Nutrition & Fitness', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(85, 8, 'Astrology & Readings', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(86, 8, 'Spiritual & Healing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(87, 8, 'Family & Genealogy', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(88, 8, 'Collectibles', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(89, 8, 'Greeting Cards & Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(91, 8, 'Viral Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(92, 8, 'Pranks & Stunts', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(93, 8, 'Celebrity Impersonators', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(94, 8, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.');

-- --------------------------------------------------------

--
-- Table structure for table `contact_support`
--

CREATE TABLE `contact_support` (
  `contact_id` int(10) NOT NULL,
  `contact_email` text NOT NULL,
  `contact_heading` text NOT NULL,
  `contact_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_support`
--

INSERT INTO `contact_support` (`contact_id`, `contact_email`, `contact_heading`, `contact_desc`) VALUES
(1, 'sad.ahmed22224@gmail.com', 'Submit A Request\r\n', 'If you have any questions, pease feel free to contact us, Our customer service center is working for you 24/7.');

-- --------------------------------------------------------

--
-- Table structure for table `delivery_times`
--

CREATE TABLE `delivery_times` (
  `delivery_id` int(10) NOT NULL,
  `delivery_title` text NOT NULL,
  `delivery_proposal_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_times`
--

INSERT INTO `delivery_times` (`delivery_id`, `delivery_title`, `delivery_proposal_title`) VALUES
(1, 'Up to 24 hours', '1 Day'),
(2, 'Up to 3 Days', ' 3 Days'),
(3, 'Up to 5 Days', '5 Days'),
(4, 'Up to 7 Days', '7 Days'),
(5, 'Any', 'Any Day');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_types`
--

CREATE TABLE `enquiry_types` (
  `enquiry_id` int(10) NOT NULL,
  `enquiry_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry_types`
--

INSERT INTO `enquiry_types` (`enquiry_id`, `enquiry_title`) VALUES
(1, 'Order Support '),
(2, 'Review Removal '),
(3, 'Account Support'),
(4, 'Report A Bug \r\n');

-- --------------------------------------------------------

--
-- Table structure for table `footer_links`
--

CREATE TABLE `footer_links` (
  `link_id` int(10) NOT NULL,
  `link_title` text NOT NULL,
  `link_url` text NOT NULL,
  `link_section` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `footer_links`
--

INSERT INTO `footer_links` (`link_id`, `link_title`, `link_url`, `link_section`) VALUES
(1, 'Graphics & Design', 'http://localhost/freelance/category.php?cat_id=1', 'categories'),
(2, 'Digital Marketing', 'http://localhost/freelance/category.php?cat_id=2', 'categories'),
(3, 'Writing & Translation\r\n', 'http://localhost/freelance/category.php?cat_id=3', 'categories'),
(4, 'Video & Animation\r\n', 'http://localhost/freelance/category.php?cat_id=4', 'categories'),
(5, 'Music & Audio\r\n', 'http://localhost/freelance/category.php?cat_id=5', 'categories'),
(6, 'Programming & Tech\r\n', 'http://localhost/freelance/category.php?cat_id=6', 'categories'),
(7, 'Business\r\n', 'http://localhost/freelance/category.php?cat_id=7', 'categories'),
(8, 'Fun & Lifestyle\r\n', 'http://localhost/freelance/category.php?cat_id=8', 'categories'),
(9, 'Terms And Conditions', 'http://localhost/freelance/terms.php', 'about'),
(10, 'Customer SUPPORT', 'http://localhost/freelance/contact.php', 'support'),
(11, '<i class=\"fa fa-google-plus-official\"></i> Google Plus', '#', 'follow'),
(12, '<i class=\"fa fa-twitter\"></i> Twitter', '#', 'follow'),
(13, '<i class=\"fa fa-facebook\"></i> Facebook', '#', 'follow'),
(14, '<i class=\"fa fa-linkedin\"></i> Linkedin', '#', 'follow'),
(15, '<i class=\"fa fa-pinterest\"></i> Pinterest', '#', 'follow');

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `id` int(10) NOT NULL,
  `site_title` text NOT NULL,
  `site_desc` text NOT NULL,
  `site_keywords` text NOT NULL,
  `site_author` text NOT NULL,
  `site_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`id`, `site_title`, `site_desc`, `site_keywords`, `site_author`, `site_url`) VALUES
(1, 'Computerfever - Freelance Services Marketplace', '\r\nComputerfever is the world\'s largest freelance services marketplace for lean entrepreneurs to focus on growth & create a successful business at affordable costs.\r\n', 'freelance,freelancers,jobs,proposals,sellers,buyers', 'Mohammed Tahir Ahmed', 'http://localhost/freelance');

-- --------------------------------------------------------

--
-- Table structure for table `home_section`
--

CREATE TABLE `home_section` (
  `section_id` int(10) NOT NULL,
  `section_title` text NOT NULL,
  `section_short_desc` text NOT NULL,
  `section_desc` text NOT NULL,
  `section_button` text NOT NULL,
  `section_button_url` text NOT NULL,
  `section_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home_section`
--

INSERT INTO `home_section` (`section_id`, `section_title`, `section_short_desc`, `section_desc`, `section_button`, `section_button_url`, `section_image`) VALUES
(1, 'We Have A Creative Platform', 'Optional title for call to action\r\n', 'Lorem ipsum dolor sit amet, consectetur adipisicing elit. Architecto quis quam, culpa deserunt hic et numquam eius accusamus expedita quidem sit voluptate! Questions?\r\n\r\nJoin Now', 'Contact Us', 'contact.php', 'platform-image.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `languages_relation`
--

CREATE TABLE `languages_relation` (
  `relation_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `language_id` int(11) NOT NULL,
  `language_level` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `languages_relation`
--

INSERT INTO `languages_relation` (`relation_id`, `seller_id`, `language_id`, `language_level`) VALUES
(1, 2, 1, 'Basic'),
(2, 2, 2, 'Conversational'),
(3, 2, 3, 'Fluent'),
(4, 2, 4, 'Native or Bilingual'),
(5, 1, 1, 'Conversational'),
(6, 1, 2, 'Basic'),
(7, 3, 1, 'Fluent'),
(8, 3, 2, 'Native or Bilingual'),
(9, 4, 1, 'Conversational'),
(10, 4, 1, 'Native or Bilingual'),
(11, 5, 2, 'Conversational'),
(12, 6, 1, 'Conversational'),
(13, 7, 2, 'Conversational'),
(14, 7, 1, 'Conversational'),
(15, 8, 1, 'Conversational');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `order_active` text NOT NULL,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `proposal_id`, `order_active`, `order_status`) VALUES
(1, 1, 'no', 'completed'),
(2, 2, 'no', 'completed'),
(3, 2, 'no', 'completed'),
(4, 2, 'no', 'completed'),
(6, 4, 'no', 'completed'),
(7, 2, 'yes', 'pending'),
(8, 2, 'yes', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `proposals`
--

CREATE TABLE `proposals` (
  `proposal_id` int(10) NOT NULL,
  `proposal_title` text NOT NULL,
  `proposal_url` text NOT NULL,
  `proposal_cat_id` int(10) NOT NULL,
  `proposal_child_id` int(10) NOT NULL,
  `proposal_price` int(10) NOT NULL,
  `proposal_img1` text NOT NULL,
  `proposal_img2` text NOT NULL,
  `proposal_img3` text NOT NULL,
  `proposal_img4` text NOT NULL,
  `proposal_video` text NOT NULL,
  `proposal_desc` text NOT NULL,
  `proposal_tags` text NOT NULL,
  `proposal_featured` text NOT NULL,
  `proposal_seller_id` int(10) NOT NULL,
  `delivery_id` int(10) NOT NULL,
  `level_id` int(10) NOT NULL,
  `language_id` int(10) NOT NULL,
  `proposal_rating` text NOT NULL,
  `proposal_views` int(10) NOT NULL,
  `proposal_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proposals`
--

INSERT INTO `proposals` (`proposal_id`, `proposal_title`, `proposal_url`, `proposal_cat_id`, `proposal_child_id`, `proposal_price`, `proposal_img1`, `proposal_img2`, `proposal_img3`, `proposal_img4`, `proposal_video`, `proposal_desc`, `proposal_tags`, `proposal_featured`, `proposal_seller_id`, `delivery_id`, `level_id`, `language_id`, `proposal_rating`, `proposal_views`, `proposal_status`) VALUES
(1, 'I Will Do Viral YouTube Seo Social Media Promotion ', 'i-will-do-viral-youtube-seo-social-media-promotion', 2, 20, 10, 'youtube-seo-1.jpg', 'youtube-seo-2.jpg', 'youtube-seo-3.jpg', 'youtube-seo-4.jpg', 'youtube-seo-video.mp4', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'youtube,seo,viral,promotion', 'yes', 1, 1, 2, 1, '5', 24, 'active'),
(2, 'I Will Do Web Development In Laravel And Codeigniter', 'i-will-do-web-development-in-laravel-and-codeignite', 6, 56, 10, 'web-development.jpg', 'web-development-2.png', '', '', 'web-development.mp4', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'web application,build website,codeigniter,php', 'yes', 2, 4, 2, 2, '4', 140, 'active'),
(3, 'I Will Design A Logo And Brand For You', 'i-will-design-a-logo-and-brand-for-you', 1, 1, 20, 'logo-1.jpg', 'logo-2.jpg', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'custom logo,typography,minimal,design', 'no', 3, 1, 2, 1, '5', 1, 'active'),
(4, '\r\nI Will Create A Professional Custom Explainer Video', 'i-will-create-a-professional-custom-explainer-video', 4, 41, 20, 'videosales-1.png', 'videosales-2.jpg', 'videosales-3.jpg', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'explainer video,whiteboard animation,sales video,Animated video,video marketing', 'no', 2, 1, 2, 1, '5', 12, 'active'),
(5, 'I Will Record Your Brazilian Portuguese Voice Over', 'i-will-record-your-brazilian-portuguese-voice-over', 5, 49, 10, 'voice-over-1.jpg', '', '', '', 'voiceover.mp4', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'audio,voice,voiceover,brazilian', 'yes', 6, 2, 1, 1, '5', 25, 'active'),
(6, 'I Will Design And Code Android Apps', 'i-will-design-and-code-android-apps', 6, 61, 20, 'andorid-1.jpg', 'andorid-2.jpg', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'android development,android app,', 'yes', 5, 5, 2, 1, '5', 8, 'active'),
(7, 'I Will Develop And Reskin 3d And 2d Games In Unity', 'i-will-develop-and-reskin-3d-and-2d-games-in-unit', 6, 56, 20, 'game-1.jpg', 'game-2.jpg', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'unity,android,ios,games,app', 'yes', 4, 4, 1, 1, '5', 8, 'active'),
(8, 'I Will Do Wordpress Customization And PHP Programming', 'i-will-do-wordpress-customization-and-php-programming', 6, 11, 20, 'wordpress-customization-1.jpg', '', '', '', 'wordpress-customization.mp4', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'wordpress blogs,complete wordpress,wordpress website,design wordpress', 'yes', 2, 1, 1, 1, '5', 11, 'active'),
(9, 'I will write custom php script,code for you', 'i-will-write-custom-php-script', 6, 56, 20, 'php-script.jpg', '', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'html,css,php,javascript,laravel', 'no', 8, 2, 2, 1, '0', 6, 'active'),
(10, 'I Will Create Or Modify Html Js Php Projects And More', 'modify-html-js-php-projects', 6, 56, 10, 'fixjshtml-1.jpg', '', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'html 5,css,php7,javascript,laravel', 'no', 8, 3, 3, 4, '0', 3, 'active'),
(11, 'I Will Fix PHP Errors Write Php Scripts And Web Application', 'fix-php-errors-write-php-scripts', 6, 56, 20, 'fix-php-errors-1.png', '', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'html,css,php,javascript,laravel', 'no', 6, 4, 4, 3, '0', 5, 'active'),
(12, 'I Will Setup Live Chat Customer Support On Your Website', 'i-will-setup-live-chat-customer-support-on-your-website', 6, 56, 20, 'livechat-1.png', 'livechat-2.jpg', 'livechat-3.jpg', 'livechat-4.jpg', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'live chat,chat software,customer service,livechat,chat', 'yes', 5, 2, 1, 3, '5', 16, 'active');

-- --------------------------------------------------------

--
-- Table structure for table `section_boxes`
--

CREATE TABLE `section_boxes` (
  `box_id` int(10) NOT NULL,
  `box_title` text NOT NULL,
  `box_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section_boxes`
--

INSERT INTO `section_boxes` (`box_id`, `box_title`, `box_desc`) VALUES
(1, 'Your Terms\r\n', 'Whatever you need to simplify your to do list, no matter your budget.\r\n'),
(2, 'Your Timeline\r\n', 'Whatever you need to simplify your to do list, no matter your budget.\r\n'),
(3, 'Your Safety\r\n', 'Your payment is always secure, Computerfever is built to protect your peace of mind.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `sellers`
--

CREATE TABLE `sellers` (
  `seller_id` int(10) NOT NULL,
  `seller_name` varchar(255) NOT NULL,
  `seller_user_name` varchar(255) NOT NULL,
  `seller_email` text NOT NULL,
  `seller_pass` text NOT NULL,
  `seller_image` text NOT NULL,
  `seller_country` text NOT NULL,
  `seller_headline` text NOT NULL,
  `seller_about` text NOT NULL,
  `seller_level` int(10) NOT NULL,
  `seller_recent_delivery` text NOT NULL,
  `seller_rating` int(10) NOT NULL,
  `seller_offers` int(10) NOT NULL,
  `seller_referral` int(10) NOT NULL,
  `seller_ip` varchar(255) NOT NULL,
  `seller_verification` text NOT NULL,
  `seller_vacation` text NOT NULL,
  `seller_register_date` text NOT NULL,
  `seller_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sellers`
--

INSERT INTO `sellers` (`seller_id`, `seller_name`, `seller_user_name`, `seller_email`, `seller_pass`, `seller_image`, `seller_country`, `seller_headline`, `seller_about`, `seller_level`, `seller_recent_delivery`, `seller_rating`, `seller_offers`, `seller_referral`, `seller_ip`, `seller_verification`, `seller_vacation`, `seller_register_date`, `seller_status`) VALUES
(1, 'Saad Ahmed', 'fixmywebsite', 'fixmywebsite@computerfever.com', '$2y$10$Hp3ht7PMsn6DNZXaWpC24eh/GL4PBct5vJQ9pqJEjtKXZVW4gpUgG', 'fixmywebsite.jpg', 'India', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 2, 'December 28, 2017', 93, 10, 4767337, '::1', 'ok', 'off', 'January 2, 2018', 'away'),
(2, 'Salman Khan', 'mir_digimarket', 'mir_digimarket@computerfever.com', '$2y$10$fbwexG8VDrX5hKN85uDpRea/vGwSgindAV.YRqbEkAByI8xpbsYN6', 'salman.jpg', 'India', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 3, 'January 3, 2018', 100, 0, 776766564, '', 'ok', 'off', 'January 1, 2018', 'away'),
(3, 'Amir Khan', 'ashleytharma1', 'ashleytharma1@computerfever.com', '$2y$10$H6.6v/.I39lL6bNYqxW7nuGPA9DVc8oBjkNYcmc9GrphFmS2WXtPO', 'amir-khan.jpg', 'India', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 'December 22, 2017', 100, 0, 75375881, '', 'ok', 'off', 'December 28, 2017', 'away'),
(4, 'thili00traffi', 'thili00traffi', 'thili00traffi@computerfever.com', '$2y$10$CczLGMNYNafwNuQDTwFTBOQg5DTtogG1TzMpUMyrklcDyYtPop9YW', 'john-abraham.jpg', 'India', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 'January 1, 2018', 89, 0, 1904048012, '::1', 'ok', 'off', 'December 21, 2017', 'online'),
(5, 'volarex', 'volarex', 'volarex@computerfever.com', '$2y$10$I6w6eVIRZ4SLmsX1V5L/Q.qIYnuRekfhGhFSPOw4u2uHWxzhAyhwe', 'tom-cruise.jpg', 'United States', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 'December 15, 2017', 100, 0, 292065884, '', '36776357657', 'off', 'December 19, 2017', 'away'),
(6, 'Mohammad Shoail Ahmed', 'shoail', 'shoail@computerfever.com', '$2y$10$VX1pEFBvWA/y/gfzCKMWzuF0z/ER6UUgtNhGH5D8FiLAIn/sKD9Y6', 'shoail.jpg', 'Pakistan', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 'December 13, 2017', 100, 0, 1253426511, '', '562728874', 'off', 'December 13, 2017', 'away'),
(7, 'John Cena', 'john', 'john@computerfever.com', '$2y$10$WssGbsWOfKzkUdEl8tx4K.8S7.vUXVECI4BAVbNyf7io/Yrxq5Xw2', 'john-cena.jpg', 'United States', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 'none', 100, 0, 1103147868, '', '16524664', 'off', 'December 9, 2017', 'away'),
(8, 'undertaker', 'undertaker', 'undertaker@computerfever.com', '$2y$10$hiwIoMHhBii3QVpOqXNZJuER3/ZdQc1rywvrg9ikhMFCCoOMDehGK', 'undertaker.jpg', 'United States', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 'none', 100, 0, 2552983, '', '179375672', 'off', 'December 3, 2017', 'away'),
(9, 'Shah Rukh khan', 'king-khan', 'king-khan@gmail.com', '\r\n$2y$10$XsF1NPYFoniKRomKAoOKyOCIj75GF9c.n2wtmyjj9/Ldj39gH3zpS', '', '', '', '', 1, 'none', 100, 10, 415666349, '::1', '1109555598', 'off', 'January 07, 2018', 'away');

-- --------------------------------------------------------

--
-- Table structure for table `seller_accounts`
--

CREATE TABLE `seller_accounts` (
  `account_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_accounts`
--

INSERT INTO `seller_accounts` (`account_id`, `seller_id`) VALUES
(1, 9);

-- --------------------------------------------------------

--
-- Table structure for table `seller_languages`
--

CREATE TABLE `seller_languages` (
  `language_id` int(10) NOT NULL,
  `language_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_languages`
--

INSERT INTO `seller_languages` (`language_id`, `language_title`) VALUES
(1, 'English'),
(2, 'French'),
(3, 'Hindi'),
(4, 'Urdu');

-- --------------------------------------------------------

--
-- Table structure for table `seller_levels`
--

CREATE TABLE `seller_levels` (
  `level_id` int(10) NOT NULL,
  `level_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_levels`
--

INSERT INTO `seller_levels` (`level_id`, `level_title`) VALUES
(1, 'New Seller'),
(2, 'Level One'),
(3, 'Level Two'),
(4, 'Top Rated');

-- --------------------------------------------------------

--
-- Table structure for table `seller_reviews`
--

CREATE TABLE `seller_reviews` (
  `review_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `review_seller_id` int(10) NOT NULL,
  `seller_rating` int(10) NOT NULL,
  `seller_review` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_reviews`
--

INSERT INTO `seller_reviews` (`review_id`, `order_id`, `review_seller_id`, `seller_rating`, `seller_review`) VALUES
(1, 1, 1, 5, 'Great Buyer.'),
(2, 2, 2, 5, 'Thank You Buyer.'),
(3, 4, 2, 5, 'Great Buyer.'),
(4, 6, 3, 5, 'Great Buyer.');

-- --------------------------------------------------------

--
-- Table structure for table `seller_skills`
--

CREATE TABLE `seller_skills` (
  `skill_id` int(10) NOT NULL,
  `skill_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_skills`
--

INSERT INTO `seller_skills` (`skill_id`, `skill_title`) VALUES
(1, '\r\nHtml 5'),
(2, 'css 3'),
(3, 'javascript'),
(4, 'jquery'),
(5, 'php 7');

-- --------------------------------------------------------

--
-- Table structure for table `skills_relation`
--

CREATE TABLE `skills_relation` (
  `relation_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `skill_id` int(10) NOT NULL,
  `skill_level` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skills_relation`
--

INSERT INTO `skills_relation` (`relation_id`, `seller_id`, `skill_id`, `skill_level`) VALUES
(1, 2, 1, 'Beginner'),
(2, 2, 2, 'Intermediate'),
(3, 2, 3, 'Expert');

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `term_id` int(10) NOT NULL,
  `term_title` text NOT NULL,
  `term_link` text NOT NULL,
  `term_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`term_id`, `term_title`, `term_link`, `term_description`) VALUES
(1, 'Terms And Conditions', 'terms', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Why do we use it? It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Where does it come from? Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.'),
(2, 'Refund Policy', 'refund', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Why do we use it? It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Where does it come from? Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.'),
(3, 'Pricing And Promotions Policy', 'pricing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Why do we use it? It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Where does it come from? Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `buyer_reviews`
--
ALTER TABLE `buyer_reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `categories_childs`
--
ALTER TABLE `categories_childs`
  ADD PRIMARY KEY (`child_id`);

--
-- Indexes for table `contact_support`
--
ALTER TABLE `contact_support`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `delivery_times`
--
ALTER TABLE `delivery_times`
  ADD PRIMARY KEY (`delivery_id`);

--
-- Indexes for table `enquiry_types`
--
ALTER TABLE `enquiry_types`
  ADD PRIMARY KEY (`enquiry_id`);

--
-- Indexes for table `footer_links`
--
ALTER TABLE `footer_links`
  ADD PRIMARY KEY (`link_id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_section`
--
ALTER TABLE `home_section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `languages_relation`
--
ALTER TABLE `languages_relation`
  ADD PRIMARY KEY (`relation_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `proposals`
--
ALTER TABLE `proposals`
  ADD PRIMARY KEY (`proposal_id`);

--
-- Indexes for table `section_boxes`
--
ALTER TABLE `section_boxes`
  ADD PRIMARY KEY (`box_id`);

--
-- Indexes for table `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`seller_id`);

--
-- Indexes for table `seller_accounts`
--
ALTER TABLE `seller_accounts`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `seller_languages`
--
ALTER TABLE `seller_languages`
  ADD PRIMARY KEY (`language_id`);

--
-- Indexes for table `seller_levels`
--
ALTER TABLE `seller_levels`
  ADD PRIMARY KEY (`level_id`);

--
-- Indexes for table `seller_reviews`
--
ALTER TABLE `seller_reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `seller_skills`
--
ALTER TABLE `seller_skills`
  ADD PRIMARY KEY (`skill_id`);

--
-- Indexes for table `skills_relation`
--
ALTER TABLE `skills_relation`
  ADD PRIMARY KEY (`relation_id`);

--
-- Indexes for table `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`term_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `buyer_reviews`
--
ALTER TABLE `buyer_reviews`
  MODIFY `review_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories_childs`
--
ALTER TABLE `categories_childs`
  MODIFY `child_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `contact_support`
--
ALTER TABLE `contact_support`
  MODIFY `contact_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `delivery_times`
--
ALTER TABLE `delivery_times`
  MODIFY `delivery_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `enquiry_types`
--
ALTER TABLE `enquiry_types`
  MODIFY `enquiry_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `footer_links`
--
ALTER TABLE `footer_links`
  MODIFY `link_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `home_section`
--
ALTER TABLE `home_section`
  MODIFY `section_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `languages_relation`
--
ALTER TABLE `languages_relation`
  MODIFY `relation_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=15;

--
-- AUTO_INCREMENT for table `proposals`
--
ALTER TABLE `proposals`
  MODIFY `proposal_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `section_boxes`
--
ALTER TABLE `section_boxes`
  MODIFY `box_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sellers`
--
ALTER TABLE `sellers`
  MODIFY `seller_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `seller_accounts`
--
ALTER TABLE `seller_accounts`
  MODIFY `account_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `seller_languages`
--
ALTER TABLE `seller_languages`
  MODIFY `language_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seller_levels`
--
ALTER TABLE `seller_levels`
  MODIFY `level_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seller_reviews`
--
ALTER TABLE `seller_reviews`
  MODIFY `review_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seller_skills`
--
ALTER TABLE `seller_skills`
  MODIFY `skill_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `skills_relation`
--
ALTER TABLE `skills_relation`
  MODIFY `relation_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `terms`
--
ALTER TABLE `terms`
  MODIFY `term_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
