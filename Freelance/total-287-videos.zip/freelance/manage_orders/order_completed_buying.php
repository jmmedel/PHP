
<div class="table-responsive box-table mt-3"><!--- table-responsive box-table mt-3 Starts --->


<table class="table table-hover"><!--- table table-hover Starts --->


<thead><!--- thead Starts --->

<tr>

<th> ORDER SUMMARY </th>

<th> ORDER DATE </th>

<th> DUE ON </th>

<th> TOTAL </th>

<th> STATUS </th>

</tr>

</thead><!--- thead Ends --->

<tbody>

<tr>

<td>

<a href="order_details.php?buying_order">

<img class="order-proposal-image" src="proposals/proposal_files/youtube-seo-1.jpg">

<p class="order-proposal-title"> I Will Do Viral Youtube Seo Social Media Promotion </p>

</a>

</td>

<td> December 5, 2017 </td>

<td> December 8, 2017 </td>

<td> $21 </td>

<td> <button class="btn btn-success"> Completed </button> </td>

</tr>


</tbody>

</table><!--- table table-hover Ends --->


</div><!--- table-responsive box-table mt-3 Ends --->