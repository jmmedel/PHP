
<div id="level-one-modal" class="modal fade"><!-- level-one-modal modal fade Starts -->

<div class="modal-dialog"><!-- modal-dialog Starts -->

<div class="modal-content"><!-- modal-content Starts -->

<div class="modal-header"><!-- modal-header Starts -->

<h5 class="modal-title"> Level One Promoted </h5>

<button class="close" data-dismiss="modal">
  <span> &times; </span>
</button>

</div><!-- modal-header Ends -->

<div class="modal-body text-center"><!-- modal-body text-center Starts -->

<h2> Coolness </h2>

<p class="lead">
We Have Some Coolness News For You!<br> 
You've Become a Level One Seller
</p>

<img src="images/level_badge_1.png" >

</div><!-- modal-body text-center Ends -->

<div class="modal-footer"><!-- modal-footer Starts -->

<button class="btn btn-secondary" data-dismiss="modal">
Close
</button>

</div><!-- modal-footer Ends -->

</div><!-- modal-content Ends -->

</div><!-- modal-dialog Ends -->

</div><!-- level-one-modal modal fade Ends -->

<script>

$(document).ready(function(){
	
	
	$("#level-one-modal").modal('show');
	
});

</script>

<div id="level-two-modal" class="modal fade"><!-- level-two-modal modal fade Starts -->

<div class="modal-dialog"><!-- modal-dialog Starts -->

<div class="modal-content"><!-- modal-content Starts -->

<div class="modal-header"><!-- modal-header Starts -->

<h5 class="modal-title"> Level Two Promoted </h5>

<button class="close" data-dismiss="modal">
  <span> &times; </span>
</button>

</div><!-- modal-header Ends -->

<div class="modal-body text-center"><!-- modal-body text-center Starts -->

<h2> Awesome </h2>

<p class="lead">
We Have Some Awesome News For You!<br> 
You've Become a Level One Seller
</p>

<img src="images/level_badge_2.png" >

</div><!-- modal-body text-center Ends -->

<div class="modal-footer"><!-- modal-footer Starts -->

<button class="btn btn-secondary" data-dismiss="modal">
Close
</button>

</div><!-- modal-footer Ends -->

</div><!-- modal-content Ends -->

</div><!-- modal-dialog Ends -->

</div><!-- level-two-modal modal fade Ends -->

<script>

$(document).ready(function(){
	
	
	$("#level-two-modal").modal('show');
	
});

</script>

<div id="top-rated-modal" class="modal fade"><!-- top-rated-modal modal fade Starts -->

<div class="modal-dialog"><!-- modal-dialog Starts -->

<div class="modal-content"><!-- modal-content Starts -->

<div class="modal-header"><!-- modal-header Starts -->

<h5 class="modal-title"> Top Rated Promoted </h5>

<button class="close" data-dismiss="modal">
  <span> &times; </span>
</button>

</div><!-- modal-header Ends -->

<div class="modal-body text-center"><!-- modal-body text-center Starts -->

<h2> Great </h2>

<p class="lead">
We Have Some Great News For You!<br> 
You've Become a Level One Seller
</p>

<img src="images/level_badge_3.png" >

</div><!-- modal-body text-center Ends -->

<div class="modal-footer"><!-- modal-footer Starts -->

<button class="btn btn-secondary" data-dismiss="modal">
Close
</button>

</div><!-- modal-footer Ends -->

</div><!-- modal-content Ends -->

</div><!-- modal-dialog Ends -->

</div><!-- top-rated-modal modal fade Ends -->

<script>

$(document).ready(function(){
	
	
	$("#top-rated-modal").modal('show');
	
});

</script>