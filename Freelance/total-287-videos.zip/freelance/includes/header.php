
<?php

include("db.php");

if(isset($_SESSION["seller_user_name"])){

include("seller_levels.php");

}

function get_real_user_ip(){
	
	//This is to check ip from shared internet network
	
	if(!empty($_SERVER['HTTP_CLIENT_IP'])){
		
		$ip = $_SERVER['HTTP_CLIENT_IP'];
		
	}
	
	//This is to check ip if it is passing from proxy network
	
	elseif(!empty($_SERVER['HTTP_X_FORWARDED_FOR'])){
		
		$ip = $_SERVER['HTTP_X_FORWARDED_FOR'];
		
	}
	
	else{
		
		$ip = $_SERVER['REMOTE_ADDR'];
		
	}
	
	return $ip;
	
}

$ip = get_real_user_ip();

?>


<nav class="navbar navbar-expand-lg navbar-dark bg-dark 


<?php if(isset($_SESSION['seller_user_name'])){ echo "navbar-login"; } ?> 


fixed-top"><!-- navbar navbar-expand-lg navbar-dark bg-dark fixed-top Starts -->

<div class="container"><!-- container Starts -->

<button class="navbar-toggler" data-toggle="collapse" data-target="#navbarNav">

<span class="navbar-toggler-icon"></span>

</button>

<a class="navbar-brand" href="<?php echo $site_url; ?>/index.php"> Computerfever </a>

<a class="navbar-toggler" href="<?php echo $site_url; ?>/mobile_categories.php">

<i class="fa fa-th-large"></i>

</a>

<div class="collapse navbar-collapse" id="navbarNav"><!-- collapse navbar-collapse Starts -->

<hr>

<form class="form-inline mr-auto" method="post"><!-- form-inline mr-auto Starts -->


<div class="input-group"><!-- input-group Starts -->

<input type="text" class="form-control" required placeholder="Search Proposals" name="search_query" value="<?php echo @$_SESSION["search_query"]; ?>">

<span class="input-group-btn"><!-- input-group-btn Starts -->

<button class="btn btn-primary" name="search" type="submit">

<i class="fa fa-search"></i>

</button>

</span><!-- input-group-btn Ends -->

</div><!-- input-group Ends -->

</form><!-- form-inline mr-auto Ends -->

<?php

if(isset($_POST['search'])){
	
	$search_query = $_POST['search_query'];
	
	$_SESSION['search_query']=$search_query;
	
	header("location: $site_url/search.php");
	
}

?>

<hr>

<ul class="navbar-nav"><!--- navbar-nav Starts -->

<?php if(!isset($_SESSION['seller_user_name'])){ ?>

<li class="nav-item active">

<a href="<?php echo $site_url; ?>/index.php" class="nav-link"> Home </a>

</li>

<li class="nav-item">

<a class="nav-link" href="#" data-toggle="modal" data-target="#register-modal">

Become A Seller

</a>

</li>


<li class="nav-item">

<a class="nav-link" href="#" data-toggle="modal" data-target="#login-modal">

Sign In

</a>

</li>


<li class="nav-item">

<a class="btn btn-primary btn-sm" href="#" data-toggle="modal" data-target="#register-modal">

Sign Up

</a>

</li>

<?php }else{ ?>

<li class="nav-item"><!-- nav-item Starts  -->

<a class="nav-link" href="http://localhost/freelance/dashboard.php" title="Dashboard">

<i class="fa fa-lg fa-dashboard"></i>

<span class="d-lg-none"> Dashboard </span>

</a>

</li><!-- nav-item Ends -->


<li class="nav-item dropdown"><!--- nav-item dropdown Starts -->

<a href="#" class="nav-link dropdown-toggle mr-lg-2" data-toggle="dropdown" title="Notifications"><!-- nav-link dropdown-toggle mr-lg-2 Starts -->

<i class="fa fa-fw fa-lg fa-bell"></i>

<span class="d-lg-none">

Notifications <span class="badge badge-pill badge-danger"> 1 New </span>

</span>

<span class="new-indicator text-danger d-lg-block d-none"><!--- new-indicator text-danger d-lg-block d-none Starts -->

<i class="fa fa-fw fa-circle"></i>

<span class="number"> 1 </span>

</span><!--- new-indicator text-danger d-lg-block d-none Ends -->

</a><!-- nav-link dropdown-toggle mr-lg-2 Ends -->

<div class="dropdown-menu notifications-dropdown"><!--- dropdown-menu notifications-dropdown Starts -->

<h3 class="dropdown-header"><!--- dropdown-header Starts --->

Notifications (1)

<a class="float-right" href="http://localhost/freelance/dashboard.php"> View Dashboard </a>

</h3><!--- dropdown-header Ends --->

<div class="header-message-div-unread"><!--- header-message-div-unread Starts --->

<a href="http://localhost/freelance/dashboard.php?n_id">

<img src="http://localhost/freelance/user_images/salman.jpg" width="50" height="50" class="rounded-circle">

<strong class="heading"> Salman Khan </strong>

<p class="message"> Complete Your Order. </p>

<p class="date text-muted"> 26:11: Nov 08 2017 </p>

</a>

</div><!--- header-message-div-unread Ends --->

<div class="header-message-div"><!--- header-message-div Starts --->

<a href="http://localhost/freelance/dashboard.php?n_id">

<img src="http://localhost/freelance/user_images/salman.jpg" width="50" height="50" class="rounded-circle">

<strong class="heading"> Salman Khan </strong>

<p class="message"> Complete Your Order. </p>

<p class="date text-muted"> 26:11: Nov 26 2017 </p>

</a>

</div><!--- header-message-div Ends --->

</div><!--- dropdown-menu notifications-dropdown Ends -->

</li><!--- nav-item dropdown Ends -->


<li class="nav-item dropdown"><!--- nav-item dropdown Starts --->

<a href="#" class="nav-link dropdown-toggle mr-lg-2" data-toggle="dropdown" title="Inbox Messages"><!--- nav-link dropdown-toggle mr-lg-2 Starts -->

<i class="fa fa-fw fa-lg fa-envelope"></i>

<span class="d-lg-none">

Messages <span class="badge badge-pill badge-danger"> 1 New </span>

</span>

<span class="new-indicator text-danger d-lg-block d-none"><!--- new-indicator text-danger d-lg-block d-none Starts -->

<i class="fa fa-fw fa-circle"></i>

<span class="number">1</span>

</span><!--- new-indicator text-danger d-lg-block d-none Ends -->

</a><!--- nav-link dropdown-toggle mr-lg-2 Ends -->

<div class="dropdown-menu messages-dropdown"><!--- dropdown-menu messages-dropdown Starts -->

<h3 class="dropdown-header"><!--- dropdown-header Starts -->

Inbox (1)

<a class="float-right" href="http://localhost/freelance/conversations/inbox.php">

View Inbox

</a>

</h3><!--- dropdown-header Ends -->

<div class="header-message-div-unread"><!--- header-message-div-unread Starts -->

<a href="http://freelance/conversations/insert_message.php?single_message_id">

<img src="http://localhost/freelance/user_images/brock.jpg" width="50" height="50" class="rounded-circle">

<strong class="heading"> Brock Lesnar </strong>

<p class="message text-truncate"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>

<p class="date text-muted"> 26:11 Nov 26 2017 </p>

</a>

</div><!--- header-message-div-unread Ends -->


<div class="header-message-div"><!--- header-message-div Starts -->

<a href="http://freelance/conversations/insert_message.php?single_message_id">

<img src="http://localhost/freelance/user_images/brock.jpg" width="50" height="50" class="rounded-circle">

<strong class="heading"> Brock Lesnar </strong>

<p class="message text-truncate"> Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, </p>

<p class="date text-muted"> 26:11 Nov 26 2017 </p>

</a>

</div><!--- header-message-div Ends -->

<div class="m-2">

<a href="http://localhost/freelance/conversations/inbox.php" class="btn btn-primary btn-block">
 See All
</a>

</div>

</div><!--- dropdown-menu messages-dropdown Ends -->

</li><!--- nav-item dropdown Ends --->


<li class="nav-item dropdown"><!--- nav-item dropdown Starts -->

<a class="nav-link mr-lg-2" href="http://localhost/freelance/favourites.php" title="Favourites">

<i class="fa fa-fw fa-lg fa-heart"></i>

<span class="d-lg-none">

Favourites <span class="badge badge-pill badge-success"> 4 </span>

</span>

<span class="new-indicator text-success d-lg-block d-none"><!--- new-indicator text-success d-lg-block d-none Starts -->

<i class="fa fa-fw fa-circle"></i>

<span class="number"> 4 </span>

</span><!--- new-indicator text-success d-lg-block d-none Ends -->

</a>

</li><!--- nav-item dropdown Ends -->


<li class="nav-item dropdown"><!--- nav-item dropdown Starts -->

<a class="nav-link mr-lg-2" href="http://localhost/freelance/cart.php" title="Cart">

<i class="fa fa-fw fa-lg fa-shopping-cart"></i>

<span class="d-lg-none">

Cart <span class="badge badge-pill badge-success"> 7 </span>

</span>

<span class="new-indicator text-success d-lg-block d-none"><!--- new-indicator text-success d-lg-block d-none Starts -->

<i class="fa fa-fw fa-circle"></i>

<span class="number"> 7 </span>

</span><!--- new-indicator text-success d-lg-block d-none Ends -->

</a>

</li><!--- nav-item dropdown Ends -->


<li class="nav-item"><!--- nav-item Starts -->

<div class="dropdown"><!--- dropdown Starts --->

<button class="btn btn-outline-secondary btn-sm dropdown-toggle" data-toggle="dropdown">

<img src="http://localhost/freelance/user_images/fixmywebsite.jpg" width="27" height="27" class="rounded-circle">

fixmywebsite <span class="badge badge-success"> $172 </span>

</button>

<div class="dropdown-menu"><!-- dropdown-menu Starts -->

<a class="dropdown-item" href="http://localhost/freelance/dashboard.php">

Dashboard

</a>

<a class="dropdown-item dropdown-toggle" href="#" data-toggle="collapse" data-target="#selling">

Selling

</a>

<div id="selling" class="dropdown-submenu collapse"><!--- selling dropdown-submenu collapse Starts -->

<a class="dropdown-item" href="http://localhost/freelance/selling_orders.php">

Orders

</a>

<a class="dropdown-item" href="http://localhost/freelance/proposals/view_proposals.php">

View Proposals

</a>

<a class="dropdown-item" href="http://localhost/freelance/requests/buyer_requests.php">

Buyer Requests

</a>

<a class="dropdown-item" href="http://localhost/freelance/revenue.php">

Revenues

</a>

</div><!--- selling dropdown-submenu collapse Ends -->

<a class="dropdown-item dropdown-toggle" href="#" data-toggle="collapse" data-target="#buying">

Buying

</a>

<div id="buying" class="dropdown-submenu collapse"><!-- buying dropdown-submenu collapse Starts -->

<a class="dropdown-item" href="http://localhost/freelance/buying_orders.php">

Orders

</a>

<a class="dropdown-item" href="http://localhost/freelance/purchases.php">

Payments

</a>

<a class="dropdown-item" href="http://localhost/freelance/favourites.php">

Favourites

</a>

</div><!-- buying dropdown-submenu collapse Ends -->

<a class="dropdown-item dropdown-toggle" href="#" data-toggle="collapse" data-target="#requests">

Requests

</a>

<div id="requests" class="dropdown-submenu collapse"><!-- requests dropdown-submenu collapse Starts -->

<a class="dropdown-item" href="http://localhost/freelance/requests/post_request.php">

Post A Request

</a>

<a class="dropdown-item" href="http://localhost/freelance/requests/manage_requests.php">

Manage Requests

</a>

</div><!-- requests dropdown-submenu collapse Ends -->

<a class="dropdown-item dropdown-toggle" href="#" data-toggle="collapse" data-target="#contacts">

Contacts

</a>

<div id="contacts" class="dropdown-submenu collapse"><!--- contacts dropdown-submenu collapse Starts -->

<a href="http://localhost/freelance/manage_contacts.php?my_buyers" class="dropdown-item">

My Buyers

</a>

<a href="http://localhost/freelance/manage_contacts.php?my_sellers" class="dropdown-item">

My Sellers

</a>

</div><!--- contacts dropdown-submenu collapse Ends -->

<a class="dropdown-item" href="http://localhost/freelance/my_referrals.php">

My Referrals

</a>

<a class="dropdown-item" href="http://localhost/freelance/conversations/inbox.php">

Inbox Conversations

</a>

<a class="dropdown-item" href="http://localhost/freelance/user.php">

My Profile

</a>

<a class="dropdown-item dropdown-toggle" href="#" data-toggle="collapse" data-target="#settings">

Settings

</a>


<div id="settings" class="dropdown-submenu collapse"><!-- settings dropdown-submenu collapse Starts -->

<a class="dropdown-item" href="http://localhost/freelance/settings.php?profile_settings">

Profile Settings

</a>


<a class="dropdown-item" href="http://localhost/freelance/settings.php?account_settings">

Account Settings

</a>

</div><!-- settings dropdown-submenu collapse Ends -->

<div class="dropdown-divider"> </div>

<a class="dropdown-item" href="http://localhost/freelance/logout.php">

Logout

</a>

</div><!-- dropdown-menu Ends -->

</div><!--- dropdown Ends --->

</li><!--- nav-item Ends -->

<?php } ?>

</ul><!--- navbar-nav Ends -->

</div><!-- collapse navbar-collapse Ends -->


</div><!-- container Ends -->



</nav><!-- navbar navbar-expand-lg navbar-dark bg-dark fixed-top Ends -->



<?php include("category_nav.php"); ?>

<?php if(isset($_GET["not_available"])){ ?>

<div class="alert alert-danger text-center mb-0 h6"><!-- alert alert-danger text-center mb-0 h6 Starts -->

<i class="fa fa-exclamation-circle"> </i>

The Page Or User Account You Are Looking For Is No Longer Available.

</div><!-- alert alert-danger text-center mb-0 h6 Ends -->

<?php } ?>

<?php if(isset($_SESSION["seller_user_name"])){ ?>

<div class="alert alert-warning clearfix"><!-- alert alert-warning clearfix Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-1 text-center"><!-- col-md-1 text-center Starts -->

<i class="fa fa-exclamation-circle fa-5x d-inline-block"></i>

</div><!-- col-md-1 text-center Ends -->

<div class="col-md-8 text-lg-left text-sm-center"><!-- col-md-8 text-lg-left text-sm-center Starts -->

<p>
<strong>
You need to activate your account to visit this website.
</strong>
</p>

<p>
 Confirm email sent to ghlama29@gmail.com
</p>

<p>
Need Help! <a href="contact.php"> Contact Support </a>
</p>

</div><!-- col-md-8 text-lg-left text-sm-center Ends -->

<div class="col-md-3"><!-- col-md-3 Starts -->

<button id="send-email" class="btn btn-warning float-right">
 Send Email
</button>

</div><!-- col-md-3 Ends -->

</div><!-- row Ends -->

</div><!-- alert alert-warning clearfix Ends -->

<?php } ?>

<div class="modal fade" id="register-modal" ><!-- modal fade Starts -->

<div class="modal-dialog"><!-- modal-dialog Starts -->

<div class="modal-form register modal-content"><!-- modal-form register modal-content Starts -->

<div class="modal-header"><!-- modal-header Starts -->

<h5 class="modal-title"> Register Account </h5>

<button class="close" data-dismiss="modal">

<span>&times;</span>

</button>

</div><!-- modal-header Ends -->

<div class="modal-body"><!-- modal-body Starts -->

<form action="" method="post"><!-- form Starts -->

<div class="form-group"><!-- form-group Starts -->

<label class="form-control-label font-weight-bold"> Full Name </label>

<input type="text" class="form-control" name="name" placeholder="Enter Your Full Name" required>

</div><!-- form-group Ends -->


<div class="form-group"><!-- form-group Starts -->

<label class="form-control-label font-weight-bold"> Username </label>

<input type="text" class="form-control" name="u_name" placeholder="Enter Your Username" required>

<small class="form-text text-muted">

! Important Username can not be changed once an account is registered.

</small>

</div><!-- form-group Ends -->



<div class="form-group"><!-- form-group Starts -->

<label class="form-control-label font-weight-bold"> Email </label>

<input type="email" class="form-control" name="email" placeholder="Enter Your Email" required>

</div><!-- form-group Ends -->


<div class="form-group"><!-- form-group Starts -->

<label class="form-control-label font-weight-bold"> Password </label>

<input type="password" class="form-control" name="pass" placeholder="Enter Your Password" required>

</div><!-- form-group Ends -->


<div class="form-group"><!-- form-group Starts -->

<label class="form-control-label font-weight-bold"> Confirm Password </label>

<input type="password" class="form-control" name="con_pass" placeholder="Enter Your Password Again To Confirm" required>

</div><!-- form-group Ends -->

<input type="submit" name="register" class="btn btn-success btn-block" value="Register Here">

</form><!-- form Ends -->

</div><!-- modal-body Ends -->

</div><!-- modal-form register modal-content Ends -->

</div><!-- modal-dialog Ends -->

</div><!-- modal fade Ends -->


<div class="modal fade" id="login-modal"><!-- modal fade Starts -->

<div class="modal-dialog"><!-- modal-dialog Starts -->

<div class="modal-form modal-content"><!-- modal-form modal-content Starts -->

<div class="modal-header"><!-- modal-header Starts -->

<h5 class="modal-title"> Login To Your Account </h5>

<button type="button" class="close" data-dismiss="modal">

<span>&times;</span>

</button>

</div><!-- modal-header Ends -->

<div class="modal-body"><!-- modal-body Starts -->

<form action="" method="post">

<div class="form-group"><!-- form-group Starts -->

<input type="text" class="form-control" name="seller_user_name" placeholder="Username" required>

</div><!-- form-group Ends -->

<div class="form-group"><!-- form-group Starts -->

<input type="password" class="form-control" name="seller_pass" placeholder="Password" required>

</div><!-- form-group Ends -->

<input type="submit" name="login" class="btn btn-success btn-block" value="Login">

</form>

<div class="text-center mt-3"><!-- text-center mt-3 Starts -->

<a href="#" data-toggle="modal" data-target="#register-modal" data-dismiss="modal">

Register

</a>

&nbsp;&nbsp; | &nbsp;&nbsp;

<a href="#" data-toggle="modal" data-target="#forgot-modal" data-dismiss="modal">

Forgot Password

</a>


</div><!-- text-center mt-3 Ends -->

</div><!-- modal-body Ends -->

</div><!-- modal-form modal-content Ends -->

</div><!-- modal-dialog Ends -->

</div><!-- modal fade Ends -->


<div class="modal fade" id="forgot-modal"><!-- modal fade Starts -->

<div class="modal-dialog"><!-- modal-dialog Starts -->

<div class="modal-form modal-content"><!-- modal-form modal-content Starts -->

<div class="modal-header"><!-- modal-header Starts -->

<h5 class="modal-title"> Forgot Password </h5>

<button type="button" class="close" data-dismiss="modal">

<span>&times;</span>

</button>

</div><!-- modal-header Ends -->

<div class="modal-body"><!-- modal-body Starts -->

<p class="text-muted text-center mb-2"><!-- text-muted text-center mb-2 Starts --> 

Enter your Computerfever profile email & we’ll send a password reset link.

</p><!-- text-muted text-center mb-2 Ends --> 

<form action="" method="post"><!-- form Starts -->

<div class="form-group"><!-- form-group Starts -->

<input type="text" class="form-control" name="forgot_email" placeholder="Enter Your Email" required>

</div><!-- form-group Ends -->

<input type="submit" name="forgot" class="btn btn-success btn-block" value="Submit">

<p class="text-muted text-center mt-2"><!-- text-muted text-center mt-2 Starts -->

Not A Member Yet ?

<a href="#" data-toggle="modal" data-target="#register-modal" data-dismiss="modal">

Join Now

</a>

</p><!-- text-muted text-center mt-2 Ends -->

</form><!-- form Ends -->


</div><!-- modal-body Ends -->

</div><!-- modal-form modal-content Ends -->

</div><!-- modal-dialog Ends -->

</div><!-- modal fade Ends -->


<?php include("register-login-forgot.php"); ?>

