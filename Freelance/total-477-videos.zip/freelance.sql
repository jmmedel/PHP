-- phpMyAdmin SQL Dump
-- version 4.7.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: May 29, 2018 at 09:09 AM
-- Server version: 10.1.26-MariaDB
-- PHP Version: 7.1.9

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `freelance`
--

-- --------------------------------------------------------

--
-- Table structure for table `adds`
--

CREATE TABLE `adds` (
  `add_id` int(10) NOT NULL,
  `add_title` varchar(255) NOT NULL,
  `add_code` text NOT NULL,
  `add_place` varchar(255) NOT NULL,
  `enable_add` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `adds`
--

INSERT INTO `adds` (`add_id`, `add_title`, `add_code`, `add_place`, `enable_add`) VALUES
(1, 'Chitika Sidebar Add', '<script type=\"text/javascript\">\r\n  ( function() {\r\n    if (window.CHITIKA === undefined) { window.CHITIKA = { \'units\' : [] }; };\r\n    var unit = {\"calltype\":\"async[2]\",\"publisher\":\"NayerAzem123\",\"width\":550,\"height\":250,\"sid\":\"Chitika Default\"};\r\n    var placement_id = window.CHITIKA.units.length;\r\n    window.CHITIKA.units.push(unit);\r\n    document.write(\'<div style=\"margin-left:-110px;\" id=\"chitikaAdBlock-\' + placement_id + \'\"></div>\');\r\n}());\r\n</script>\r\n<script type=\"text/javascript\" src=\"//cdn.chitika.net/getads.js\" async></script>', 'dashboard_sidebar', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(10) NOT NULL,
  `admin_name` text NOT NULL,
  `admin_email` text NOT NULL,
  `admin_pass` text NOT NULL,
  `admin_image` text NOT NULL,
  `admin_contact` text NOT NULL,
  `admin_country` text NOT NULL,
  `admin_job` text NOT NULL,
  `admin_about` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `admin_name`, `admin_email`, `admin_pass`, `admin_image`, `admin_contact`, `admin_country`, `admin_job`, `admin_about`) VALUES
(1, 'Kareena Kapoor', 'kareena@gmail.com', '$2y$10$A1nubDNGCUDCWOgCgxjjbeiLZgBcBlGB0w7jCJtwUDdjduT7/z/tq', 'kareena.jpg', '0923337857', 'India', 'Actress', 'Contrary to popular belief Lorem Ipsum is not simply random text. It has roots in a piece of    classical Latin literature from 45 BC making it over 2000 years old. Richard McClintock a Latin   professor at Hampden-Sydney College in Virginia looked up one of');

-- --------------------------------------------------------

--
-- Table structure for table `buyer_requests`
--

CREATE TABLE `buyer_requests` (
  `request_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `cat_id` int(10) NOT NULL,
  `child_id` int(10) NOT NULL,
  `request_title` text NOT NULL,
  `request_description` text NOT NULL,
  `request_file` text NOT NULL,
  `delivery_time` text NOT NULL,
  `request_budget` text NOT NULL,
  `request_date` text NOT NULL,
  `request_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buyer_requests`
--

INSERT INTO `buyer_requests` (`request_id`, `seller_id`, `cat_id`, `child_id`, `request_title`, `request_description`, `request_file`, `delivery_time`, `request_budget`, `request_date`, `request_status`) VALUES
(1, 1, 2, 20, 'Youtube SkyRocket Views', 'i want more than 50k youtube views', 'download.jpg', '3 Days', '15', 'January 15, 2018', 'active'),
(2, 2, 6, 11, 'Need A Wordpress Developer', 'i want 5 years experience Wordpress theme developer', 'download.jpg', 'Any Day', '100', 'January 15, 2018', 'active'),
(3, 3, 1, 12, 'Background Removel', 'Photo Background Removal.', 'download.jpg', '1 Day', '5', 'January 15, 2018', 'active'),
(4, 3, 6, 60, 'Prestashop Sms Api', 'Sms api integration to prestashop platform. Already have api key for sample\r\n', 'download.jpg', '1 Day', '50', 'January 15, 2018', 'active'),
(5, 3, 6, 60, 'Shopify Premium Store', 'Shopify Store Build - Looking for a full Catalog Store with the ability to sell predesigned items that the design can be purchased on 4 different things.', 'download.jpg', '1 Day', '50', 'January 15, 2018', 'active'),
(6, 4, 2, 20, 'youtube channel facebook page', 'i need youtube channel facebook page setup', 'download.jpg', '2 Day', '10', 'January 15, 2018', 'active'),
(7, 4, 6, 11, 'I want to customize my wordrress e-commerce theme.', 'i want 5 years experience theme developer who experts in html css php & mysqli .', 'download.jpg', 'Any Day', '100', 'January 15, 2018', 'active'),
(8, 2, 2, 20, 'I want youtube views', 'i want more than 50k youtube views on my chanel.', 'download.jpg', '3 Days', '15', 'January 20, 2018', 'active'),
(9, 4, 6, 11, 'I need a experience wordpress web developer.', 'i want 5 years experience Wordpress theme developer.', 'download.jpg', 'Any Day', '100', 'January 15, 2018', 'active'),
(12, 1, 1, 12, 'I need a article writer urgent.', 'I want a man who writes articles on my website.', '', '1 Days', '40', 'February 31, 2018', 'pending'),
(14, 2, 2, 20, 'I want to promote my youtube channel.', 'I want a man who can promote my youtube channel this is the url https://www.youtube.com/channel/UCcCGca_TUZcqiTr-ZtlirHQ', 'promote.jpg', '3 Days', '10', 'February 10, 2018', 'active'),
(15, 2, 6, 56, 'I need a experience game developer.', 'i want 5 years experience shooting game developer.', 'download.jpg', 'Any Day', '100', 'January 15, 2018', 'active'),
(16, 1, 1, 13, 'I need a 2D template', 'I need a 2D template for a pillow box with flat sides. I need someone 2who knows what a pillow box is, (Google it) with knowledge of geometry and math or software to design it.', '', '3 Days', '35', 'July 23th, 2017', 'unapproved'),
(26, 8, 6, 61, 'Convert exe to apkp file', 'Convert.... I have a windows based file that is EXE and need it to be converted into an AKP file.	', '', '1 Day', '10', 'July 21th, 2017', 'pending'),
(29, 2, 6, 56, 'Personal Management System', 'Hi ever body, I am Saeid from Austria. now I have a Project for \"Personal Management System of Events\". I want to realize it with flowing technologies: 1- React + Redux 2- Bootstrap (responsive design) 3- Firebase as DB + backend-function + Storage + notification + auth if you have interest callback', '', 'Any Day', '', 'July 24th, 2017', 'pending'),
(30, 7, 6, 60, 'Develop My Ecommerce Store', 'I am looking for someone to develop my ecommerce store using ecwid. I already have a site template, I just need site development, coding services.', '', '7 Days', '150', 'July 25th, 2017', 'pending'),
(34, 3, 1, 12, 'I need to someone edit my logo', 'need to someone editing my porposed logo to matching with my website and corporate theme.', '', '1 Day', '', 'July 27th, 2017', 'pending'),
(38, 6, 2, 10, 'facebook like website', 'i want make facebook like website in wordpress.', 'facebook.JPG', '7 Days', '50', 'July 28th, 2017', 'pending'),
(44, 4, 6, 11, 'I need a shopify website', 'I need a shopify website built to sell from Alibaba express. it has to be strength, power speed, oriented. I am selling sports performance equipment and training fear!', '', '1 Day', '25', 'August 1st, 2017', 'pending'),
(51, 3, 6, 56, 'Please Quote Me', 'Please quote for a platform exactly like computerfever.com', 'image.jpg', '3 Days', '40', 'December 12th, 2017', 'pending'),
(54, 5, 8, 94, 'Softwere Serial Key', 'I am looking to get a VALID ACTIVATION KEY for Newspaper WordPress theme by tagdiv.', 'download.jpg', '1 Day', '5', 'October 14th, 2017', 'pending'),
(56, 6, 3, 33, 'Story Writing', 'I am a creative story writer that can spin up a story both fictional and non-fictional. I can also proof read and edit articles for blog posts. I h... See more', 'download.jpg', '1 Day', '5', 'October 14th, 2017', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `buyer_reviews`
--

CREATE TABLE `buyer_reviews` (
  `review_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `review_buyer_id` int(10) NOT NULL,
  `buyer_rating` int(10) NOT NULL,
  `buyer_review` text NOT NULL,
  `review_seller_id` int(10) NOT NULL,
  `review_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `buyer_reviews`
--

INSERT INTO `buyer_reviews` (`review_id`, `proposal_id`, `order_id`, `review_buyer_id`, `buyer_rating`, `buyer_review`, `review_seller_id`, `review_date`) VALUES
(1, 7, 1, 2, 5, 'Outstanding Work.', 1, 'January 2, 2018'),
(2, 2, 2, 3, 5, 'Great Work.', 2, 'December 30, 2017'),
(3, 2, 4, 4, 5, 'Outstanding Experience.', 2, 'December 28, 2017'),
(4, 4, 6, 1, 3, 'Just what i wanted.', 3, 'December 21, 2017'),
(6, 5, 9, 1, 5, 'Great Job.', 6, 'December 21, 2017'),
(7, 6, 10, 2, 5, 'Great Job.', 5, 'December 21, 2017'),
(10, 12, 14, 7, 5, 'Great Job.', 5, 'December 21, 2017'),
(12, 13, 0, 7, 5, 'Excellent Seller.', 1, 'Mar 13 2018');

-- --------------------------------------------------------

--
-- Table structure for table `cart`
--

CREATE TABLE `cart` (
  `cart_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `proposal_price` int(10) NOT NULL,
  `proposal_qty` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `cat_id` int(10) NOT NULL,
  `cat_title` text NOT NULL,
  `cat_desc` text NOT NULL,
  `cat_image` text NOT NULL,
  `cat_featured` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`cat_id`, `cat_title`, `cat_desc`, `cat_image`, `cat_featured`) VALUES
(1, 'Graphics & Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'graphic-design.png', 'yes'),
(2, 'Digital Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'digital marketing.jpg', 'yes'),
(3, 'Writing & Translation', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'writting.jpg', 'yes'),
(4, 'Video & Animation\r\n', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'video-animation.jpg', 'yes'),
(5, 'Music & Audio', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'music-audio.jpg', 'yes'),
(6, 'Programming & Tech\r\n', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'program-tech.jpg', 'yes'),
(7, 'Business\r\n', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'business.jpg', 'yes'),
(8, 'Fun & Lifestyle\r\n', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'fun-life-style.jpg', 'yes');

-- --------------------------------------------------------

--
-- Table structure for table `categories_childs`
--

CREATE TABLE `categories_childs` (
  `child_id` int(10) NOT NULL,
  `child_parent_id` int(10) NOT NULL,
  `child_title` text NOT NULL,
  `child_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `categories_childs`
--

INSERT INTO `categories_childs` (`child_id`, `child_parent_id`, `child_title`, `child_desc`) VALUES
(1, 1, 'Logo Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(2, 1, 'Business Cards &amp; Stationery', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(3, 1, 'Illustration', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(4, 1, 'Cartoons Caricatures', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(5, 1, 'Flyers Posters', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(6, 1, 'Book Covers & Packaging', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(7, 1, 'Web &amp; Mobile Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(8, 1, 'Social Media Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(9, 1, 'Banner Ads', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(10, 2, 'Social Media Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(11, 6, 'WordPress', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(12, 1, 'Photoshop Editing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(13, 1, '3D & 2D Models', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(14, 1, 'T-Shirts', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(15, 1, 'Presentation Design', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(16, 1, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(17, 2, 'SEO', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(18, 2, 'Web Traffic', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(19, 2, 'Content Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(20, 2, 'Video Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(21, 2, 'Email Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(22, 2, 'Search & Display Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(23, 2, 'Marketing Strategy', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(24, 2, 'Web Analytics', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(25, 2, 'Influencer Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(26, 2, 'Local Listings', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(27, 2, 'Domain Research', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(28, 2, 'E-Commerce Marketing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(29, 2, 'Mobile Advertising', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(30, 3, 'Resumes & Cover Letters', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(31, 3, 'Proofreading & Editing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(32, 3, 'Translation', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(33, 3, 'Creative Writing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(34, 3, 'Business Copywriting', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(35, 3, 'Research & Summaries', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(36, 3, 'Articles & Blog Posts', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(37, 3, 'Press Releases', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(38, 3, 'Transcription', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(39, 3, 'Legal Writing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(40, 3, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(41, 4, 'Whiteboard & Explainer Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(42, 4, 'Intros & Animated Logos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(43, 4, 'Promotional & Brand Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(44, 4, 'Editing & Post Production', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(45, 4, 'Lyric & Music Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(46, 4, 'Spokespersons & Testimonials', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(48, 4, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(49, 5, 'Voice Over', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(50, 5, 'Mixing & Mastering', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(51, 5, 'Producers & Composers', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(52, 5, 'Singer-Songwriters', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(53, 5, 'Session Musicians & Singers', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(54, 5, 'Jingles & Drops', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(55, 5, 'Sound Effects', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(56, 6, 'Web Programming', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(58, 6, 'Website Builders & CMS', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(60, 6, 'Ecommerce', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(61, 6, 'Mobile Apps & Web', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(62, 6, 'Desktop applications', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(63, 6, 'Support & IT', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(64, 6, 'Chatbots', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(65, 6, 'Data Analysis & Reports', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(66, 6, 'Convert Files', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(67, 6, 'Databases', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(68, 6, 'User Testing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(69, 6, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(70, 7, 'Virtual Assistant', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(71, 7, 'Market Research', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(72, 7, 'Business Plans', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(73, 7, 'Branding Services', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(74, 7, 'Legal Consulting', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(75, 7, 'Financial Consulting', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(76, 7, 'Business Tips', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(77, 7, 'Presentations', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(78, 7, 'Career Advice', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(79, 7, 'Flyer Distribution', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(80, 7, 'Other', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(81, 8, 'Online Lessons', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(82, 8, 'Arts & Crafts', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(83, 8, 'Relationship Advice', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(84, 8, 'Health, Nutrition & Fitness', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(85, 8, 'Astrology & Readings', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(86, 8, 'Spiritual & Healing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(87, 8, 'Family & Genealogy', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(88, 8, 'Collectibles', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(89, 8, 'Greeting Cards & Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(91, 8, 'Viral Videos', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(92, 8, 'Pranks & Stunts', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(93, 8, 'Celebrity Impersonators', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.'),
(94, 8, 'Others', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.');

-- --------------------------------------------------------

--
-- Table structure for table `contact_support`
--

CREATE TABLE `contact_support` (
  `contact_id` int(10) NOT NULL,
  `contact_email` text NOT NULL,
  `contact_heading` text NOT NULL,
  `contact_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `contact_support`
--

INSERT INTO `contact_support` (`contact_id`, `contact_email`, `contact_heading`, `contact_desc`) VALUES
(1, 'sad.ahmed22224@gmail.com', 'Submit A Support Request', 'If you have any questions, pease feel free to contact us, Our customer service center is working for you 24/7.');

-- --------------------------------------------------------

--
-- Table structure for table `coupons`
--

CREATE TABLE `coupons` (
  `coupon_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `coupon_title` text NOT NULL,
  `coupon_price` int(10) NOT NULL,
  `coupon_code` text NOT NULL,
  `coupon_limit` int(10) NOT NULL,
  `coupon_used` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `coupons`
--

INSERT INTO `coupons` (`coupon_id`, `proposal_id`, `coupon_title`, `coupon_price`, `coupon_code`, `coupon_limit`, `coupon_used`) VALUES
(5, 6, 'Proposal Coupon', 10, '444455', 5, 1);

-- --------------------------------------------------------

--
-- Table structure for table `delivery_times`
--

CREATE TABLE `delivery_times` (
  `delivery_id` int(10) NOT NULL,
  `delivery_title` text NOT NULL,
  `delivery_proposal_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `delivery_times`
--

INSERT INTO `delivery_times` (`delivery_id`, `delivery_title`, `delivery_proposal_title`) VALUES
(1, 'Up to 24 hours', '1 Day'),
(2, 'Up to 3 Days', '3 Days'),
(3, 'Up to 4 Days', '4 Days'),
(4, 'Up to 7 Days', '7 Days'),
(5, 'Any', 'Any Day');

-- --------------------------------------------------------

--
-- Table structure for table `enquiry_types`
--

CREATE TABLE `enquiry_types` (
  `enquiry_id` int(10) NOT NULL,
  `enquiry_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `enquiry_types`
--

INSERT INTO `enquiry_types` (`enquiry_id`, `enquiry_title`) VALUES
(1, 'Order Support '),
(2, 'Review Removal '),
(3, 'Account Support'),
(4, 'Report A Bug \r\n'),
(5, 'Featured Support');

-- --------------------------------------------------------

--
-- Table structure for table `favorites`
--

CREATE TABLE `favorites` (
  `favourite_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `favorites`
--

INSERT INTO `favorites` (`favourite_id`, `seller_id`, `proposal_id`) VALUES
(1, 4, 1);

-- --------------------------------------------------------

--
-- Table structure for table `featured_proposals`
--

CREATE TABLE `featured_proposals` (
  `featured_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `end_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `footer_links`
--

CREATE TABLE `footer_links` (
  `link_id` int(10) NOT NULL,
  `link_title` text NOT NULL,
  `link_url` text NOT NULL,
  `link_section` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `footer_links`
--

INSERT INTO `footer_links` (`link_id`, `link_title`, `link_url`, `link_section`) VALUES
(1, 'Graphics & Design', 'http://localhost/freelance/category.php?cat_id=1', 'categories'),
(2, 'Digital Marketing', 'http://localhost/freelance/category.php?cat_id=2', 'categories'),
(3, 'Writing & Translation\r\n', 'http://localhost/freelance/category.php?cat_id=3', 'categories'),
(4, 'Video & Animation\r\n', 'http://localhost/freelance/category.php?cat_id=4', 'categories'),
(5, 'Music & Audio\r\n', 'http://localhost/freelance/category.php?cat_id=5', 'categories'),
(6, 'Programming & Tech\r\n', 'http://localhost/freelance/category.php?cat_id=6', 'categories'),
(7, 'Business\r\n', 'http://localhost/freelance/category.php?cat_id=7', 'categories'),
(8, 'Fun & Lifestyle\r\n', 'http://localhost/freelance/category.php?cat_id=8', 'categories'),
(10, 'Customer SUPPORT', 'http://localhost/freelance/contact.php', 'support'),
(11, '<i class=\"fa fa-google-plus-official\"></i> Google Plus', '#', 'follow'),
(12, '<i class=\"fa fa-twitter\"></i> Twitter', '#', 'follow'),
(13, '<i class=\"fa fa-facebook\"></i> Facebook', '#', 'follow'),
(14, '<i class=\"fa fa-linkedin\"></i> Linkedin', '#', 'follow'),
(15, '<i class=\"fa fa-pinterest\"></i> Pinterest', '#', 'follow'),
(18, 'Terms & Conditions', 'http://localhost/freelance/terms.php', 'about');

-- --------------------------------------------------------

--
-- Table structure for table `general_settings`
--

CREATE TABLE `general_settings` (
  `id` int(10) NOT NULL,
  `site_title` text NOT NULL,
  `site_desc` text NOT NULL,
  `site_keywords` text NOT NULL,
  `site_author` text NOT NULL,
  `site_url` text NOT NULL,
  `site_email_address` text NOT NULL,
  `level_one_rating` int(10) NOT NULL,
  `level_one_orders` int(10) NOT NULL,
  `level_two_rating` int(10) NOT NULL,
  `level_two_orders` int(10) NOT NULL,
  `level_top_rating` int(10) NOT NULL,
  `level_top_orders` int(10) NOT NULL,
  `enable_referrals` text NOT NULL,
  `referral_money` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `general_settings`
--

INSERT INTO `general_settings` (`id`, `site_title`, `site_desc`, `site_keywords`, `site_author`, `site_url`, `site_email_address`, `level_one_rating`, `level_one_orders`, `level_two_rating`, `level_two_orders`, `level_top_rating`, `level_top_orders`, `enable_referrals`, `referral_money`) VALUES
(1, 'Computerfever - Freelance Services Marketplace', 'Computerfever is the world\'s largest freelance services marketplace for learn entrepreneurs to focus on growth & create a successful business at affordable costs.\r\n', 'freelance,freelancers,jobs,proposals,sellers,buyers', 'Mohammed Tahir Ahmed', 'http://localhost/freelance', 'sad.ahmed22224@gmail.com', 90, 10, 0, 30, 95, 60, 'yes', 1);

-- --------------------------------------------------------

--
-- Table structure for table `hide_seller_messages`
--

CREATE TABLE `hide_seller_messages` (
  `id` int(10) NOT NULL,
  `hider_id` int(10) NOT NULL,
  `hide_seller_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `hide_seller_messages`
--

INSERT INTO `hide_seller_messages` (`id`, `hider_id`, `hide_seller_id`) VALUES
(1, 1, 5);

-- --------------------------------------------------------

--
-- Table structure for table `home_section`
--

CREATE TABLE `home_section` (
  `section_id` int(10) NOT NULL,
  `section_title` text NOT NULL,
  `section_short_desc` text NOT NULL,
  `section_desc` text NOT NULL,
  `section_button` text NOT NULL,
  `section_button_url` text NOT NULL,
  `section_image` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `home_section`
--

INSERT INTO `home_section` (`section_id`, `section_title`, `section_short_desc`, `section_desc`, `section_button`, `section_button_url`, `section_image`) VALUES
(1, 'We Have A Creative Platform', 'We Provide Freelancing Services to Buyers', 'We have a creative platform which provide quality freelancing services to buyers at affordable rates and buyers will also have the option to cancel the orders if they don\'t like the work. ', 'Contact Us', 'contact.php', 'platform-image.jpg');

-- --------------------------------------------------------

--
-- Table structure for table `inbox_messages`
--

CREATE TABLE `inbox_messages` (
  `message_id` int(10) NOT NULL,
  `message_group_id` int(10) NOT NULL,
  `message_sender` int(10) NOT NULL,
  `message_receiver` int(10) NOT NULL,
  `message_offer_id` int(10) NOT NULL,
  `message_desc` text NOT NULL,
  `message_file` text NOT NULL,
  `message_date` text NOT NULL,
  `message_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inbox_messages`
--

INSERT INTO `inbox_messages` (`message_id`, `message_group_id`, `message_sender`, `message_receiver`, `message_offer_id`, `message_desc`, `message_file`, `message_date`, `message_status`) VALUES
(1, 7625724, 1, 4, 0, 'Hello thili00traffi', '', '2:10: January 9, 2018\r\n', 'read'),
(2, 56256561, 2, 4, 0, 'I need to combine 13 pdf documents of about 10 pages each into 1 pdf, Can you do this.', '', '2:10: January 11, 2018\r\n', 'read'),
(3, 799872384, 5, 1, 0, 'Hello Fixmyebsite\r\nI want man who create my mobile app.', '', '2:10: January 9, 2018\r\n', 'read'),
(4, 966881336, 1, 2, 0, 'I am Fixmyebsite\r\nI want to translate an urdu story into English.', '', '3:10: January 10, 2018\r\n', 'read'),
(5, 966881336, 2, 1, 0, 'ok i will do it as you are demanding.', 'sample-image.jpg', '11:55: February 13, 2018', 'read'),
(7, 966881336, 2, 1, 2, 'i am sending you an offer.', '', '03:38: February 13, 2018', 'read'),
(8, 558109793, 2, 5, 0, 'Hello volarex I do you build a app for me.', '', '03:20: March 11, 2018', 'read'),
(9, 558109793, 5, 2, 0, 'yes i will do it.', '', '03:20: March 11, 2018', 'read'),
(10, 558109793, 5, 2, 0, 'tell me what kind of app you want create.', '', '03:20: March 11, 2018', 'read'),
(11, 495976613, 3, 2, 0, 'Do you build a Laravel website for me.', '', '03:23: March 11, 2018', 'read'),
(12, 495976613, 2, 3, 0, 'Yes i will build any website in laravel.', '', '03:24: March 11, 2018', 'read'),
(13, 495976613, 2, 3, 0, 'But it cost $200.', '', '03:26: March 11, 2018', 'read'),
(14, 1451730458, 3, 1, 0, 'I want to edit my wedding photo.', '', '03:26: March 11, 2018', 'read'),
(15, 1451730458, 3, 1, 0, 'this is photo.', 'wedding.jpg', '04:08: March 11, 2018', 'read'),
(16, 1451730458, 1, 3, 3, 'ok i will do it.', '', '04:10: March 11, 2018', 'read'),
(18, 7625724, 1, 4, 0, 'i want to make a game from you.', '', '03:11: April 22, 2018', 'read'),
(19, 7625724, 1, 4, 0, 'can you reply me fast.', '', '03:14: April 22, 2018', 'read');

-- --------------------------------------------------------

--
-- Table structure for table `inbox_sellers`
--

CREATE TABLE `inbox_sellers` (
  `inbox_seller_id` int(10) NOT NULL,
  `message_group_id` int(10) NOT NULL,
  `message_id` int(10) NOT NULL,
  `offer_id` int(10) NOT NULL,
  `sender_id` int(10) NOT NULL,
  `receiver_id` int(10) NOT NULL,
  `message_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `inbox_sellers`
--

INSERT INTO `inbox_sellers` (`inbox_seller_id`, `message_group_id`, `message_id`, `offer_id`, `sender_id`, `receiver_id`, `message_status`) VALUES
(1, 7625724, 19, 0, 1, 4, 'read'),
(2, 56256561, 2, 0, 2, 4, 'read'),
(3, 676773525, 0, 0, 3, 4, 'empty'),
(4, 966881336, 7, 4, 2, 1, 'read'),
(5, 799872384, 3, 0, 5, 1, 'read'),
(6, 558109793, 10, 0, 5, 2, 'read'),
(7, 495976613, 13, 0, 2, 3, 'read'),
(8, 1451730458, 16, 0, 1, 3, 'read');

-- --------------------------------------------------------

--
-- Table structure for table `languages_relation`
--

CREATE TABLE `languages_relation` (
  `relation_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `language_id` int(11) NOT NULL,
  `language_level` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `languages_relation`
--

INSERT INTO `languages_relation` (`relation_id`, `seller_id`, `language_id`, `language_level`) VALUES
(1, 2, 1, 'Basic'),
(2, 2, 2, 'Conversational'),
(3, 2, 3, 'Fluent'),
(4, 2, 4, 'Native or Bilingual'),
(5, 1, 1, 'Conversational'),
(6, 1, 2, 'Basic'),
(7, 3, 1, 'Fluent'),
(8, 3, 2, 'Native or Bilingual'),
(9, 4, 1, 'Conversational'),
(10, 4, 1, 'Native or Bilingual'),
(11, 5, 2, 'Conversational'),
(12, 6, 1, 'Conversational'),
(13, 7, 2, 'Conversational'),
(14, 7, 1, 'Conversational'),
(15, 8, 1, 'Conversational'),
(18, 1, 4, 'Fluent'),
(19, 1, 4, 'Fluent');

-- --------------------------------------------------------

--
-- Table structure for table `messages_offers`
--

CREATE TABLE `messages_offers` (
  `offer_id` int(10) NOT NULL,
  `sender_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `description` text NOT NULL,
  `delivery_time` text NOT NULL,
  `amount` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `messages_offers`
--

INSERT INTO `messages_offers` (`offer_id`, `sender_id`, `proposal_id`, `order_id`, `description`, `delivery_time`, `amount`, `status`) VALUES
(2, 2, 16, 25, 'i will do your work as you demand.', '1 Day', '5', 'accepted'),
(3, 1, 13, 0, 'please give me order.', '1 Day', '5', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `my_buyers`
--

CREATE TABLE `my_buyers` (
  `id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `buyer_id` int(10) NOT NULL,
  `completed_orders` int(10) NOT NULL,
  `amount_spent` int(10) NOT NULL,
  `last_order_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `my_buyers`
--

INSERT INTO `my_buyers` (`id`, `seller_id`, `buyer_id`, `completed_orders`, `amount_spent`, `last_order_date`) VALUES
(2, 2, 1, 10, 120, 'February 14, 2018'),
(4, 4, 1, 5, 35, 'April 12, 2018'),
(6, 1, 2, 5, 50, 'February 2, 2018'),
(7, 1, 3, 3, 30, 'January 30, 2018'),
(8, 1, 4, 2, 25, 'January 26, 2018'),
(10, 4, 2, 1, 20, 'January 25, 2018'),
(11, 5, 1, 1, 20, 'May 10, 2018');

-- --------------------------------------------------------

--
-- Table structure for table `my_sellers`
--

CREATE TABLE `my_sellers` (
  `id` int(10) NOT NULL,
  `buyer_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `completed_orders` int(10) NOT NULL,
  `amount_spent` int(10) NOT NULL,
  `last_order_date` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `my_sellers`
--

INSERT INTO `my_sellers` (`id`, `buyer_id`, `seller_id`, `completed_orders`, `amount_spent`, `last_order_date`) VALUES
(2, 1, 2, 10, 120, 'February 14, 2018'),
(4, 1, 4, 3, 45, 'April 12, 2018'),
(5, 4, 2, 3, 30, 'February 15, 2018'),
(6, 4, 3, 1, 10, 'January 30, 2018'),
(7, 1, 5, 1, 20, 'May 10, 2018');

-- --------------------------------------------------------

--
-- Table structure for table `notifications`
--

CREATE TABLE `notifications` (
  `notification_id` int(10) NOT NULL,
  `receiver_id` int(10) NOT NULL,
  `sender_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `reason` text NOT NULL,
  `date` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `notifications`
--

INSERT INTO `notifications` (`notification_id`, `receiver_id`, `sender_id`, `order_id`, `reason`, `date`, `status`) VALUES
(1, 4, 2, 10, 'order', '2:10: January 1, 2018', 'unread'),
(2, 4, 2, 10, 'order_message', '2:10: January 2, 2018', 'unread'),
(3, 4, 2, 10, 'order_revision', '2:10: January 3, 2018', 'unread'),
(5, 1, 2, 10, 'order', '2:10: January 8, 2018', 'unread'),
(6, 2, 1, 18, 'order', 'January 23, 2018', 'unread'),
(7, 4, 1, 27, 'order', 'January 24, 2018', 'unread'),
(8, 2, 1, 28, 'order', 'January 24, 2018', 'unread'),
(9, 4, 1, 19, 'order', 'January 25, 2018', 'read'),
(10, 2, 1, 20, 'order', 'January 25, 2018', 'unread'),
(12, 2, 1, 22, 'order', 'January 25, 2018', 'unread'),
(14, 4, 1, 21, 'order_message', '12:32: Jan 29, 2018', 'unread'),
(18, 1, 4, 21, 'order_message', '04:06: Jan 29, 2018', 'read'),
(19, 1, 4, 21, 'order_delivered', '05:01: Jan 29 2018', 'read'),
(22, 1, 4, 21, 'cancellation_request', '05:15: Jan 30, 2018', 'unread'),
(23, 4, 1, 21, 'decline_cancellation_request', '12:24: Jan 31, 2018', 'unread'),
(24, 4, 1, 21, 'cancellation_request', '10:14: Feb 01, 2018', 'unread'),
(25, 1, 4, 21, 'accept_cancellation_request', '10:14: Feb 01, 2018', 'unread'),
(26, 4, 3, 14, 'order_message', '10:29: Feb 01, 2018', 'unread'),
(27, 4, 3, 14, 'cancellation_request', '10:35: Feb 01, 2018', 'unread'),
(28, 3, 4, 14, 'decline_cancellation_request', '10:35: Feb 01, 2018', 'unread'),
(29, 4, 6, 13, 'order_message', '11:21: Feb 01, 2018', 'unread'),
(30, 4, 6, 13, 'order_message', '11:22: Feb 01, 2018', 'unread'),
(31, 4, 6, 13, 'order_message', '11:23: Feb 01, 2018', 'unread'),
(32, 4, 6, 13, 'order_message', '11:43: Feb 01, 2018', 'unread'),
(33, 6, 4, 13, 'order_delivered', '12:02: Feb 01 2018', 'unread'),
(34, 4, 6, 13, 'order_completed', '12:53: Feb 01, 2018', 'unread'),
(35, 6, 4, 13, 'seller_order_review', '03:02: Feb 01 2018', 'unread'),
(36, 4, 6, 13, 'buyer_order_review', '04:02: Feb 01 2018', 'unread'),
(37, 2, 1, 24, 'order', 'February 09, 2018', 'unread'),
(38, 2, 1, 24, 'order_message', '04:01: Feb 09, 2018', 'unread'),
(39, 2, 1, 25, 'order', 'February 14, 2018', 'unread'),
(40, 2, 1, 25, 'cancelled_by_customer_support', '03:36: Apr 07, 2018', 'unread'),
(41, 4, 1, 26, 'order', 'April 12, 2018', 'unread'),
(42, 4, 1, 26, 'order_message', '03:57: Apr 12, 2018', 'unread'),
(43, 4, 1, 26, 'cancelled_by_customer_support', '03:51: Apr 22, 2018', 'unread'),
(44, 2, 1, 24, 'cancelled_by_customer_support', '03:51: Apr 22, 2018', 'unread'),
(45, 5, 1, 27, 'order', 'May 10, 2018', 'unread');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(10) NOT NULL,
  `order_number` text NOT NULL,
  `order_duration` text NOT NULL,
  `order_time` text NOT NULL,
  `order_date` text NOT NULL,
  `order_description` text NOT NULL,
  `seller_id` int(10) NOT NULL,
  `buyer_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `order_price` int(10) NOT NULL,
  `order_qty` int(10) NOT NULL,
  `order_fee` int(10) NOT NULL,
  `order_active` text NOT NULL,
  `order_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `orders`
--

INSERT INTO `orders` (`order_id`, `order_number`, `order_duration`, `order_time`, `order_date`, `order_description`, `seller_id`, `buyer_id`, `proposal_id`, `order_price`, `order_qty`, `order_fee`, `order_active`, `order_status`) VALUES
(1, '3266236', '1 Day', 'Jan 02, 2018 05:54:36', 'January 01, 2018', '', 1, 4, 1, 10, 1, 1, 'no', 'completed'),
(2, '56567676', '7 Days', 'Jan 04, 2018 05:54:36', 'January 03, 2018', '', 2, 3, 2, 10, 1, 0, 'no', 'completed'),
(4, '26677666', '7 Days', 'Jan 05, 2018 05:54:36', 'January 04, 2018', '', 2, 5, 2, 20, 2, 1, 'no', 'completed'),
(6, '26444453', '1 Day', 'Jan 07, 2018 05:54:36', 'January 06, 2018', '', 2, 4, 4, 10, 1, 0, 'no', 'completed'),
(9, '133444545', '3 Days', 'Jan 10, 2018 02:52:36', 'January 07, 2018', '', 4, 6, 7, 20, 1, 0, 'no', 'completed'),
(10, '94525626', '3 Days', 'Jan 10, 2018 02:52:36', 'January 07, 2018', '', 4, 7, 7, 20, 1, 1, 'no', 'completed'),
(13, '562556265', '3 Days', 'Feb 04, 2018 07:23:32', 'January 07, 2018', '', 4, 6, 7, 20, 1, 0, 'no', 'completed'),
(14, '1232556', '3 Days', 'Jan 10, 2018 02:52:36', 'January 07, 2018', '', 4, 3, 7, 20, 1, 1, 'no', 'cancelled'),
(16, '34452634', ' 3 Days', 'Jan 12, 2018 02:52:36', 'January 09, 2018', '', 2, 1, 8, 20, 1, 0, 'no', 'completed'),
(18, '2034866106', '7 Days', 'Jan 30, 2018 05:54:36', 'January 23, 2018', '', 2, 1, 2, 10, 1, 0, 'yes', 'delivered'),
(21, '1698943215', '5 Days', 'Jan 30, 2018 11:15:38', 'January 25, 2018', '', 4, 1, 7, 20, 1, 0, 'no', 'cancelled'),
(22, '1204887259', '7 Days', 'Feb 01, 2018 11:15:39', 'January 25, 2018', '', 2, 1, 2, 15, 3, 0, 'yes', 'delivered'),
(23, '3266236', '1 Day', 'Jan 02, 2018 05:54:36', 'January 01, 2018', '', 1, 4, 1, 20, 2, 1, 'no', 'completed'),
(24, '403050052', '1 Day', 'Feb 10, 2018 12:01:47', 'February 09, 2018', 'I will translate your urdu story to english.', 2, 1, 16, 5, 1, 0, 'no', 'cancelled'),
(25, '1229197351', '1 Day', 'Feb 15, 2018 11:47:56', 'February 14, 2018', 'i will do your work as you demand.', 2, 1, 16, 5, 1, 0, 'no', 'cancelled'),
(26, '1719980621', '3 Days', 'Apr 15, 2018 12:57:03', 'April 12, 2018', '', 4, 1, 7, 20, 1, 0, 'no', 'cancelled'),
(27, '418416865', 'Any Day', 'Jan 01, 1970 12:00:00', 'May 10, 2018', '', 5, 1, 6, 20, 1, 1, 'yes', 'pending');

-- --------------------------------------------------------

--
-- Table structure for table `order_conversations`
--

CREATE TABLE `order_conversations` (
  `c_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `sender_id` int(10) NOT NULL,
  `message` text NOT NULL,
  `file` varchar(255) NOT NULL,
  `date` varchar(255) NOT NULL,
  `reason` text NOT NULL,
  `status` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `order_conversations`
--

INSERT INTO `order_conversations` (`c_id`, `order_id`, `sender_id`, `message`, `file`, `date`, `reason`, `status`) VALUES
(2, 21, 1, 'Please make a game for me which will be played on mobiles apps.\n', 'mario.jpg', '12:32: Jan 29, 2018', '', 'message'),
(6, 21, 4, '\nO.K I will do it,so you don\'t worry about it.', '', '04:06: Jan 29, 2018', '', 'message'),
(7, 21, 4, 'Here is your delivery.I have made your game', 'game.jpg', '05:01: Jan 29 2018', '', 'message'),
(8, 21, 1, 'I have seen it and your work is not up to standard.', 'threat-image.jpg', '04:31: Jan 30, 2018', '', 'revision'),
(11, 21, 4, 'i want to cancel this order.', '', '05:15: Jan 30, 2018', 'Buyer is not responding', 'decline_cancellation_request'),
(12, 21, 1, 'o.k I accept your request now.', '', '10:14: Feb 01, 2018', 'Seller tells me to, cancel this order.', 'accept_cancellation_request'),
(13, 14, 3, 'I have given you this order mistakenly,so please cancel this', '', '10:29: Feb 01, 2018', '', 'message'),
(14, 14, 3, 'I have given you this order mistakenly, so please cancel this order.', '', '10:35: Feb 01, 2018', 'Seller tells me to, cancel this order.', 'decline_cancellation_request'),
(15, 14, 0, '', '', '', '', 'cancelled_by_customer_support'),
(19, 13, 6, 'Please make a creative game for me.', '', '11:43: Feb 01, 2018', '', 'message'),
(20, 13, 4, 'Here is your order delivery', 'slide-5.jpg', '12:02: Feb 01 2018', '', 'message'),
(21, 1, 4, 'My Youtube Channel Url Is : https://www.youtube.com/channel/UCcCGca_TUZcqiTr-ZtlirHQ', '', '12:02: Feb 01 2018', '', 'message'),
(22, 1, 1, 'I Will Complete My Work.', '', '12:02: Feb 02 2018', '', 'message'),
(23, 2, 3, 'Create A E-commerce Website With Laravel And Codeigniter', '', '12:02: Jan 01 2018', '', 'message'),
(24, 2, 2, 'Here Is Your Work.', '', '12:02: Jan 05 2018', '', 'message'),
(25, 4, 5, 'Create A Real Estate Website With Laravel And Codeigniter.', '', '12:02: Jan 01 2018', '', 'message'),
(26, 4, 2, 'Here Is Your Work.', '', '12:02: Jan 05 2018', '', 'message'),
(27, 6, 4, 'Create A Explainer Video About This Site\r\nhttps://www.computerfever.com\r\n\r\n', '', '12:02: Jan 03 2018', '', 'message'),
(28, 6, 2, 'Here Is Your Work.', 'video.mp4', '12:02: Jan 05 2018', '', 'message'),
(29, 9, 6, 'Please make a racing game for me which will be played on windows.\r\n', 'mario.jpg', '12:32: Jan 28, 2018', '', 'message'),
(30, 9, 4, 'Here is your delivery.I have made your game', 'game.jpg', '05:01: Jan 30 2018', '', 'message'),
(31, 10, 7, 'Please make a shooting game for me which will be played on andriod.\r\n', 'mario.jpg', '12:32: Jan 28, 2018', '', 'message'),
(32, 10, 4, 'Here is your delivery.I have made your game', 'game.jpg', '05:01: Jan 30 2018', '', 'message'),
(33, 16, 1, 'I want to customize my wordpress website design.\r\n\r\nThis is Site Url : https://www.computerfever.com\r\n\r\n', '', '12:32: Jan 28, 2018', '', 'message'),
(34, 16, 2, 'I have customized your website.', '', '12:32: Jan 28, 2018', '', 'message'),
(35, 18, 1, 'Create A Blogging Website With Laravel And Codeigniter.', '', '12:02: Jan 01 2018', '', 'message'),
(36, 18, 2, 'Here is your delivery.I have made your website.', '', '05:01: Jan 30 2018', '', 'delivered'),
(37, 22, 1, 'Create A Cms Like Wordpress With Laravel And Codeigniter.', '', '12:02: Jan 01 2018', '', 'message'),
(38, 22, 2, 'I have Create A Cms Like Wordpress.', '', '12:02: Jan 01 2018', '', 'delivered'),
(39, 24, 1, 'Please translate my story into English language.', '', '04:01: Feb 09, 2018', '', 'message'),
(40, 25, 1, 'Order Cancelled By Customer Support', '', '03:36: Apr 07, 2018', '', 'cancelled_by_customer_support'),
(41, 26, 1, 'Please develop a good game for me.', '', '03:57: Apr 12, 2018', '', 'message'),
(42, 26, 1, 'Order Cancelled By Customer Support', '', '03:51: Apr 22, 2018', '', 'cancelled_by_customer_support'),
(43, 24, 1, 'Order Cancelled By Customer Support', '', '03:51: Apr 22, 2018', '', 'cancelled_by_customer_support');

-- --------------------------------------------------------

--
-- Table structure for table `payment_settings`
--

CREATE TABLE `payment_settings` (
  `id` int(10) NOT NULL,
  `comission_percentage` int(10) NOT NULL,
  `days_before_withdraw` int(10) NOT NULL,
  `withdrawal_limit` int(10) NOT NULL,
  `featured_fee` int(10) NOT NULL,
  `featured_duration` int(10) NOT NULL,
  `processing_fee` int(10) NOT NULL,
  `enable_paypal` text NOT NULL,
  `paypal_email` text NOT NULL,
  `paypal_currency_code` text NOT NULL,
  `paypal_api_username` text NOT NULL,
  `paypal_api_password` text NOT NULL,
  `paypal_api_signature` text NOT NULL,
  `paypal_app_id` text NOT NULL,
  `paypal_sandbox` text NOT NULL,
  `enable_stripe` text NOT NULL,
  `stripe_secret_key` text NOT NULL,
  `stripe_publishable_key` text NOT NULL,
  `stripe_currency_code` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `payment_settings`
--

INSERT INTO `payment_settings` (`id`, `comission_percentage`, `days_before_withdraw`, `withdrawal_limit`, `featured_fee`, `featured_duration`, `processing_fee`, `enable_paypal`, `paypal_email`, `paypal_currency_code`, `paypal_api_username`, `paypal_api_password`, `paypal_api_signature`, `paypal_app_id`, `paypal_sandbox`, `enable_stripe`, `stripe_secret_key`, `stripe_publishable_key`, `stripe_currency_code`) VALUES
(1, 25, 10, 5, 10, 2, 1, 'yes', 'paypal-business@computerfever.com', 'USD', 'paypal-business_api1.computerfever.com', 'ZKZMK2PG2TWCMXQC', 'AvDjGN8oD1ALXS2btFY5O9LIIxQGAAQnXs6Rl5Vgn0wolnjW1BkmaUaz', 'APP-80W284485P519543T', 'off', 'yes', 'sk_test_RtRMOCdX6IIK2f9Q94CilE5k', 'pk_test_NcOLIMZPgVJid1099xnjs1Ka', 'usd');

-- --------------------------------------------------------

--
-- Table structure for table `proposals`
--

CREATE TABLE `proposals` (
  `proposal_id` int(10) NOT NULL,
  `proposal_title` text NOT NULL,
  `proposal_url` text NOT NULL,
  `proposal_cat_id` int(10) NOT NULL,
  `proposal_child_id` int(10) NOT NULL,
  `proposal_price` int(10) NOT NULL,
  `proposal_img1` text NOT NULL,
  `proposal_img2` text NOT NULL,
  `proposal_img3` text NOT NULL,
  `proposal_img4` text NOT NULL,
  `proposal_video` text NOT NULL,
  `proposal_desc` text NOT NULL,
  `buyer_instruction` text NOT NULL,
  `proposal_tags` text NOT NULL,
  `proposal_featured` text NOT NULL,
  `proposal_seller_id` int(10) NOT NULL,
  `delivery_id` int(10) NOT NULL,
  `level_id` int(10) NOT NULL,
  `language_id` int(10) NOT NULL,
  `proposal_rating` text NOT NULL,
  `proposal_views` int(10) NOT NULL,
  `proposal_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proposals`
--

INSERT INTO `proposals` (`proposal_id`, `proposal_title`, `proposal_url`, `proposal_cat_id`, `proposal_child_id`, `proposal_price`, `proposal_img1`, `proposal_img2`, `proposal_img3`, `proposal_img4`, `proposal_video`, `proposal_desc`, `buyer_instruction`, `proposal_tags`, `proposal_featured`, `proposal_seller_id`, `delivery_id`, `level_id`, `language_id`, `proposal_rating`, `proposal_views`, `proposal_status`) VALUES
(1, 'I Will Do Viral YouTube Social Seo Media Promotion ', 'i-will-do-viral-youtube-seo-social-media-promotion', 2, 20, 10, 'youtube-seo-1.jpg', 'youtube-seo-2.jpg', 'youtube-seo-3.jpg', 'youtube-seo-4.jpg', 'youtube-seo-video.mp4', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>', 'Please send your youtube channel url.Please send your required promotioal video url.', 'youtube,seo,viral,promotion', 'no', 1, 1, 2, 1, '5', 33, 'active'),
(2, 'I Will Do Web Development In Laravel And Codeigniter', 'i-will-do-web-development-in-laravel-and-codeignite', 6, 56, 10, 'web-development.jpg', 'web-development-2.png', '', '', 'web-development.mp4', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'web application,build website,codeigniter,php', 'no', 2, 4, 2, 2, '5', 234, 'active'),
(3, 'I Will Design A Logo And Brand For You', 'i-will-design-a-logo-and-brand-for-you', 1, 1, 20, 'logo-1.jpg', 'logo-2.jpg', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your logo creation.', 'custom logo,typography,minimal,design', 'no', 3, 1, 2, 1, '0', 1, 'modification'),
(4, '\r\nI Will Create A Professional Custom Explainer Video', 'i-will-create-a-professional-custom-explainer-video', 4, 41, 20, 'videosales-1.png', 'videosales-2.jpg', 'videosales-3.jpg', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'explainer video,whiteboard animation,sales video,Animated video,video marketing', 'no', 2, 1, 2, 1, '3', 14, 'pause'),
(5, 'I Will Record Your Brazilian Portuguese Voice Over', 'i-will-record-your-brazilian-portuguese-voice-over', 5, 49, 10, 'voice-over-1.jpg', '', '', '', 'voiceover.mp4', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'audio,voice,voiceover,brazilian', 'no', 6, 2, 1, 1, '5', 59, 'pause'),
(6, 'I Will Design And Code Android Apps', 'i-will-design-and-code-android-apps', 6, 61, 20, 'andorid-1.jpg', 'andorid-2.jpg', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'android development,android app,', 'no', 5, 5, 2, 1, '5', 39, 'active'),
(7, 'I Will Develop And Reskin 3d And 2d Games In Unity', 'i-will-develop-and-reskin-3d-and-2d-games-in-unit', 6, 56, 20, 'game-1.jpg', 'game-2.jpg', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your game creation.', 'unity,android,ios,games,app', 'no', 4, 2, 1, 1, '5', 44, 'active'),
(8, 'I Will Do Wordpress Customization And PHP Programming', 'i-will-do-wordpress-customization-and-php-programming', 6, 11, 10, 'wordpress-customization-1.jpg', '', '', '', 'wordpress-customization.mp4', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>', 'Please give me full details about your work.', 'wordpress blogs,complete wordpress,wordpress website,design wordpress', 'no', 1, 4, 1, 1, '5', 13, 'active'),
(9, 'I will write custom php script,code for you', 'i-will-write-custom-php-script', 6, 56, 20, 'php-script.jpg', '', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'html,css,php,javascript,laravel', 'no', 8, 2, 2, 1, '0', 6, 'trash'),
(10, 'I Will Create Or Modify Html Js Php Projects And More', 'modify-html-js-php-projects', 6, 56, 10, 'fixjshtml-1.jpg', '', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'html 5,css,php7,javascript,laravel', 'no', 8, 3, 3, 4, '0', 4, 'active'),
(11, 'I Will Fix PHP Errors Write Php Scripts And Web Application', 'fix-php-errors-write-php-scripts', 6, 56, 20, 'fix-php-errors-1.png', '', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'html,css,php,javascript,laravel', 'no', 6, 4, 4, 3, '0', 5, 'pause'),
(12, 'I Will Setup Live Chat Customer Support On Your Website', 'i-will-setup-live-chat-customer-support-on-your-website', 6, 56, 20, 'livechat-1.png', 'livechat-2.jpg', 'livechat-3.jpg', 'livechat-4.jpg', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'live chat,chat software,customer service,livechat,chat', 'no', 5, 2, 1, 3, '5', 22, 'active'),
(13, 'I Will Provide Professional Image Editing', 'i-will-provide-professional-image-editing', 1, 12, 10, 'editing-photo-1.jpg', 'editing-photo-2.jpg', 'editing-photo-3.jpg', '', '', '<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.</p>', 'Please give me full details about your work.', 'background removal,image editin,gairbrushing,photoediting,photo retouching', 'no', 1, 1, 2, 1, '5', 14, 'active'),
(15, 'I Will Translate Between Arabic, English And Somali', 'i-will-translate-between-arabic-english-and-somali', 3, 32, 15, 'translate-1.jpg', '', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'writing, translation', 'no', 4, 2, 1, 1, '', 1, 'active'),
(16, 'I Will Translate Any Language To English. ', 'i-will-translate-any-language-to-english', 3, 32, 10, 'translate-3.jpg', '', '', '', '', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book.', 'Please give me full details about your work.', 'writing, translation', 'no', 2, 2, 1, 1, '', 10, 'pause');

-- --------------------------------------------------------

--
-- Table structure for table `proposal_modifications`
--

CREATE TABLE `proposal_modifications` (
  `modification_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `modification_message` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `proposal_modifications`
--

INSERT INTO `proposal_modifications` (`modification_id`, `proposal_id`, `modification_message`) VALUES
(1, 13, 'Please change your proposal image because it has copyright strike.'),
(2, 3, 'Please Change Your Proposal Images Because They Have Copyright Claim.');

-- --------------------------------------------------------

--
-- Table structure for table `purchases`
--

CREATE TABLE `purchases` (
  `purchase_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `date` text NOT NULL,
  `method` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `purchases`
--

INSERT INTO `purchases` (`purchase_id`, `seller_id`, `order_id`, `amount`, `date`, `method`) VALUES
(1, 1, 18, 10, 'January 23, 2018', 'shopping_balance'),
(4, 1, 21, 20, 'January 25, 2018', 'stripe'),
(5, 1, 22, 15, 'January 25, 2018', 'paypal'),
(6, 1, 21, 20, 'February 01, 2018', 'order_cancellation'),
(7, 1, 24, 5, 'February 09, 2018', 'shopping_balance'),
(8, 1, 25, 5, 'February 14, 2018', 'shopping_balance'),
(9, 1, 25, 5, 'April 07, 2018', 'order_cancellation'),
(10, 1, 26, 20, 'April 12, 2018', 'shopping_balance'),
(11, 1, 26, 20, 'April 22, 2018', 'order_cancellation'),
(12, 1, 24, 5, 'April 22, 2018', 'order_cancellation'),
(13, 1, 27, 21, 'May 10, 2018', 'stripe');

-- --------------------------------------------------------

--
-- Table structure for table `recent_proposals`
--

CREATE TABLE `recent_proposals` (
  `recent_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `recent_proposals`
--

INSERT INTO `recent_proposals` (`recent_id`, `seller_id`, `proposal_id`) VALUES
(1, 4, 3),
(2, 4, 5),
(6, 1, 8),
(98, 4, 1),
(99, 6, 0),
(101, 6, 2),
(102, 6, 8),
(103, 4, 6),
(106, 1, 15),
(110, 1, 16),
(119, 1, 10),
(122, 1, 5),
(125, 2, 6),
(126, 3, 2),
(127, 3, 13),
(149, 1, 12),
(156, 2, 1),
(160, 2, 7),
(174, 1, 2),
(178, 1, 7),
(179, 4, 16),
(180, 1, 6);

-- --------------------------------------------------------

--
-- Table structure for table `referrals`
--

CREATE TABLE `referrals` (
  `referral_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `referred_id` int(10) NOT NULL,
  `comission` int(10) NOT NULL,
  `date` text NOT NULL,
  `ip` varchar(255) NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `referrals`
--

INSERT INTO `referrals` (`referral_id`, `seller_id`, `referred_id`, `comission`, `date`, `ip`, `status`) VALUES
(1, 1, 2, 1, 'December 14, 2017', '1', 'approved'),
(2, 1, 3, 1, 'December 16, 2017', '1', 'declined'),
(3, 1, 4, 1, 'December 25, 2017', '1', 'approved'),
(4, 1, 5, 1, 'December 30, 2017', '1', 'declined');

-- --------------------------------------------------------

--
-- Table structure for table `revenues`
--

CREATE TABLE `revenues` (
  `revenue_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `amount` int(10) NOT NULL,
  `date` text NOT NULL,
  `end_date` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `revenues`
--

INSERT INTO `revenues` (`revenue_id`, `seller_id`, `order_id`, `amount`, `date`, `end_date`, `status`) VALUES
(1, 1, 1, 8, 'October 11,2017', 'October 11, 2017 06:27:56', 'cleared'),
(3, 1, 23, 16, 'January 8,2017', 'January 06, 2017 08:27:56', 'cleared');

-- --------------------------------------------------------

--
-- Table structure for table `section_boxes`
--

CREATE TABLE `section_boxes` (
  `box_id` int(10) NOT NULL,
  `box_title` text NOT NULL,
  `box_desc` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `section_boxes`
--

INSERT INTO `section_boxes` (`box_id`, `box_title`, `box_desc`) VALUES
(1, 'Your Terms\r\n', 'Whatever you need to simplify your to do list, no matter your budget.\r\n'),
(2, 'Your Work', 'Whatever you need to simplify your to do list, no matter your budget.\r\n'),
(3, 'Your Safety\r\n', 'Your payment is always secure, Computerfever is built to protect your peace of mind.\r\n');

-- --------------------------------------------------------

--
-- Table structure for table `sellers`
--

CREATE TABLE `sellers` (
  `seller_id` int(10) NOT NULL,
  `seller_name` varchar(255) NOT NULL,
  `seller_user_name` varchar(255) NOT NULL,
  `seller_email` text NOT NULL,
  `seller_paypal_email` text NOT NULL,
  `seller_pass` text NOT NULL,
  `seller_image` text NOT NULL,
  `seller_country` text NOT NULL,
  `seller_headline` text NOT NULL,
  `seller_about` text NOT NULL,
  `seller_level` int(10) NOT NULL,
  `seller_language` int(10) NOT NULL,
  `seller_recent_delivery` text NOT NULL,
  `seller_rating` int(10) NOT NULL,
  `seller_offers` int(10) NOT NULL,
  `seller_referral` int(10) NOT NULL,
  `seller_ip` varchar(255) NOT NULL,
  `seller_verification` text NOT NULL,
  `seller_vacation` text NOT NULL,
  `seller_register_date` text NOT NULL,
  `seller_status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `sellers`
--

INSERT INTO `sellers` (`seller_id`, `seller_name`, `seller_user_name`, `seller_email`, `seller_paypal_email`, `seller_pass`, `seller_image`, `seller_country`, `seller_headline`, `seller_about`, `seller_level`, `seller_language`, `seller_recent_delivery`, `seller_rating`, `seller_offers`, `seller_referral`, `seller_ip`, `seller_verification`, `seller_vacation`, `seller_register_date`, `seller_status`) VALUES
(1, 'Ghulam Ahmed', 'fixmywebsite', 'fixmywebsite@computerfever.com', 'my-paypal@computerfever.com', '$2y$10$LuNJhya.0.TZU6cxJaBzxe8oCa.1khuOna.77mqPiA6CFYa4zL5NO', 'fixmywebsite.jpg', 'India', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 2, 1, 'December 28, 2017', 100, 9, 4767337, '::1', 'ok', 'off', 'January 2, 2018', 'away'),
(2, 'Salman Khan', 'mir_digimarket', 'mir_digimarket@computerfever.com', '', '$2y$10$fbwexG8VDrX5hKN85uDpRea/vGwSgindAV.YRqbEkAByI8xpbsYN6', 'salman.jpg', 'India', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 3, 2, 'January 3, 2018', 100, 3, 776766564, '::1', 'ok', 'off', 'January 1, 2018', 'online'),
(3, 'Amir Khan', 'ashleytharma1', 'ashleytharma1@computerfever.com', '', '$2y$10$H6.6v/.I39lL6bNYqxW7nuGPA9DVc8oBjkNYcmc9GrphFmS2WXtPO', 'amir-khan.jpg', 'India', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 1, 'December 22, 2017', 100, 0, 75375881, '::1', 'ok', 'off', 'December 28, 2017', 'away'),
(4, 'thili00traffi', 'thili00traffi', 'thili00traffi@computerfever.com', '', '$2y$10$CczLGMNYNafwNuQDTwFTBOQg5DTtogG1TzMpUMyrklcDyYtPop9YW', 'john-abraham.jpg', 'India', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 1, 'February 01, 2018', 98, 4, 1904048012, '::1', 'ok', 'off', 'December 21, 2017', 'online'),
(5, 'volarex', 'volarex', 'volarex@computerfever.com', '', '$2y$10$I6w6eVIRZ4SLmsX1V5L/Q.qIYnuRekfhGhFSPOw4u2uHWxzhAyhwe', 'tom-cruise.jpg', 'United States', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 1, 'December 15, 2017', 100, 0, 292065884, '::1', 'ok', 'off', 'December 19, 2017', 'away'),
(6, 'Mohammad Shoail Ahmed', 'sohail', 'shoail@computerfever.com', '', '$2y$10$N5Eqc1UF/O0a.pI1ffj6tOzzMXwWehv1hKouH3eFRPgoGsi3QdsyO', 'shoail.jpg', 'Pakistan', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 1, 'December 13, 2017', 100, 0, 1253426511, '::1', 'ok', 'off', 'December 13, 2017', 'online'),
(7, 'John Cena', 'john', 'john@computerfever.com', '', '$2y$10$WssGbsWOfKzkUdEl8tx4K.8S7.vUXVECI4BAVbNyf7io/Yrxq5Xw2', 'john-cena.jpg', 'United States', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 2, 'none', 100, 0, 1103147868, '::1', 'ok', 'off', 'December 9, 2017', 'away'),
(8, 'undertaker', 'undertaker', 'undertaker@computerfever.com', '', '$2y$10$hiwIoMHhBii3QVpOqXNZJuER3/ZdQc1rywvrg9ikhMFCCoOMDehGK', 'undertaker.jpg', 'United States', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 4, 'none', 100, 0, 2552983, '::1', 'ok', 'off', 'December 3, 2017', 'away'),
(9, 'Shah Rukh khan', 'king-khan', 'king-khan@gmail.com', '', '\r\n$2y$10$XsF1NPYFoniKRomKAoOKyOCIj75GF9c.n2wtmyjj9/Ldj39gH3zpS', 'shah-rukh.jpg', 'India', 'Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry\'s.', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here.', 1, 3, 'none', 100, 10, 415666349, '::1', '7675886', 'off', 'January 07, 2018', 'away');

-- --------------------------------------------------------

--
-- Table structure for table `seller_accounts`
--

CREATE TABLE `seller_accounts` (
  `account_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `withdrawn` int(10) NOT NULL,
  `current_balance` int(10) NOT NULL,
  `used_purchases` int(10) NOT NULL,
  `pending_clearance` int(10) NOT NULL,
  `month_earnings` int(10) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_accounts`
--

INSERT INTO `seller_accounts` (`account_id`, `seller_id`, `withdrawn`, `current_balance`, `used_purchases`, `pending_clearance`, `month_earnings`) VALUES
(1, 1, 40, 56, 60, 0, 70),
(3, 2, 30, 99, 0, 0, 40),
(4, 3, 40, 100, 0, 0, 60),
(5, 4, 60, 50, 0, 16, 96),
(6, 5, 45, 15, 0, 0, 45),
(7, 6, 70, 10, 0, 0, 50),
(8, 7, 60, 0, 0, 0, 60),
(9, 8, 40, 10, 0, 0, 90),
(10, 9, 50, 0, 0, 0, 100);

-- --------------------------------------------------------

--
-- Table structure for table `seller_languages`
--

CREATE TABLE `seller_languages` (
  `language_id` int(10) NOT NULL,
  `language_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_languages`
--

INSERT INTO `seller_languages` (`language_id`, `language_title`) VALUES
(1, 'English'),
(2, 'French'),
(3, 'Hindi'),
(4, 'Punjabi');

-- --------------------------------------------------------

--
-- Table structure for table `seller_levels`
--

CREATE TABLE `seller_levels` (
  `level_id` int(10) NOT NULL,
  `level_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_levels`
--

INSERT INTO `seller_levels` (`level_id`, `level_title`) VALUES
(1, 'New Seller'),
(2, 'Level One'),
(3, 'Level Two'),
(4, 'Top Rated');

-- --------------------------------------------------------

--
-- Table structure for table `seller_reviews`
--

CREATE TABLE `seller_reviews` (
  `review_id` int(10) NOT NULL,
  `order_id` int(10) NOT NULL,
  `review_seller_id` int(10) NOT NULL,
  `seller_rating` int(10) NOT NULL,
  `seller_review` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_reviews`
--

INSERT INTO `seller_reviews` (`review_id`, `order_id`, `review_seller_id`, `seller_rating`, `seller_review`) VALUES
(1, 1, 1, 5, 'Great Buyer.'),
(2, 2, 2, 5, 'Thank You Buyer.'),
(4, 6, 3, 5, 'Great Buyer.'),
(5, 13, 4, 4, 'Excellent buyer but give little responses.'),
(7, 10, 5, 5, 'Excellent Buyer.'),
(8, 14, 5, 5, 'Awesome Buyer.');

-- --------------------------------------------------------

--
-- Table structure for table `seller_skills`
--

CREATE TABLE `seller_skills` (
  `skill_id` int(10) NOT NULL,
  `skill_title` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `seller_skills`
--

INSERT INTO `seller_skills` (`skill_id`, `skill_title`) VALUES
(1, '\r\nHtml 5'),
(2, 'css 3'),
(3, 'javascript'),
(4, 'jquery'),
(5, 'php 5');

-- --------------------------------------------------------

--
-- Table structure for table `send_offers`
--

CREATE TABLE `send_offers` (
  `offer_id` int(10) NOT NULL,
  `request_id` int(10) NOT NULL,
  `sender_id` int(10) NOT NULL,
  `proposal_id` int(10) NOT NULL,
  `description` text NOT NULL,
  `delivery_time` text NOT NULL,
  `amount` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `send_offers`
--

INSERT INTO `send_offers` (`offer_id`, `request_id`, `sender_id`, `proposal_id`, `description`, `delivery_time`, `amount`, `status`) VALUES
(1, 2, 1, 8, 'i can develop any kind of wordpress theme\r\n', '3 Days', '120', 'active'),
(2, 6, 1, 1, 'I will do your work as you said', '1 Day', '5', 'active');

-- --------------------------------------------------------

--
-- Table structure for table `skills_relation`
--

CREATE TABLE `skills_relation` (
  `relation_id` int(10) NOT NULL,
  `seller_id` int(10) NOT NULL,
  `skill_id` int(10) NOT NULL,
  `skill_level` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `skills_relation`
--

INSERT INTO `skills_relation` (`relation_id`, `seller_id`, `skill_id`, `skill_level`) VALUES
(1, 2, 1, 'Beginner'),
(2, 2, 2, 'Intermediate'),
(3, 2, 3, 'Expert'),
(4, 1, 1, 'Beginner'),
(5, 1, 2, 'Intermediate'),
(6, 1, 3, 'Expert');

-- --------------------------------------------------------

--
-- Table structure for table `slider`
--

CREATE TABLE `slider` (
  `slide_id` int(10) NOT NULL,
  `slide_name` text NOT NULL,
  `slide_desc` text NOT NULL,
  `slide_image` text NOT NULL,
  `slide_url` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `slider`
--

INSERT INTO `slider` (`slide_id`, `slide_name`, `slide_desc`, `slide_image`, `slide_url`) VALUES
(2, 'Slide Number 2', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.', 'image-2.jpg', 'http://www.computerfever.com\r\n'),
(3, 'Slide Number 3', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.', 'image-3.jpg', 'http://www.computerfever.com\r\n'),
(4, 'Slide Number 4', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.', 'image-4.jpg', 'http://www.computerfever.com\r\n'),
(8, 'Slide Number 1', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. ', 'image-5.jpg', 'http://www.computerfever.com');

-- --------------------------------------------------------

--
-- Table structure for table `support_tickets`
--

CREATE TABLE `support_tickets` (
  `ticket_id` int(10) NOT NULL,
  `enquiry_id` int(10) NOT NULL,
  `sender_id` int(10) NOT NULL,
  `subject` text NOT NULL,
  `message` text NOT NULL,
  `order_number` text NOT NULL,
  `order_rule` text NOT NULL,
  `attachment` text NOT NULL,
  `date` text NOT NULL,
  `status` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `support_tickets`
--

INSERT INTO `support_tickets` (`ticket_id`, `enquiry_id`, `sender_id`, `subject`, `message`, `order_number`, `order_rule`, `attachment`, `date`, `status`) VALUES
(1, 1, 1, 'I need your support', '\r\nPlease help me in solving this issue.', '989777', 'Buyer', 'slide-5.jpg', '06:58 Jan 20, 2018', 'closed'),
(8, 3, 2, 'Proposal creation', 'I need to know how to create proposal.', '', '', '', '04:58 Feb 05, 2018', 'open');

-- --------------------------------------------------------

--
-- Table structure for table `terms`
--

CREATE TABLE `terms` (
  `term_id` int(10) NOT NULL,
  `term_title` text NOT NULL,
  `term_link` text NOT NULL,
  `term_description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `terms`
--

INSERT INTO `terms` (`term_id`, `term_title`, `term_link`, `term_description`) VALUES
(1, 'Terms And Conditions', 'terms', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Why do we use it? It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Where does it come from? Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.'),
(2, 'Refund Policies', 'refund', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Why do we use it? It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Where does it come from? Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.'),
(3, 'Pricing And Promotions Policy', 'pricing', 'It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Why do we use it? It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using \'Content here, content here\', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for \'lorem ipsum\' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like). Where does it come from? Contrary to popular belief, Lorem Ipsum is not simply random text. It has roots in a piece of classical Latin literature from 45 BC, making it over 2000 years old. Richard McClintock, a Latin professor at Hampden-Sydney College in Virginia, looked up one of the more obscure Latin words, consectetur, from a Lorem Ipsum passage, and going through the cites of the word in classical literature, discovered the undoubtable source. Lorem Ipsum comes from sections 1.10.32 and 1.10.33 of \"de Finibus Bonorum et Malorum\" (The Extremes of Good and Evil) by Cicero, written in 45 BC. This book is a treatise on the theory of ethics, very popular during the Renaissance. The first line of Lorem Ipsum, \"Lorem ipsum dolor sit amet..\", comes from a line in section 1.10.32. The standard chunk of Lorem Ipsum used since the 1500s is reproduced below for those interested. Sections 1.10.32 and 1.10.33 from \"de Finibus Bonorum et Malorum\" by Cicero are also reproduced in their exact original form, accompanied by English versions from the 1914 translation by H. Rackham.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `adds`
--
ALTER TABLE `adds`
  ADD PRIMARY KEY (`add_id`);

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `buyer_requests`
--
ALTER TABLE `buyer_requests`
  ADD PRIMARY KEY (`request_id`);

--
-- Indexes for table `buyer_reviews`
--
ALTER TABLE `buyer_reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `cart`
--
ALTER TABLE `cart`
  ADD PRIMARY KEY (`cart_id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`cat_id`);

--
-- Indexes for table `categories_childs`
--
ALTER TABLE `categories_childs`
  ADD PRIMARY KEY (`child_id`);

--
-- Indexes for table `contact_support`
--
ALTER TABLE `contact_support`
  ADD PRIMARY KEY (`contact_id`);

--
-- Indexes for table `coupons`
--
ALTER TABLE `coupons`
  ADD PRIMARY KEY (`coupon_id`);

--
-- Indexes for table `delivery_times`
--
ALTER TABLE `delivery_times`
  ADD PRIMARY KEY (`delivery_id`);

--
-- Indexes for table `enquiry_types`
--
ALTER TABLE `enquiry_types`
  ADD PRIMARY KEY (`enquiry_id`);

--
-- Indexes for table `favorites`
--
ALTER TABLE `favorites`
  ADD PRIMARY KEY (`favourite_id`);

--
-- Indexes for table `featured_proposals`
--
ALTER TABLE `featured_proposals`
  ADD PRIMARY KEY (`featured_id`);

--
-- Indexes for table `footer_links`
--
ALTER TABLE `footer_links`
  ADD PRIMARY KEY (`link_id`);

--
-- Indexes for table `general_settings`
--
ALTER TABLE `general_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `hide_seller_messages`
--
ALTER TABLE `hide_seller_messages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `home_section`
--
ALTER TABLE `home_section`
  ADD PRIMARY KEY (`section_id`);

--
-- Indexes for table `inbox_messages`
--
ALTER TABLE `inbox_messages`
  ADD PRIMARY KEY (`message_id`);

--
-- Indexes for table `inbox_sellers`
--
ALTER TABLE `inbox_sellers`
  ADD PRIMARY KEY (`inbox_seller_id`);

--
-- Indexes for table `languages_relation`
--
ALTER TABLE `languages_relation`
  ADD PRIMARY KEY (`relation_id`);

--
-- Indexes for table `messages_offers`
--
ALTER TABLE `messages_offers`
  ADD PRIMARY KEY (`offer_id`);

--
-- Indexes for table `my_buyers`
--
ALTER TABLE `my_buyers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `my_sellers`
--
ALTER TABLE `my_sellers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications`
--
ALTER TABLE `notifications`
  ADD PRIMARY KEY (`notification_id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`);

--
-- Indexes for table `order_conversations`
--
ALTER TABLE `order_conversations`
  ADD PRIMARY KEY (`c_id`);

--
-- Indexes for table `payment_settings`
--
ALTER TABLE `payment_settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `proposals`
--
ALTER TABLE `proposals`
  ADD PRIMARY KEY (`proposal_id`);

--
-- Indexes for table `proposal_modifications`
--
ALTER TABLE `proposal_modifications`
  ADD PRIMARY KEY (`modification_id`);

--
-- Indexes for table `purchases`
--
ALTER TABLE `purchases`
  ADD PRIMARY KEY (`purchase_id`);

--
-- Indexes for table `recent_proposals`
--
ALTER TABLE `recent_proposals`
  ADD PRIMARY KEY (`recent_id`);

--
-- Indexes for table `referrals`
--
ALTER TABLE `referrals`
  ADD PRIMARY KEY (`referral_id`);

--
-- Indexes for table `revenues`
--
ALTER TABLE `revenues`
  ADD PRIMARY KEY (`revenue_id`);

--
-- Indexes for table `section_boxes`
--
ALTER TABLE `section_boxes`
  ADD PRIMARY KEY (`box_id`);

--
-- Indexes for table `sellers`
--
ALTER TABLE `sellers`
  ADD PRIMARY KEY (`seller_id`);

--
-- Indexes for table `seller_accounts`
--
ALTER TABLE `seller_accounts`
  ADD PRIMARY KEY (`account_id`);

--
-- Indexes for table `seller_languages`
--
ALTER TABLE `seller_languages`
  ADD PRIMARY KEY (`language_id`);

--
-- Indexes for table `seller_levels`
--
ALTER TABLE `seller_levels`
  ADD PRIMARY KEY (`level_id`);

--
-- Indexes for table `seller_reviews`
--
ALTER TABLE `seller_reviews`
  ADD PRIMARY KEY (`review_id`);

--
-- Indexes for table `seller_skills`
--
ALTER TABLE `seller_skills`
  ADD PRIMARY KEY (`skill_id`);

--
-- Indexes for table `send_offers`
--
ALTER TABLE `send_offers`
  ADD PRIMARY KEY (`offer_id`);

--
-- Indexes for table `skills_relation`
--
ALTER TABLE `skills_relation`
  ADD PRIMARY KEY (`relation_id`);

--
-- Indexes for table `slider`
--
ALTER TABLE `slider`
  ADD PRIMARY KEY (`slide_id`);

--
-- Indexes for table `support_tickets`
--
ALTER TABLE `support_tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `terms`
--
ALTER TABLE `terms`
  ADD PRIMARY KEY (`term_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `adds`
--
ALTER TABLE `adds`
  MODIFY `add_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `buyer_requests`
--
ALTER TABLE `buyer_requests`
  MODIFY `request_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=57;

--
-- AUTO_INCREMENT for table `buyer_reviews`
--
ALTER TABLE `buyer_reviews`
  MODIFY `review_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `cart`
--
ALTER TABLE `cart`
  MODIFY `cart_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `cat_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `categories_childs`
--
ALTER TABLE `categories_childs`
  MODIFY `child_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=95;

--
-- AUTO_INCREMENT for table `contact_support`
--
ALTER TABLE `contact_support`
  MODIFY `contact_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `coupons`
--
ALTER TABLE `coupons`
  MODIFY `coupon_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `delivery_times`
--
ALTER TABLE `delivery_times`
  MODIFY `delivery_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `enquiry_types`
--
ALTER TABLE `enquiry_types`
  MODIFY `enquiry_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `favorites`
--
ALTER TABLE `favorites`
  MODIFY `favourite_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `featured_proposals`
--
ALTER TABLE `featured_proposals`
  MODIFY `featured_id` int(10) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `footer_links`
--
ALTER TABLE `footer_links`
  MODIFY `link_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `general_settings`
--
ALTER TABLE `general_settings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `hide_seller_messages`
--
ALTER TABLE `hide_seller_messages`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `home_section`
--
ALTER TABLE `home_section`
  MODIFY `section_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `inbox_messages`
--
ALTER TABLE `inbox_messages`
  MODIFY `message_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `inbox_sellers`
--
ALTER TABLE `inbox_sellers`
  MODIFY `inbox_seller_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `languages_relation`
--
ALTER TABLE `languages_relation`
  MODIFY `relation_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=20;

--
-- AUTO_INCREMENT for table `messages_offers`
--
ALTER TABLE `messages_offers`
  MODIFY `offer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `my_buyers`
--
ALTER TABLE `my_buyers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;

--
-- AUTO_INCREMENT for table `my_sellers`
--
ALTER TABLE `my_sellers`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;

--
-- AUTO_INCREMENT for table `notifications`
--
ALTER TABLE `notifications`
  MODIFY `notification_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=46;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=28;

--
-- AUTO_INCREMENT for table `order_conversations`
--
ALTER TABLE `order_conversations`
  MODIFY `c_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=44;

--
-- AUTO_INCREMENT for table `payment_settings`
--
ALTER TABLE `payment_settings`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `proposals`
--
ALTER TABLE `proposals`
  MODIFY `proposal_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

--
-- AUTO_INCREMENT for table `proposal_modifications`
--
ALTER TABLE `proposal_modifications`
  MODIFY `modification_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `purchases`
--
ALTER TABLE `purchases`
  MODIFY `purchase_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `recent_proposals`
--
ALTER TABLE `recent_proposals`
  MODIFY `recent_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=181;

--
-- AUTO_INCREMENT for table `referrals`
--
ALTER TABLE `referrals`
  MODIFY `referral_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `revenues`
--
ALTER TABLE `revenues`
  MODIFY `revenue_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `section_boxes`
--
ALTER TABLE `section_boxes`
  MODIFY `box_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT for table `sellers`
--
ALTER TABLE `sellers`
  MODIFY `seller_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

--
-- AUTO_INCREMENT for table `seller_accounts`
--
ALTER TABLE `seller_accounts`
  MODIFY `account_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `seller_languages`
--
ALTER TABLE `seller_languages`
  MODIFY `language_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seller_levels`
--
ALTER TABLE `seller_levels`
  MODIFY `level_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `seller_reviews`
--
ALTER TABLE `seller_reviews`
  MODIFY `review_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `seller_skills`
--
ALTER TABLE `seller_skills`
  MODIFY `skill_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;

--
-- AUTO_INCREMENT for table `send_offers`
--
ALTER TABLE `send_offers`
  MODIFY `offer_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `skills_relation`
--
ALTER TABLE `skills_relation`
  MODIFY `relation_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `slider`
--
ALTER TABLE `slider`
  MODIFY `slide_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `support_tickets`
--
ALTER TABLE `support_tickets`
  MODIFY `ticket_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- AUTO_INCREMENT for table `terms`
--
ALTER TABLE `terms`
  MODIFY `term_id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
