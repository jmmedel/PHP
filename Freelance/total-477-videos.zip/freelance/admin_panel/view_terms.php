<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{


?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Terms

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Terms

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="row"><!--- row Starts --->

<?php

$get_terms = "select * from terms";

$run_terms = mysqli_query($con,$get_terms);

while($row_terms = mysqli_fetch_array($run_terms)){

$term_id = $row_terms['term_id'];

$term_title = $row_terms['term_title'];

$term_description = substr($row_terms['term_description'],0,300);

?>

<div class="col-lg-4 col-md-6 mb-3"><!--- col-lg-4 col-md-6 mb-3 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="text-center">

<?php echo $term_title; ?>

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<p><?php echo $term_description; ?></p>

</div><!--- card-body Ends --->

<div class="card-footer"><!--- card-footer Starts --->

<a href="index.php?delete_term=<?php echo $term_id; ?>" class="float-left">

<i class="fa fa-trash-alt"></i> Delete

</a>


<a href="index.php?edit_term=<?php echo $term_id; ?>" class="float-right">

<i class="fa fa-pencil-alt"></i> Edit

</a>

<div class="clearfix"></div>

</div><!--- card-footer Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-4 col-md-6 mb-3 Ends --->

<?php } ?>

</div><!--- row Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->



<?php } ?>