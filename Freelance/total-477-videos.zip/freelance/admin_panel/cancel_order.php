<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<?php

if(isset($_GET['cancel_order'])){
	
$order_id = $_GET['cancel_order'];


$update_order = "update orders set order_active='no',order_status='cancelled' where order_id='$order_id'";
	
$run_order = mysqli_query($con,$update_order);
	
if($run_order){
	
$sel_orders = "select * from orders where order_id='$order_id'";

$run_orders= mysqli_query($con,$sel_orders);
	
$row_orders = mysqli_fetch_array($run_orders);
	
$seller_id = $row_orders['seller_id'];

$buyer_id = $row_orders['buyer_id'];

$order_price = $row_orders['order_price'];

$order_number = $row_orders['order_number'];
	
	
$message = "Order Cancelled By Customer Support";
	
date_default_timezone_set("Asia/Karachi");
	
$date = date("h:i: M d, Y");
	
$purchase_date = date("F d, Y");
	
	
$insert_purchase = "insert into purchases (seller_id,order_id,amount,date,method) values ('$buyer_id','$order_id','$order_price','$purchase_date','order_cancellation')";
	
$run_purchase = mysqli_query($con,$insert_purchase);
	
	
$insert_order_conversation = "insert into order_conversations (order_id,sender_id,message,file,date,status) values ('$order_id','$buyer_id','$message','','$date','cancelled_by_customer_support')";
	
$run_order_conversation = mysqli_query($con,$insert_order_conversation);
	

$insert_notification = "insert into notifications (receiver_id,sender_id,order_id,reason,date,status) values ('$seller_id','$buyer_id','$order_id','cancelled_by_customer_support','$date','unread')";
	
$run_notification = mysqli_query($con,$insert_notification);
	

$update_balance = "update seller_accounts set used_purchases=used_purchases-$order_price,current_balance=current_balance+$order_price where seller_id='$buyer_id'";
	
$run_balance = mysqli_query($con,$update_balance);	

if($run_balance){
	
echo "<script>alert('Order #$order_number Has been Cancelled, Order Amount Successfully Return To Buyer Shopping Balance.');</script>";
	
echo "<script>window.open('index.php?view_orders','_self');</script>";
	
	
}
	
	
}
	
	
}

?>

<?php } ?>