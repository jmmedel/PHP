<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{


?>


<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Referrals

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Referrals

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-bordered table-hover"><!--- table table-bordered table-hover Starts --->

<thead><!--- thead Starts --->

<tr>

<th>No:</th>

<th>Username:</th>

<th>Referred:</th>

<th>Money / Comission:</th>

<th> Ip Address :</th>

<th> Sign Up Date :</th>

<th> Status :</th>

<th> Actions: </th>

</tr>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php

$i = 0;

$get_referrals = "select * from referrals where status='pending'";

$run_referrals = mysqli_query($con,$get_referrals);

while($row_referrals = mysqli_fetch_array($run_referrals)){

$referral_id = $row_referrals['referral_id'];

$seller_id = $row_referrals['seller_id'];

$referred_id = $row_referrals['referred_id'];

$comission = $row_referrals['comission'];

$date = $row_referrals['date'];

$ip = $row_referrals['ip'];

$status = $row_referrals['status'];


$get_seller = "select * from sellers where seller_id='$seller_id'";
	
$run_seller = mysqli_query($con,$get_seller);
	
$row_seller = mysqli_fetch_array($run_seller);
	
$seller_user_name = $row_seller['seller_user_name'];


$sel_referred = "select * from sellers where seller_id='$referred_id'";

$run_referred = mysqli_query($con,$sel_referred);

$row_referred = mysqli_fetch_array($run_referred);

$referred_user_name = $row_referred['seller_user_name'];


$i++;

?>

<tr>

<td><?php echo $i; ?></td>

<td><?php echo $seller_user_name; ?></td>

<td><?php echo $referred_user_name; ?></td>

<td>$<?php echo $comission; ?></td>

<td><?php echo $ip; ?></td>

<td><?php echo $date; ?></td>

<td><?php echo $status; ?></td>

<td>

<div class="dropdown"><!--- dropdown Starts --->

<button class="btn btn-success dropdown-toggle" data-toggle="dropdown">

Actions

</button>

<div class="dropdown-menu">

<a class="dropdown-item" href="index.php?approve_referral=<?php echo $referral_id; ?>" onclick="return confirm('Do You Really Want To Approve This Referral And add $<?php echo $comission; ?>.00 to <?php echo $seller_user_name; ?> Balance.');">

<i class="fa fa-thumbs-up"></i> Approve Referral

</a>


<a class="dropdown-item" href="index.php?decline_referral=<?php echo $referral_id; ?>" onclick="return confirm('Do You Really Want To Decline This Referral After Declination Referral Commission Wil Not Be Given To <?php echo $seller_user_name; ?>.');">

<i class="fa fa-ban"></i> Decline Referral

</a>


</div>

</div><!--- dropdown Ends --->

</td>

</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-bordered table-hover Ends --->

</div><!--- table-responsive Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php } ?>