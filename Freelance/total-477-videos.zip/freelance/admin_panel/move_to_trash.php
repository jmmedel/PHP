<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<?php

if(isset($_GET['move_to_trash'])){
	
$trash_id = $_GET['move_to_trash'];
	
$update_proposal = "update proposals set proposal_status='trash' where proposal_id='$trash_id'";
	
$run_proposal = mysqli_query($con,$update_proposal);
	
if($run_proposal){
	
echo "<script>alert('One Proposal Has Been Moved To Trash.');</script>";
	
echo "<script>window.open('index.php?view_proposals_trash','_self');</script>";
	
}

	
}

?>

<?php } ?>