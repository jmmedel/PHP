<?php

session_start();

include("includes/db.php");

if(isset($_SESSION['admin_email'])){
	
echo "<script>window.open('index.php?dashboard','_self');</script>";
	
}

?>
<!DOCTYPE HTML>

<html>

<head>

<title> Admin Login </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="css/bootstrap.min.css">

<link rel="stylesheet" href="css/login.css">

</head>

<body>

<div class="container"><!-- container Starts --->

<?php if(isset($_GET['session_expired'])){ ?>

<div class="offset-md-3 col-lg-6 col-md-6"><!--- offset-md-3 col-lg-6 col-md-6 Starts --->

<div class="alert alert-danger alert-dismissible fade show"><!--- alert alert-danger alert-dismissible fade show Starts -->

<button type="button" class="close" data-dismiss="alert">

<span>&times;</span>

</button>

<strong> Your Session Expired. </strong>  Please Login Again.

</div><!--- alert alert-danger alert-dismissible fade show Ends -->

</div><!--- offset-md-3 col-lg-6 col-md-6 Ends --->

<?php } ?>

<form class="form-login" action="" method="post"><!-- form-login Starts --->

<h2 class="form-login-heading mb-3"> Admin Login </h2>

<input type="text" class="form-control" name="admin_email" placeholder="Email Adress">

<input type="password" class="form-control" name="admin_pass" placeholder="Password">

<button class="btn btn-lg btn-primary btn-block" type="submit" name="admin_login">

Login

</button>

</form><!-- form-login Ends --->


</div><!-- container Ends --->

<script src="js/jquery.min.js"> </script>

<script src="js/popper.min.js"> </script>

<script src="js/bootstrap.min.js"> </script>

</body>

</html>

<?php

if(isset($_POST['admin_login'])){
	
$admin_email = mysqli_real_escape_string($con,$_POST['admin_email']);

$admin_pass = mysqli_real_escape_string($con,$_POST['admin_pass']);
	
$select_admins = "select * from admins where admin_email='$admin_email'";
	
$run_admins = mysqli_query($con,$select_admins);
	
$row_admins = mysqli_fetch_array($run_admins);
	
$hash_password = $row_admins['admin_pass'];
	
$decrypt_password = password_verify($admin_pass, $hash_password);
	
	
if($decrypt_password == 0){
	
echo "<script>alert(' Email Or Password Is Wrong, Please Try Again');</script>";
	
}else{
	
$get_admin = "select * from admins where admin_email='$admin_email' AND admin_pass='$hash_password'";
	
$run_admin = mysqli_query($con,$get_admin);
	
if($run_admin){
	
$_SESSION['admin_email'] = $admin_email;

$_SESSION['loggedin_time'] = time();

echo "<script>alert('You are Logged in into admin panel');</script>";

echo "<script>window.open('index.php?dashboard','_self');</script>";

	
}
	
	
}
	
	
	
}


?>



