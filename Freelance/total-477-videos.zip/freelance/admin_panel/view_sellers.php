<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>


<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Sellers

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-body"><!--- card-body Starts --->

<?php 

$get_sellers = "select * from sellers";

$run_sellers = mysqli_query($con,$get_sellers);

$count_sellers = mysqli_num_rows($run_sellers);

?>

<h4 class="mb-4">

Sellers Summary

<small>All Sellers (<?php echo $count_sellers; ?>)</small>

</h4>

<div class="row"><!--- row Starts --->


<div class="text-center border-box col-md-3"><!---- text-center border-box col-md-3 Starts --->

<p> Top Rated Sellers </p>

<?php 

$get_sellers = "select * from sellers where seller_level='4'";

$run_sellers = mysqli_query($con,$get_sellers);

$count_sellers = mysqli_num_rows($run_sellers);

?>

<h2><?php echo $count_sellers; ?></h2>

</div><!---- text-center border-box col-md-3 Ends --->




<div class="text-center border-box col-md-3"><!---- text-center border-box col-md-3 Starts --->

<p> Level Two Sellers </p>

<?php 

$get_sellers = "select * from sellers where seller_level='3'";

$run_sellers = mysqli_query($con,$get_sellers);

$count_sellers = mysqli_num_rows($run_sellers);

?>

<h2><?php echo $count_sellers; ?></h2>

</div><!---- text-center border-box col-md-3 Ends --->



<div class="text-center border-box col-md-3"><!---- text-center border-box col-md-3 Starts --->

<p> Level One Sellers </p>

<?php 

$get_sellers = "select * from sellers where seller_level='2'";

$run_sellers = mysqli_query($con,$get_sellers);

$count_sellers = mysqli_num_rows($run_sellers);

?>

<h2><?php echo $count_sellers; ?></h2>

</div><!---- text-center border-box col-md-3 Ends --->




<div class="text-center col-md-3"><!---- text-center col-md-3 Starts --->

<p> New Sellers </p>

<?php 

$get_sellers = "select * from sellers where seller_level='1'";

$run_sellers = mysqli_query($con,$get_sellers);

$count_sellers = mysqli_num_rows($run_sellers);

?>

<h2><?php echo $count_sellers; ?></h2>

</div><!---- text-center col-md-3 Ends --->


</div><!--- row Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->



<div class="row mt-4"><!--- 3 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt"></i> View Sellers

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-bordered table-hover"><!--- table table-bordered table-hover Starts --->

<thead><!--- thead Starts --->

<tr>

<th>Seller No</th>

<th>Seller Username</th>

<th>Seller Email</th>

<th>Seller Level</th>

<th>Seller Register Date</th>

<th>Actions</th>

</tr>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php

$i = 0;

$per_page = 7;

$get_sellers = "select * from sellers order by 1 DESC LIMIT 0,$per_page";

$run_sellers = mysqli_query($con,$get_sellers);

while($row_sellers = mysqli_fetch_array($run_sellers)){

$seller_id = $row_sellers['seller_id'];

$seller_user_name = $row_sellers['seller_user_name'];

$seller_email = $row_sellers['seller_email'];

$seller_level = $row_sellers['seller_level'];

$seller_register_date = $row_sellers['seller_register_date'];

$seller_status = $row_sellers['seller_status'];


$get_seller_levels = "select * from seller_levels where level_id='$seller_level'";

$run_seller_levels = mysqli_query($con,$get_seller_levels);

$row_seller_levels = mysqli_fetch_array($run_seller_levels);
	
$level_title = $row_seller_levels['level_title'];

$i++;


?>

<tr>

<td><?php echo $i; ?></td>

<td><?php echo $seller_user_name; ?></td>

<td><?php echo $seller_email; ?></td>

<td><?php echo $level_title; ?></td>

<td><?php echo $seller_register_date; ?></td>

<td>

<div class="dropdown"><!--- dropdown Starts --->

<button class="btn btn-success dropdown-toggle" type="button" data-toggle="dropdown">

Actions

</button>


<div class="dropdown-menu"><!--- dropdown-menu Starts --->

<a class="dropdown-item" href="index.php?single_seller=<?php echo $seller_id; ?>">

<i class="fa fa-info-circle"></i> View Seller Full Details

</a>


<a class="dropdown-item" href="index.php?seller_login=<?php echo $seller_user_name; ?>">

<i class="fa fa-sign-in-alt"></i> Login As <?php echo $seller_user_name; ?>

</a>


<?php if($seller_status == "block-ban"){ ?>

<a class="dropdown-item" href="index.php?unblock_seller=<?php echo $seller_id; ?>">

<i class="fa fa-unlock"></i> Already Banned , Unblock Seller

</a>

<?php }else{ ?>

<a class="dropdown-item" href="index.php?ban_seller=<?php echo $seller_id; ?>">

<i class="fa fa-ban"></i> Block / Ban Seller

</a>

<?php } ?>

</div><!--- dropdown-menu Ends --->


</div><!--- dropdown Ends --->

</td>

</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-bordered table-hover Ends --->

</div><!--- table-responsive Ends --->


<div class="d-flex justify-content-center"><!--- d-flex justify-content-center Starts --->

<ul class="pagination"><!--- pagination Starts --->

<?php

/// Now Select All From Proposals Table

$query = "select * from sellers order by 1 DESC";

$result = mysqli_query($con,$query);

/// Count The Total Records 

$total_records = mysqli_num_rows($result);

/// Using ceil function to divide the total records on per page

$total_pages = ceil($total_records / $per_page);

echo "

<li class='page-item'>

<a href='index.php?sellers_pagination=1' class='page-link'> First Page </a>

</li>

";

for($i=1; $i<=$total_pages; $i++){
	
echo "

<li class='page-item'>

<a href='index.php?sellers_pagination=".$i."' class='page-link'>".$i."</a>

</li>

";
		
}

echo "

<li class='page-item'>

<a href='index.php?sellers_pagination=$total_pages' class='page-link'> Last Page </a>

</li>

";


?>

</ul><!--- pagination Ends --->

</div><!--- d-flex justify-content-center Ends --->


</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 3 row Ends --->




<?php } ?>