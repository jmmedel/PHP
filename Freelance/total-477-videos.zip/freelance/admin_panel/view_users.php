<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Users

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts ---> 

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt"> </i> View Users

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-bordered table-hover"><!--- table table-bordered table-hover Starts --->

<thead><!--- thead Starts --->

<tr>

<th>User Name:</th>

<th>User Email:</th>

<th>User Image:</th>

<th>User Country:</th>

<th>User Job:</th>

<th>Delete User:</th>

</tr>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php

$get_admins = "select * from admins";

$run_admins = mysqli_query($con,$get_admins);

while($row_admins = mysqli_fetch_array($run_admins)){

$admin_id = $row_admins['admin_id'];

$admin_name = $row_admins['admin_name'];

$admin_email = $row_admins['admin_email'];

$admin_image = $row_admins['admin_image'];

$admin_country = $row_admins['admin_country'];

$admin_job = $row_admins['admin_job'];

?>

<tr>

<td><?php echo $admin_name; ?></td>

<td><?php echo $admin_email; ?></td>

<td><img src="admin_images/<?php echo $admin_image; ?>" width="60" height="60"></td>

<td><?php echo $admin_country; ?></td>

<td><?php echo $admin_job; ?></td>

<td>

<?php if($login_admin_id == $admin_id){ ?>

You Can Not Delete Yourself.

<?php }else{ ?>

<a href="index.php?delete_user=<?php echo $admin_id; ?>">

<i class="fa fa-trash-alt"></i> Delete

</a>

<?php } ?>

</td>

</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-bordered table-hover Ends --->

</div><!--- table-responsive Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends ---> 

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->



<?php } ?>