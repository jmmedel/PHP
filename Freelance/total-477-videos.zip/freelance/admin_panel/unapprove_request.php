<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<?php 

if(isset($_GET['unapprove_request'])){
	
$request_id = $_GET['unapprove_request'];
	
$update_request = "update buyer_requests set request_status='unapproved' where request_id='$request_id'";
	
$run_request = mysqli_query($con,$update_request);
	
if($run_request){
	
echo "<script>alert('One Request Has been Unapproved.');</script>";
	
echo "<script>window.open('index.php?buyer_requests','_self');</script>";
	
}
	
	
}

?>

<?php } ?>