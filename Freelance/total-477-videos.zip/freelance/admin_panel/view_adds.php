<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	
?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Adds

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4"> 

<i class="fa fa-money-bill-alt"></i> View Adds

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-bordered table-hover"><!--- table table-bordered table-hover Starts ---> 

<thead>

<tr>

<th>Add Id</th>

<th>Add Title</th>

<th>Add Place</th>

<th>Add Actions</th>

</tr>

</thead>

<tbody>

<?php

$i = 0;

$get_adds = "select * from adds";

$run_adds = mysqli_query($con,$get_adds);

while($row_adds = mysqli_fetch_array($run_adds)){

$add_id = $row_adds['add_id'];

$add_title = $row_adds['add_title'];

$add_place = $row_adds['add_place'];

$i++;

?>

<tr>

<td><?php echo $i; ?></td>

<td><?php echo $add_title; ?></td>

<td>

<?php if($add_place == "dashboard_sidebar"){ ?>

Dashboard Sidebar

<?php } ?>

</td>

<td>

<a href="index.php?edit_add=<?php echo $add_id; ?>">

<i class="fa fa-pencil-alt"></i> Edit

</a>

</td>

</tr>

<?php } ?>

</tbody>

</table><!--- table table-bordered table-hover Ends ---> 

</div><!--- table-responsive Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->





<?php } ?>