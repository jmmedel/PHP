<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<?php

if(isset($_GET['edit_term'])){
	
$edit_id = $_GET['edit_term'];
	
$edit_term = "select * from terms where term_id='$edit_id'";
	
$run_edit = mysqli_query($con,$edit_term);
	
$row_edit = mysqli_fetch_array($run_edit);
	
$term_id = $row_edit['term_id'];

$term_title = $row_edit['term_title'];

$term_description = $row_edit['term_description'];

$term_link = $row_edit['term_link'];
	
	
}
 
?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Edit Term

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Edit Term

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Term Title : </label>

<div class="col-md-6">

<input type="text" name="term_title" class="form-control" required value="<?php echo $term_title; ?>">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Term Description : </label>

<div class="col-md-6">

<textarea class="form-control" name="term_desc" rows="7" required><?php echo $term_description; ?></textarea>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Term Link : </label>

<div class="col-md-6">

<input type="text" name="term_link" class="form-control" required value="<?php echo $term_link; ?>">

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="update" class="btn btn-primary form-control" value="Update Term">

</div>

</div><!--- form-group row Ends --->



</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->

<?php

if(isset($_POST['update'])){
	
$term_title = mysqli_real_escape_string($con,$_POST['term_title']);

$term_desc = mysqli_real_escape_string($con,$_POST['term_desc']);

$term_link = mysqli_real_escape_string($con,$_POST['term_link']);
	
$update_term = "update terms set term_title='$term_title',term_link='$term_link',term_description='$term_desc' where term_id='$term_id'";
	
$run_term = mysqli_query($con,$update_term);
	
if($run_term){
	
echo "<script>alert('One Term has been Updated.');</script>";
	
echo "<script>window.open('index.php?view_terms','_self');</script>";
	
}
	
	
	
}


?>

<?php } ?>