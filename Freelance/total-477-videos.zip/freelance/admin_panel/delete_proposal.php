<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<?php

if(isset($_GET['delete_proposal'])){
	
$delete_id = $_GET['delete_proposal'];
	
$delete_proposal = "delete from proposals where proposal_id='$delete_id'";
	
$run_proposal = mysqli_query($con,$delete_proposal);
	
if($run_proposal){
	
echo "<script>alert('One Proposal Has Been Delete Permanently.');</script>";
	
echo "<script>window.open('index.php?view_proposals','_self');</script>";
	
}

	
}

?>

<?php } ?>