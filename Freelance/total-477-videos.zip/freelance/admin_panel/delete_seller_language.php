<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<?php

if(isset($_GET['delete_seller_language'])){
	
$language_id = $_GET['delete_seller_language'];


$delete_languages_relation = "delete from languages_relation where language_id='$language_id'";

$run_delete_languages_relation = mysqli_query($con,$delete_languages_relation);


$delete_seller_language = "delete from seller_languages where language_id='$language_id'";

$run_delete = mysqli_query($con,$delete_seller_language);

if($run_delete){
	
echo "<script>alert('One Seller Language Has Been Deleted.');</script>";
	
echo "<script>window.open('index.php?view_seller_languages','_self');</script>";
	
	
}

	
}


?>

<?php } ?>