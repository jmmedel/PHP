<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<?php

if(isset($_GET['edit_enquiry_type'])){
	
$edit_id = $_GET['edit_enquiry_type'];
	
$edit_enquiry_type = "select * from enquiry_types where enquiry_id='$edit_id'";
	
$run_edit = mysqli_query($con,$edit_enquiry_type);
	
$row_edit = mysqli_fetch_array($run_edit);
	
$enquiry_id = $row_edit['enquiry_id'];

$enquiry_title = $row_edit['enquiry_title'];

	
}

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Edit Enquiry Type

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Edit Enquiry Type

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Enquiry Type Title : </label>

<div class="col-md-6">

<input type="text" name="enquiry_title" class="form-control" value="<?php echo $enquiry_title; ?>" required>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="update" class="btn btn-primary form-control" value="Update Enquiry Type">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['update'])){
	
$enquiry_title = mysqli_real_escape_string($con,$_POST['enquiry_title']);
	
$update_enquiry_type = "update enquiry_types set enquiry_title='$enquiry_title' where enquiry_id='$enquiry_id'";
	
$run_enquiry_type = mysqli_query($con,$update_enquiry_type);
	
if($run_enquiry_type){
	
echo "<script>alert('One Enquiry Type Has been Updated.');</script>";
	
echo "<script>window.open('index.php?view_enquiry_types','_self');</script>";

	
}
	
	
}

?>

<?php } ?>