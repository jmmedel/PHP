<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<?php

if(isset($_GET['seller_login'])){
	
$seller_user_name = $_GET['seller_login'];

$_SESSION['seller_user_name']=$seller_user_name;

echo "<script>alert('You are Logged In to $seller_user_name Computerfever Account.');</script>";
	
echo "<script>window.open('../index.php','_self');</script>";
	
}

?>

<?php } ?>