<?php

session_start();

include("../includes/db.php");

if(!isset($_SESSION['seller_user_name'])){
	
echo "<script>window.open('../login.php','_self')</script>";
	
}

$login_seller_user_name = $_SESSION['seller_user_name'];

$select_login_seller = "select * from sellers where seller_user_name='$login_seller_user_name'";

$run_login_seller = mysqli_query($con,$select_login_seller);

$row_login_seller = mysqli_fetch_array($run_login_seller);

$login_seller_id = $row_login_seller['seller_id'];

$login_seller_vacation = $row_login_seller['seller_vacation'];

?>
<!DOCTYPE html>

<html>

<head>

<title> Computerfever / View Proposals </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="description" content="Computerfever is the world's largest freelance services marketplace for lean entrepreneurs to focus on growth & create a successful business at affordable costs.">

<meta name="keywords" content="freelance,freelancers,jobs,proposals,sellers,buyers">

<meta name="author" content="Mohammed Tahir Ahmed">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="../styles/bootstrap.min.css" rel="stylesheet">

<link href="../styles/style.css" rel="stylesheet">

<link href="../styles/user_nav_style.css" rel="stylesheet">

<link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet">

<link href="../styles/owl.carousel.css" rel="stylesheet">

<link href="../styles/owl.theme.default.css" rel="stylesheet">

<script src="../js/jquery.min.js"></script>

<script src="https://checkout.stripe.com/checkout.js"></script>

</head>

<body>

<?php include("../includes/user_header.php"); ?>

<div class="container-fluid view-proposals"><!-- container-fluid view-proposals Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-12 mt-5 mb-3"><!-- col-md-12 mt-5 mb-3 Starts -->

<h1 class="pull-left"> View Proposals </h1>

<label class="pull-right lead"><!-- pull-right lead Starts -->

Vacation Mode

<?php if($login_seller_vacation == "off"){ ?>

<button id="turn_on_seller_vaction" data-toggle="button" class="btn btn-lg btn-toggle">

<div class="toggle-handle"></div>

</button>

<?php }else{ ?>

<button id="turn_off_seller_vaction" data-toggle="button" class="btn btn-lg btn-toggle active">

<div class="toggle-handle"></div>

</button>

<?php } ?>

</label><!-- pull-right lead Ends -->

<script>

$(document).ready(function(){
	
	
$(document).on('click','#turn_on_seller_vaction', function(){
	
seller_id = "<?php echo $login_seller_id; ?>";
	
$.ajax({
	
method:"POST",

url: "seller_vacation.php",
	
data: { seller_id: seller_id, turn_on: 'on' }
	
}).done(function(){
	
$("#turn_on_seller_vaction").attr('id','turn_off_seller_vaction');
	
alert('Your Seller Vacation Mode Has Been Turned On');
	
});
	
	
});
	
	
$(document).on('click','#turn_off_seller_vaction', function(){
	
seller_id = "<?php echo $login_seller_id; ?>";
	
$.ajax({
	
method:"POST",

url: "seller_vacation.php",
	
data: { seller_id: seller_id, turn_off: 'off' }
	
}).done(function(){
	
$("#turn_off_seller_vaction").attr('id','turn_on_seller_vaction');
	
alert('Your Seller Vacation Mode Has Been Turned Off');
	
});
	
	
});

	
	
});

</script>

</div><!-- col-md-12 mt-5 mb-3 Ends -->

<div class="col-md-12"><!-- col-md-12 Starts -->

<a href="create_proposal.php" class="btn btn-success pull-right">
Add New Proposal
</a>

<div class="clearfix"></div>

<ul class="nav nav-tabs mt-3"><!-- nav nav-tabs mt-3 Starts -->

<?php

$select_proposals = "select * from proposals where proposal_seller_id='$login_seller_id' and proposal_status='active'";

$run_proposals = mysqli_query($con, $select_proposals);

$count_proposals = mysqli_num_rows($run_proposals);

?>

<li class="nav-item">

<a href="#active-proposals" data-toggle="tab" class="nav-link active">

Active <span class="badge badge-success"><?php echo $count_proposals; ?></span>

</a>

</li>

<?php

$select_proposals = "select * from proposals where proposal_seller_id='$login_seller_id' and proposal_status='pause'";

$run_proposals = mysqli_query($con, $select_proposals);

$count_proposals = mysqli_num_rows($run_proposals);

?>

<li class="nav-item">

<a href="#pause-proposals" data-toggle="tab" class="nav-link">

Paused <span class="badge badge-success"><?php echo $count_proposals; ?></span>

</a>

</li>

<?php

$select_proposals = "select * from proposals where proposal_seller_id='$login_seller_id' and proposal_status='pending'";

$run_proposals = mysqli_query($con, $select_proposals);

$count_proposals = mysqli_num_rows($run_proposals);

?>

<li class="nav-item">

<a href="#pending-proposals" data-toggle="tab" class="nav-link">

Pending Approval <span class="badge badge-success"><?php echo $count_proposals; ?></span>

</a>

</li>

<?php

$select_proposals = "select * from proposals where proposal_seller_id='$login_seller_id' and proposal_status='modification'";

$run_proposals = mysqli_query($con, $select_proposals);

$count_proposals = mysqli_num_rows($run_proposals);

?>

<li class="nav-item">

<a href="#modification-proposals" data-toggle="tab" class="nav-link">

Requires Modification <span class="badge badge-success"><?php echo $count_proposals; ?></span>

</a>

</li>

</ul><!-- nav nav-tabs mt-3 Ends -->

<div class="tab-content"><!-- tab-content Starts -->

<div id="active-proposals" class="tab-pane fade show active"><!-- active-proposals tab-pane fade show active Starts -->

<div class="table-responsive box-table mt-4"><!-- table-responsive box-table mt-4 Starts -->

<table class="table table-hover"><!-- table table-hover Starts -->

<thead>

<tr>

<th>Proposal Title</th>

<th>Proposal Price </th>

<th>Views</th>

<th>Orders</th>

<th>Actions</th>

</tr>

</thead>

<tbody>

<?php

$select_proposals = "select * from proposals where proposal_seller_id='$login_seller_id' and proposal_status='active'";

$run_proposals = mysqli_query($con, $select_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_views = $row_proposals['proposal_views'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_url = $row_proposals['proposal_url'];

$proposal_featured = $row_proposals['proposal_featured'];

$select_orders = "select * from orders where proposal_id='$proposal_id'";

$run_orders = mysqli_query($con,$select_orders);

$count_orders = mysqli_num_rows($run_orders);

?>

<tr>

<td class="proposal-title"> <?php echo $proposal_title; ?> </td>

<td class="text-success"> $<?php echo $proposal_price; ?> </td>

<td><?php echo $proposal_views; ?></td>

<td><?php echo $count_orders; ?></td>

<td>

<div class="dropdown"><!-- dropdown Starts -->

<button class="btn btn-success dropdown-toggle" data-toggle="dropdown"></button>

<div class="dropdown-menu"><!-- dropdown-menu Starts -->

<a href="<?php echo $proposal_url; ?>" class="dropdown-item"> Preview </a>

<?php if($proposal_featured == "no"){ ?>

<a href="#" class="dropdown-item" id="featured-button-<?php echo $proposal_id; ?>"> Featured Listing </a>

<?php }else{ ?>

<a href="#" class="dropdown-item bg-success active"> Already Featured </a>

<?php } ?>

<a href="pause_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Pause </a>

<a href="edit_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Edit </a>

<a href="delete_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Delete </a>

</div><!-- dropdown-menu Ends -->

</div><!-- dropdown Ends -->

<script>

$("#featured-button-<?php echo $proposal_id; ?>").click(function(){

proposal_id = "<?php echo $proposal_id; ?>";

$.ajax({
  method: "POST",
  url: "pay_featured_listing.php",
  data: {proposal_id: proposal_id }
})
.done(function(data){

$("#featured-proposal-modal").html(data);	
	
});	
	
	
});

</script>

</td>

</tr>

<?php } ?>

</tbody>

</table><!-- table table-hover Ends -->

</div><!-- table-responsive box-table mt-4 Ends -->

</div><!-- active-proposals tab-pane fade show active Ends -->

<div id="pause-proposals" class="tab-pane fade show"><!-- pause-proposals tab-pane fade show  Starts -->

<div class="table-responsive box-table mt-4"><!-- table-responsive box-table mt-4 Starts -->

<table class="table table-hover"><!-- table table-hover Starts -->

<thead>

<tr>

<th>Proposal Title</th>

<th>Proposal Price </th>

<th>Views</th>

<th>Orders</th>

<th>Actions</th>

</tr>

</thead>

<tbody>

<?php

$select_proposals = "select * from proposals where proposal_seller_id='$login_seller_id' and proposal_status='pause'";

$run_proposals = mysqli_query($con, $select_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_views = $row_proposals['proposal_views'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_url = $row_proposals['proposal_url'];

$proposal_featured = $row_proposals['proposal_featured'];

$select_orders = "select * from orders where proposal_id='$proposal_id'";

$run_orders = mysqli_query($con,$select_orders);

$count_orders = mysqli_num_rows($run_orders);

?>

<tr>

<td class="proposal-title"> <?php echo $proposal_title; ?> </td>

<td class="text-success"> $<?php echo $proposal_price; ?> </td>

<td><?php echo $proposal_views; ?></td>

<td><?php echo $count_orders; ?></td>

<td>

<div class="dropdown"><!-- dropdown Starts -->

<button class="btn btn-success dropdown-toggle" data-toggle="dropdown"></button>

<div class="dropdown-menu"><!-- dropdown-menu Starts -->

<a href="<?php echo $proposal_url; ?>" class="dropdown-item"> Preview </a>

<a href="activate_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Activate </a>

<a href="edit_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Edit </a>

<a href="delete_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Delete </a>

</div><!-- dropdown-menu Ends -->

</div><!-- dropdown Ends -->

</td>

</tr>

<?php } ?>

</tbody>

</table><!-- table table-hover Ends -->

</div><!-- table-responsive box-table mt-4 Ends -->

</div><!-- pause-proposals tab-pane fade show Ends -->


<div id="pending-proposals" class="tab-pane fade show"><!-- pending-proposals tab-pane fade show  Starts -->

<div class="table-responsive box-table mt-4"><!-- table-responsive box-table mt-4 Starts -->

<table class="table table-hover"><!-- table table-hover Starts -->

<thead>

<tr>

<th>Proposal Title</th>

<th>Proposal Price </th>

<th>Views</th>

<th>Orders</th>

<th>Actions</th>

</tr>

</thead>

<tbody>

<?php

$select_proposals = "select * from proposals where proposal_seller_id='$login_seller_id' and proposal_status='pending'";

$run_proposals = mysqli_query($con, $select_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_views = $row_proposals['proposal_views'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_url = $row_proposals['proposal_url'];

$proposal_featured = $row_proposals['proposal_featured'];

$select_orders = "select * from orders where proposal_id='$proposal_id'";

$run_orders = mysqli_query($con,$select_orders);

$count_orders = mysqli_num_rows($run_orders);

?>

<tr>

<td class="proposal-title"> <?php echo $proposal_title; ?> </td>

<td class="text-success"> $<?php echo $proposal_price; ?> </td>

<td><?php echo $proposal_views; ?></td>

<td><?php echo $count_orders; ?></td>

<td>

<div class="dropdown"><!-- dropdown Starts -->

<button class="btn btn-success dropdown-toggle" data-toggle="dropdown"></button>

<div class="dropdown-menu"><!-- dropdown-menu Starts -->

<a href="<?php echo $proposal_url; ?>" class="dropdown-item"> Preview </a>

<a href="edit_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Edit </a>

<a href="delete_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Delete </a>

</div><!-- dropdown-menu Ends -->

</div><!-- dropdown Ends -->

</td>

</tr>

<?php } ?>

</tbody>

</table><!-- table table-hover Ends -->

</div><!-- table-responsive box-table mt-4 Ends -->

</div><!-- pending-proposals tab-pane fade show Ends -->

<div id="modification-proposals" class="tab-pane fade show"><!-- modification-proposals tab-pane fade show  Starts -->

<div class="table-responsive box-table mt-4"><!-- table-responsive box-table mt-4 Starts -->

<table class="table table-hover"><!-- table table-hover Starts -->

<thead>

<tr>

<th>Modification Proposal</th>

<th>Modification Message</th>

<th>Actions</th>

</tr>

</thead>

<tbody>

<?php

$select_proposals = "select * from proposals where proposal_seller_id='$login_seller_id' and proposal_status='modification'";

$run_proposals = mysqli_query($con, $select_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_url = $row_proposals['proposal_url'];


$select_modification = "select * from proposal_modifications where proposal_id='$proposal_id'";

$run_modification = mysqli_query($con,$select_modification);

$row_modification = mysqli_fetch_array($run_modification);

$modification_message = $row_modification['modification_message'];


?>

<tr>

<td class="proposal-title"> <?php echo $proposal_title; ?> </td>

<td> <?php echo $modification_message; ?> </td>

<td>

<div class="dropdown"><!-- dropdown Starts -->

<button class="btn btn-success dropdown-toggle" data-toggle="dropdown"></button>

<div class="dropdown-menu"><!-- dropdown-menu Starts -->

<a href="submit_approval.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Submit For Approval </a>

<a href="<?php echo $proposal_url; ?>" class="dropdown-item"> Preview </a>

<a href="edit_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Edit </a>

<a href="delete_proposal.php?proposal_id=<?php echo $proposal_id; ?>" class="dropdown-item"> Delete </a>

</div><!-- dropdown-menu Ends -->

</div><!-- dropdown Ends -->

</td>

</tr>

<?php } ?>

</tbody>

</table><!-- table table-hover Ends -->

</div><!-- table-responsive box-table mt-4 Ends -->

</div><!-- modification-proposals tab-pane fade show Ends -->

</div><!-- tab-content Ends -->

</div><!-- col-md-12 Ends -->

</div><!-- row Ends -->

</div><!-- container-fluid view-proposals Ends -->

<div id="featured-proposal-modal"></div>

<?php include("../includes/footer.php"); ?>

</body>

</html>