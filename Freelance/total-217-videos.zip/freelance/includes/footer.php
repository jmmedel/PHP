
<div class="mt-2" id="footer"><!-- footer Starts -->

<div class="container"><!-- container Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Starts -->

<h4><strong> CATEGRIES </strong></h4>

<ul><!-- ul Starts -->

<li><a href="http://localhost/freelance/category.php?cat_id"> Graphics & Design </a></li>

<li><a href="http://localhost/freelance/category.php?cat_id"> Graphics & Design </a></li>

<li><a href="http://localhost/freelance/category.php?cat_id"> Graphics & Design </a></li>

<li><a href="http://localhost/freelance/category.php?cat_id"> Graphics & Design </a></li>

<li><a href="http://localhost/freelance/category.php?cat_id"> Graphics & Design </a></li>

<li><a href="http://localhost/freelance/category.php?cat_id"> Graphics & Design </a></li>


</ul><!-- ul Ends -->

</div><!-- col-md-3 col-sm-6 Ends -->


<div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Starts -->

<h4><strong> ABOUT </strong></h4>

<ul><!-- ul Starts -->

<li><a href="http://localhost/freelance/terms.php"> Terms And Conditions </a></li>


</ul><!-- ul Ends -->

</div><!-- col-md-3 col-sm-6 Ends -->


<div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Starts -->

<h4><strong> SUPPORT </strong></h4>

<ul><!-- ul Starts -->

<li><a href="http://localhost/freelance/contact.php"> Customer SUPPORT </a></li>


</ul><!-- ul Ends -->

</div><!-- col-md-3 col-sm-6 Ends -->


<div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Starts -->

<h4><strong> Follow Us </strong></h4>

<ul><!-- ul Starts -->

<li>

<a href="#"> <i class="fa fa-google-plus-official"></i> Google Plus </a>

</li>

<li>

<a href="#"> <i class="fa fa-twitter"></i> Twitter </a>

</li>

<li>

<a href="#"> <i class="fa fa-facebook"></i> Facebook </a>

</li>


<li>

<a href="#"> <i class="fa fa-linkedin"></i> Linkedin </a>

</li>


<li>

<a href="#"> <i class="fa fa-pinterest"></i> Pinterest </a>

</li>

</ul><!-- ul Ends -->

</div><!-- col-md-3 col-sm-6 Ends -->


</div><!-- row Ends -->

</div><!-- container Ends -->

</div><!-- footer Ends -->


<div id="copyright"><!-- copyright Starts -->


<div class="container"><!-- container Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-6"><!-- col-md-6 Starts -->

<p class="text-lg-left tex-center font-weight-bold">

&copy; ComputerFever Freelance Services LLC. All Rights Reserved.

</p>

</div><!-- col-md-6 Ends -->

<div class="col-md-6"><!-- col-md-6 Starts -->

<p class="text-lg-right text-center">

Template By 

<a class="text-white font-weight-bold" href="http://www.computerfever.com"> 

ComputerFever.com

</a>

</p>

</div><!-- col-md-6 Ends -->

</div><!-- row Ends -->

</div><!-- container Ends -->

</div><!-- copyright Ends -->









<script src="http://localhost/freelance/js/jquery.sticky.js"></script>

<script src="http://localhost/freelance/js/popper.min.js"></script>

<script src="http://localhost/freelance/js/bootstrap.min.js"></script>

<script src="http://localhost/freelance/js/owl.carousel.min.js"></script>

<script src="http://localhost/freelance/js/custom.js"></script>