
<?php

if($reason == "order"){
	
	echo "has just sent you an order.";
	
}

if($reason == "order_message"){
	
	echo "send message, updated your order.";
	
}

if($reason == "order_revision"){
	
	echo "requested revision on your order.";
	
}


if($reason == "order_completed"){
	
	echo "completed your order.";
	
}



?>