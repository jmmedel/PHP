
<?php

session_start();

include("includes/db.php");

?>

<!DOCTYPE html>

<html>

<head>

<title> Computerfever / Categories </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="author" content="Mohammed Tahir Ahmed">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="styles/bootstrap.min.css" rel="stylesheet">

<link href="styles/style.css" rel="stylesheet">

<link href="styles/category_nav_style.css" rel="stylesheet">

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

<script src="js/jquery.min.js"></script>

</head>

<body>

<?php include("includes/header.php"); ?>

<div class="container mt-5"><!-- container mt-5 Starts -->

<h2 class="text-center mb-4"> Computerfever Categories </h2>

<div class="row flex-wrap"><!-- row flex-wrap Starts -->

<?php

$get_categories = "select * from categories where cat_featured='yes'";

$run_categories = mysqli_query($con,$get_categories);

while($row_categories = mysqli_fetch_array($run_categories)){
	
	$cat_id = $row_categories['cat_id'];
	
	$cat_title = $row_categories['cat_title'];
	
	$cat_image = $row_categories['cat_image'];
	
	$cat_desc = substr($row_categories['cat_desc'],0,60);

?>

<div class="col-lg-3 col-md-4 col-sm-6"><!-- col-lg-3 col-md-4 col-sm-6 Starts -->

<div class="mobile-category"><!-- mobile-category Starts -->

<a href="category.php?cat_id=<?php echo $cat_id; ?>"><!-- category.php?cat_id Starts --->

<div class="ml-2 mt-3 category-picture"><!-- ml-2 mt-3 category-picture Starts -->

<img src="cat_images/<?php echo $cat_image; ?>">

</div><!-- ml-2 mt-3 category-picture Ends -->

<div class="category-text"><!-- category-text Starts -->

<p class="category-title">

<strong> <?php echo $cat_title; ?> </strong>

</p>


<p class="mb-4 category-desc">

<?php echo $cat_desc; ?>

</p>

</div><!-- category-text Ends -->

</a><!-- category.php?cat_id Ends --->

</div><!-- mobile-category Ends -->

</div><!--- col-lg-3 col-md-4 col-sm-6 Ends -->

<?php } ?>

</div><!-- row flex-wrap Ends -->

</div><!-- container mt-5 Ends -->

<?php include("includes/footer.php"); ?>

</body>

</html>