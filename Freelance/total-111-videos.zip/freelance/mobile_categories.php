<!DOCTYPE html>

<html>

<head>

<title> Computerfever - Freelance Services Marketplace </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="description" content="Computerfever is the world's largest freelance services marketplace for lean entrepreneurs to focus on growth & create a successful business at affordable costs.">

<meta name="keywords" content="freelance,freelancers,jobs,proposals,sellers,buyers">

<meta name="author" content="Mohammed Tahir Ahmed">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="styles/bootstrap.min.css" rel="stylesheet">

<link href="styles/style.css" rel="stylesheet">

<link href="styles/category_nav_style.css" rel="stylesheet">

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

<link href="styles/owl.carousel.css" rel="stylesheet">

<link href="styles/owl.theme.default.css" rel="stylesheet">

<script src="js/jquery.min.js"></script>

</head>

<body>

<?php include("includes/header.php"); ?>

<div class="container mt-5"><!-- container mt-5 Starts -->

<h2 class="text-center mb-4"> Computerfever Categories </h2>

<div class="row flex-wrap"><!-- row flex-wrap Starts -->

<div class="col-lg-3 col-md-4 col-sm-6"><!-- col-lg-3 col-md-4 col-sm-6 Starts -->

<div class="mobile-category"><!-- mobile-category Starts -->

<a href="category.php?cat_id"><!-- category.php?cat_id Starts --->

<div class="ml-2 mt-3 category-picture"><!-- ml-2 mt-3 category-picture Starts -->

<img src="cat_images/graphic-design.png">

</div><!-- ml-2 mt-3 category-picture Ends -->

<div class="category-text"><!-- category-text Starts -->

<p class="category-title">

<strong>Graphic Designing</strong>

</p>


<p class="mb-4 category-desc">

It is a long established fact that a reader will be distract

</p>

</div><!-- category-text Ends -->

</a><!-- category.php?cat_id Ends --->

</div><!-- mobile-category Ends -->

</div><!--- col-lg-3 col-md-4 col-sm-6 Ends -->


<div class="col-lg-3 col-md-4 col-sm-6"><!-- col-lg-3 col-md-4 col-sm-6 Starts -->

<div class="mobile-category"><!-- mobile-category Starts -->

<a href="category.php?cat_id"><!-- category.php?cat_id Starts --->

<div class="ml-2 mt-3 category-picture"><!-- ml-2 mt-3 category-picture Starts -->

<img src="cat_images/graphic-design.png">

</div><!-- ml-2 mt-3 category-picture Ends -->

<div class="category-text"><!-- category-text Starts -->

<p class="category-title">

<strong>Graphic Designing</strong>

</p>


<p class="mb-4 category-desc">

It is a long established fact that a reader will be distract

</p>

</div><!-- category-text Ends -->

</a><!-- category.php?cat_id Ends --->

</div><!-- mobile-category Ends -->

</div><!-- col-lg-3 col-md-4 col-sm-6 Ends -->


<div class="col-lg-3 col-md-4 col-sm-6"><!-- col-lg-3 col-md-4 col-sm-6 Starts -->

<div class="mobile-category"><!-- mobile-category Starts -->

<a href="category.php?cat_id"><!-- category.php?cat_id Starts --->

<div class="ml-2 mt-3 category-picture"><!-- ml-2 mt-3 category-picture Starts -->

<img src="cat_images/graphic-design.png">

</div><!-- ml-2 mt-3 category-picture Ends -->

<div class="category-text"><!-- category-text Starts -->

<p class="category-title">

<strong>Graphic Designing</strong>

</p>


<p class="mb-4 category-desc">

It is a long established fact that a reader will be distract

</p>

</div><!-- category-text Ends -->

</a><!-- category.php?cat_id Ends --->

</div><!-- mobile-category Ends -->

</div><!-- col-lg-3 col-md-4 col-sm-6 Ends -->

<div class="col-lg-3 col-md-4 col-sm-6"><!-- col-lg-3 col-md-4 col-sm-6 Starts -->

<div class="mobile-category"><!-- mobile-category Starts -->

<a href="category.php?cat_id"><!-- category.php?cat_id Starts --->

<div class="ml-2 mt-3 category-picture"><!-- ml-2 mt-3 category-picture Starts -->

<img src="cat_images/graphic-design.png">

</div><!-- ml-2 mt-3 category-picture Ends -->

<div class="category-text"><!-- category-text Starts -->

<p class="category-title">

<strong>Graphic Designing</strong>

</p>


<p class="mb-4 category-desc">

It is a long established fact that a reader will be distract

</p>

</div><!-- category-text Ends -->

</a><!-- category.php?cat_id Ends --->

</div><!-- mobile-category Ends -->

</div><!-- col-lg-3 col-md-4 col-sm-6 Ends -->

<div class="col-lg-3 col-md-4 col-sm-6"><!-- col-lg-3 col-md-4 col-sm-6 Starts -->

<div class="mobile-category"><!-- mobile-category Starts -->

<a href="category.php?cat_id"><!-- category.php?cat_id Starts --->

<div class="ml-2 mt-3 category-picture"><!-- ml-2 mt-3 category-picture Starts -->

<img src="cat_images/graphic-design.png">

</div><!-- ml-2 mt-3 category-picture Ends -->

<div class="category-text"><!-- category-text Starts -->

<p class="category-title">

<strong>Graphic Designing</strong>

</p>


<p class="mb-4 category-desc">

It is a long established fact that a reader will be distract

</p>

</div><!-- category-text Ends -->

</a><!-- category.php?cat_id Ends --->

</div><!-- mobile-category Ends -->

</div><!-- col-lg-3 col-md-4 col-sm-6 Ends -->

</div><!-- row flex-wrap Ends -->

</div><!-- container mt-5 Ends -->

<?php include("includes/footer.php"); ?>

</body>

</html>