
<?php

session_start();

include("includes/db.php");

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}

if((time() - $_SESSION['loggedin_time']) > 3600){
	
echo "<script>window.open('logout.php?session_expired','_self');</script>";
	
}


$admin_email = $_SESSION['admin_email'];

$get_admin = "select * from admins where admin_email='$admin_email'";

$run_admin = mysqli_query($con,$get_admin);

$row_admin = mysqli_fetch_array($run_admin);

$admin_id = $row_admin['admin_id'];

$admin_name = $row_admin['admin_name'];

$admin_image = $row_admin['admin_image'];

$admin_country = $row_admin['admin_country'];

$admin_job = $row_admin['admin_job'];

$admin_contact = $row_admin['admin_contact'];

$admin_about = $row_admin['admin_about'];


$get_proposals = "select * from proposals where proposal_status='pending'";

$run_proposals = mysqli_query($con,$get_proposals);

$count_proposals = mysqli_num_rows($run_proposals);



$get_orders = "select * from orders where order_active='yes'";

$run_orders = mysqli_query($con,$get_orders);

$count_orders = mysqli_num_rows($run_orders);


$get_sellers = "select * from sellers";

$run_sellers = mysqli_query($con,$get_sellers);

$count_sellers = mysqli_num_rows($run_sellers);


$get_support_tickets = "select * from support_tickets where status='open'";

$run_support_tickets = mysqli_query($con,$get_support_tickets);

$count_support_tickets = mysqli_num_rows($run_support_tickets);


$get_requests = "select * from buyer_requests where request_status='pending'";

$run_requests = mysqli_query($con,$get_requests);

$count_requests = mysqli_num_rows($run_requests);


$get_referrals = "select * from referrals where status='pending'";

$run_referrals = mysqli_query($con,$get_referrals);

$count_referrals = mysqli_num_rows($run_referrals);


?>

<!DOCTYPE HTML>

<html>

<head>

<title> Freelance Admin Panel </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="css/bootstrap.min.css">

<link rel="stylesheet" href="css/style.css">

<link rel="stylesheet" href="font-awesome/css/fontawesome-all.css">

<script src="js/jquery.min.js"> </script>

</head>

<body>

<div id="wrapper"><!--- wrapper Starts --->

<?php include("includes/sidebar.php"); ?>

<div id="page-wrapper"><!--- page-wrapper Starts --->

<div class="container-fluid"><!--- container-fluid Starts --->

<?php

if(isset($_GET['dashboard'])){
	
	include("dashboard.php");
	
}


if(isset($_GET['general_settings'])){
	
	include("general_settings.php");
	
}

if(isset($_GET['insert_box'])){
	
	include("insert_box.php");
	
}


if(isset($_GET['delete_box'])){
	
	include("delete_box.php");
	
}


if(isset($_GET['edit_box'])){
	
	include("edit_box.php");
	
}


if(isset($_GET['layout_settings'])){
	
	include("layout_settings.php");
	
}


if(isset($_GET['delete_link'])){
	
	include("delete_link.php");
	
}


if(isset($_GET['payment_settings'])){
	
	include("payment_settings.php");
	
}


if(isset($_GET['view_proposals'])){
	
	include("view_proposals.php");
	
}

if(isset($_GET['proposals_pagination'])){
	
	include("proposals_pagination.php");
	
}


if(isset($_GET['view_proposals_active'])){
	
	include("view_proposals_active.php");
	
}


?>

</div><!--- container-fluid Ends --->

</div><!--- page-wrapper Ends --->

</div><!--- wrapper Ends --->

<script src="js/popper.min.js"> </script>

<script src="js/bootstrap.min.js"> </script>

</body>

</html>