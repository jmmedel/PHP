<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<?php

if(isset($_GET['delete_link'])){
	
$delete_id = $_GET['delete_link'];

$delete_link = "delete from footer_links where link_id='$delete_id'";
	
$run_delete = mysqli_query($con,$delete_link);
	
if($run_delete){

echo "<script>alert('One Link Has Been Deleted.');</script>";	
	
echo "<script>window.open('index.php?layout_settings','_self');</script>";

	
}
	
}

?>

<?php } ?>