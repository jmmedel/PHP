
<div class="mt-2" id="footer"><!-- footer Starts -->

<div class="container"><!-- container Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Starts -->

<h4><strong> CATEGRIES </strong></h4>

<ul><!-- ul Starts -->

<?php

$get_links = "select * from footer_links where link_section='categories'";

$run_links = mysqli_query($con,$get_links);

while($row_links = mysqli_fetch_array($run_links)){
	
	$link_title = $row_links['link_title'];
	
	$link_url = $row_links['link_url'];

?>

<li><a href="<?php echo $link_url; ?>"> <?php echo $link_title; ?> </a></li>

<?php } ?>


</ul><!-- ul Ends -->

</div><!-- col-md-3 col-sm-6 Ends -->


<div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Starts -->

<h4><strong> ABOUT </strong></h4>

<ul><!-- ul Starts -->

<?php

$get_links = "select * from footer_links where link_section='about'";

$run_links = mysqli_query($con,$get_links);

while($row_links = mysqli_fetch_array($run_links)){
	
	$link_title = $row_links['link_title'];
	
	$link_url = $row_links['link_url'];

?>

<li><a href="<?php echo $link_url; ?>"> <?php echo $link_title; ?> </a></li>

<?php } ?>

</ul><!-- ul Ends -->

</div><!-- col-md-3 col-sm-6 Ends -->


<div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Starts -->

<h4><strong> SUPPORT </strong></h4>

<ul><!-- ul Starts -->


<?php

$get_links = "select * from footer_links where link_section='support'";

$run_links = mysqli_query($con,$get_links);

while($row_links = mysqli_fetch_array($run_links)){
	
	$link_title = $row_links['link_title'];
	
	$link_url = $row_links['link_url'];

?>

<li><a href="<?php echo $link_url; ?>"> <?php echo $link_title; ?> </a></li>

<?php } ?>

</ul><!-- ul Ends -->

</div><!-- col-md-3 col-sm-6 Ends -->


<div class="col-md-3 col-sm-6"><!-- col-md-3 col-sm-6 Starts -->

<h4><strong> Follow Us </strong></h4>

<ul><!-- ul Starts -->

<?php

$get_links = "select * from footer_links where link_section='follow'";

$run_links = mysqli_query($con,$get_links);

while($row_links = mysqli_fetch_array($run_links)){
	
	$link_title = $row_links['link_title'];
	
	$link_url = $row_links['link_url'];

?>

<li><a href="<?php echo $link_url; ?>"> <?php echo $link_title; ?> </a></li>

<?php } ?>

</ul><!-- ul Ends -->

</div><!-- col-md-3 col-sm-6 Ends -->


</div><!-- row Ends -->

</div><!-- container Ends -->

</div><!-- footer Ends -->


<div id="copyright"><!-- copyright Starts -->


<div class="container"><!-- container Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-6"><!-- col-md-6 Starts -->

<p class="text-lg-left tex-center font-weight-bold">

&copy; ComputerFever Freelance Services LLC. All Rights Reserved.

</p>

</div><!-- col-md-6 Ends -->

<div class="col-md-6"><!-- col-md-6 Starts -->

<p class="text-lg-right text-center">

Template By 

<a class="text-white font-weight-bold" href="http://www.computerfever.com"> 

ComputerFever.com

</a>

</p>

</div><!-- col-md-6 Ends -->

</div><!-- row Ends -->

</div><!-- container Ends -->

</div><!-- copyright Ends -->









<script src="<?php echo $site_url; ?>/js/jquery.sticky.js"></script>

<script src="<?php echo $site_url; ?>/js/popper.min.js"></script>

<script src="<?php echo $site_url; ?>/js/bootstrap.min.js"></script>

<script src="<?php echo $site_url; ?>/js/owl.carousel.min.js"></script>

<script src="<?php echo $site_url; ?>/js/custom.js"></script>

