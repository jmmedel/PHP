<!DOCTYPE html>

<html>

<head>

<title> Computerfever - Freelance Services Marketplace </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="description" content="Computerfever is the world's largest freelance services marketplace for lean entrepreneurs to focus on growth & create a successful business at affordable costs.">

<meta name="keywords" content="freelance,freelancers,jobs,proposals,sellers,buyers">

<meta name="author" content="Mohammed Tahir Ahmed">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="styles/bootstrap.min.css" rel="stylesheet">

<link href="styles/style.css" rel="stylesheet">

<link href="styles/category_nav_style.css" rel="stylesheet">

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">


</head>

<body>

<?php include("includes/header.php"); ?>

<?php include("includes/user_profile_header.php"); ?>


<div class="container-fluid"><!-- container-fluid Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-4 mt-4"><!-- col-md-4 mt-4 Starts -->

<?php include("includes/user_sidebar.php"); ?>

</div><!-- col-md-4 mt-4 Ends -->

<div class="col-md-8"><!-- col-md-8 Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-12"><!-- col-md-12 Starts -->

<div class="card mt-4 mb-4 rounded-0"><!-- card mt-4 mb-4 rounded-0 Starts -->

<div class="card-body"><!--- card-body Starts -->

<h2> Miss_digimarket's Proposals </h2>

</div><!--- card-body Ends -->

</div><!-- card mt-4 mb-4 rounded-0 Ends -->

</div><!-- col-md-12 Ends -->

</div><!-- row Ends -->

<div class="row"><!-- row Starts -->

<div class="col-lg-4 col-md-6 col-sm-6"><!--- col-lg-4 col-md-6 col-sm-6 Starts --->

<div class="proposal-div"><!-- proposal-div Starts -->

<div class="proposal_nav"><!-- proposal_nav Starts -->

<span class="float-left"><!-- float-left Starts -->

<strong class="ml-2 mr-1"> By </strong>

miss_digimarket

</span><!-- float-left Ends -->

<span class="float-right mt-2"><!-- float-right mt-2 Starts -->

<img class="rating" src="images/user_rate_full.png">

<img class="rating" src="images/user_rate_full.png">

<img class="rating" src="images/user_rate_full.png">

<img class="rating" src="images/user_rate_blank.png">

<img class="rating" src="images/user_rate_blank.png">

<span class="ml-1 mr-2">(3)</span>

</span><!-- float-right mt-2 Ends -->

<div class="clearfix mb-2"></div>

</div><!-- proposal_nav Ends -->

</div><!-- proposal-div Ends -->

</div><!--- col-lg-4 col-md-6 col-sm-6 Ends --->

</div><!-- row Ends -->

</div><!-- col-md-8 Ends -->

</div><!-- row Ends -->

</div><!-- container-fluid Ends -->



<?php include("includes/footer.php"); ?>

</body>

</html>