
<div class="card user-sidebar rounded-0"><!--- card user-sidebar rounded-0 Starts -->


<div class="card-body"><!-- card-body Starts -->

<h3>Description</h3>

<p>

We have made a special team of expertise belonging on different professions to serve you as a free lancers.So keep getting our services for your needs.

</p>

<hr class="card-hr">

<h3>Languages</h3>

<ul class="list-unstyled mt-3"><!-- list-unstyled mt-3 Starts -->

<li class="card-li mb-1"><!--- card-li mb-1 Starts -->

English - <span class="text-muted"> Fluent </span>

</li><!--- card-li mb-1 Ends -->

<li class="card-li mb-1"><!--- card-li mb-1 Starts -->

English - <span class="text-muted"> Fluent </span>

</li><!--- card-li mb-1 Ends -->


<li class="card-li mb-1"><!--- card-li mb-1 Starts -->

English - <span class="text-muted"> Fluent </span>

</li><!--- card-li mb-1 Ends -->

<li class="card-li mb-1"><!--- card-li mb-1 Starts -->

English - <span class="text-muted"> Fluent </span>

</li><!--- card-li mb-1 Ends -->

</ul><!-- list-unstyled mt-3 Ends -->

<hr class="card-hr">

<h3>Skills</h3>

<ul class="list-unstyled mt-3"><!-- list-unstyled mt-3 Starts -->

<li class="card-li mb-1"><!--- card-li mb-1 Starts -->

Html5 - <span class="text-muted"> Expert </span>

</li><!--- card-li mb-1 Ends -->


<li class="card-li mb-1"><!--- card-li mb-1 Starts -->

Html5 - <span class="text-muted"> Expert </span>

</li><!--- card-li mb-1 Ends -->


<li class="card-li mb-1"><!--- card-li mb-1 Starts -->

Html5 - <span class="text-muted"> Expert </span>

</li><!--- card-li mb-1 Ends -->


<li class="card-li mb-1"><!--- card-li mb-1 Starts -->

Html5 - <span class="text-muted"> Expert </span>

</li><!--- card-li mb-1 Ends -->

</ul><!-- list-unstyled mt-3 Ends -->

</div><!-- card-body Ends -->


</div><!--- card user-sidebar rounded-0 Ends -->