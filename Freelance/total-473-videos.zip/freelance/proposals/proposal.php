<?php

session_start();

include("../includes/db.php");

$proposal_url = $_GET['proposal_url'];

$get_proposal = "select * from proposals where proposal_url='$proposal_url'";

$run_proposal = mysqli_query($con,$get_proposal);

$count_proposal = mysqli_num_rows($run_proposal);

if($count_proposal == 0){
	
	echo "<script> window.open('../index.php?not_available','_self') </script>";
	
}

$row_proposal = mysqli_fetch_array($run_proposal);

$proposal_id = $row_proposal['proposal_id'];

// Select Proposal Details From Proposal Id

$get_proposal = "select * from proposals where proposal_id='$proposal_id'";

$run_proposal = mysqli_query($con,$get_proposal);

$row_proposal = mysqli_fetch_array($run_proposal);

$proposal_title = $row_proposal['proposal_title'];

$proposal_cat_id = $row_proposal['proposal_cat_id'];

$proposal_child_id = $row_proposal['proposal_child_id'];

$proposal_price = $row_proposal['proposal_price'];

$proposal_img1 = $row_proposal['proposal_img1'];

$proposal_img2 = $row_proposal['proposal_img2'];

$proposal_img3 = $row_proposal['proposal_img3'];

$proposal_img4 = $row_proposal['proposal_img4'];

$proposal_video = $row_proposal['proposal_video'];

$proposal_desc = $row_proposal['proposal_desc'];

$proposal_short_desc = substr($row_proposal['proposal_desc'],0,160);

$proposal_tags = $row_proposal['proposal_tags'];

$proposal_seller_id = $row_proposal['proposal_seller_id'];

$delivery_id = $row_proposal['delivery_id'];

$proposal_rating = $row_proposal['proposal_rating'];

// Select Proposal Category

$get_cat = "select * from categories where cat_id='$proposal_cat_id'";

$run_cat = mysqli_query($con,$get_cat);

$row_cat = mysqli_fetch_array($run_cat);

$proposal_cat_title = $row_cat['cat_title'];

// Select Proposal Child Category

$get_child_cat = "select * from categories_childs where child_id='$proposal_child_id'";

$run_child_cat = mysqli_query($con,$get_child_cat);

$row_child_cat = mysqli_fetch_array($run_child_cat);

$proposal_child_title = $row_child_cat['child_title'];

// Select Proposal Delivery Time

$get_delivery_time = "select * from delivery_times where delivery_id='$delivery_id'";

$run_delivery_time = mysqli_query($con,$get_delivery_time);

$row_delivery_time = mysqli_fetch_array($run_delivery_time);

$delivery_proposal_title = $row_delivery_time['delivery_proposal_title'];

// Select Proposal Active Orders

$select_orders = "select * from orders where proposal_id='$proposal_id' AND order_active='yes'";

$run_orders = mysqli_query($con,$select_orders);

$proposal_order_queue = mysqli_num_rows($run_orders);

// Select Proposal Reviews Then Count Them

$proposal_reviews = array();

$select_buyer_reviews = "select * from buyer_reviews where proposal_id='$proposal_id'";

$run_buyer_reviews = mysqli_query($con,$select_buyer_reviews);

$count_reviews = mysqli_num_rows($run_buyer_reviews);

while($row_buyer_reviews = mysqli_fetch_array($run_buyer_reviews)){
	
	$proposal_buyer_rating = $row_buyer_reviews['buyer_rating'];
	
	array_push($proposal_reviews,$proposal_buyer_rating);
	
	
}

$total = array_sum($proposal_reviews);

@$average_rating = $total/count($proposal_reviews);

// Select Proposal Seller Details

$select_proposal_seller = "select * from sellers where seller_id='$proposal_seller_id'";

$run_proposal_seller = mysqli_query($con,$select_proposal_seller);

$row_proposal_seller = mysqli_fetch_array($run_proposal_seller);

$proposal_seller_user_name = $row_proposal_seller['seller_user_name'];

$proposal_seller_image = $row_proposal_seller['seller_image'];

$proposal_seller_country = $row_proposal_seller['seller_country'];

$proposal_seller_about = $row_proposal_seller['seller_about'];

$proposal_seller_level = $row_proposal_seller['seller_level'];

$proposal_seller_recent_delivery = $row_proposal_seller['seller_recent_delivery'];

$proposal_seller_rating = $row_proposal_seller['seller_rating'];

$proposal_seller_vacation = $row_proposal_seller['seller_vacation'];

$proposal_seller_status = $row_proposal_seller['seller_status'];


// Select Proposal Seller Level


$select_seller_level = "select * from seller_levels where level_id='$proposal_seller_level'";

$run_seller_level = mysqli_query($con,$select_seller_level);

$row_seller_level = mysqli_fetch_array($run_seller_level);

$level_title = $row_seller_level['level_title'];

// Update Proposal Views


if(!isset($_SESSION['seller_user_name'])){
	
	$update_proposal_views = "update proposals set proposal_views=proposal_views+1 where proposal_id='$proposal_id'";
	
	$run_update_views = mysqli_query($con,$update_proposal_views);
	
	
}


if(isset($_SESSION['seller_user_name'])){
	
	
$login_seller_user_name = $_SESSION['seller_user_name'];

$select_login_seller = "select * from sellers where seller_user_name='$login_seller_user_name'";

$run_login_seller = mysqli_query($con,$select_login_seller);

$row_login_seller = mysqli_fetch_array($run_login_seller);

$login_seller_id = $row_login_seller['seller_id'];


if($proposal_seller_id != $login_seller_id ){
	
   $update_proposal_views = "update proposals set proposal_views=proposal_views+1 where proposal_id='$proposal_id'";
	
	$run_update_views = mysqli_query($con,$update_proposal_views);
	
}

	$select_recent_proposal = "select * from recent_proposals where seller_id='$login_seller_id' AND proposal_id='$proposal_id'";
	
	$run_recent_proposal= mysqli_query($con,$select_recent_proposal);

    $count_recent_proposal = mysqli_num_rows($run_recent_proposal);
	
	if($count_recent_proposal == 1){
		
		if($proposal_seller_id != $login_seller_id){
			
		$delete_recent_proposal = "delete from recent_proposals where seller_id='$login_seller_id' AND proposal_id='$proposal_id'";
		
		$run_delete = mysqli_query($con,$delete_recent_proposal);
			
		$insert_recent_proposal = "insert into recent_proposals (seller_id,proposal_id) values ('$login_seller_id','$proposal_id')";	
			
		$run_recent_proposal = mysqli_query($con,$insert_recent_proposal);
			
		}
		
	}else{
		
		if($proposal_seller_id != $login_seller_id){
			
		$insert_recent_proposal = "insert into recent_proposals (seller_id,proposal_id) values ('$login_seller_id','$proposal_id')";	
			
		$run_recent_proposal = mysqli_query($con,$insert_recent_proposal);
			
		}
		
		
	}
	
	
}



?>

<!DOCTYPE html>

<html>

<head>

<title> <?php echo $proposal_title; ?> </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="description" content="<?php echo $proposal_short_desc; ?>">

<meta name="keywords" content="<?php echo $proposal_tags; ?>">

<meta name="author" content="<?php echo $proposal_seller_user_name; ?>">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="../styles/bootstrap.min.css" rel="stylesheet">

<link href="../styles/style.css" rel="stylesheet">

<link href="../styles/category_nav_style.css" rel="stylesheet">

<!--- stylesheet width modifications --->

<link href="../styles/custom.css" rel="stylesheet">

<link href="../font-awesome/css/font-awesome.min.css" rel="stylesheet">

<link href="../styles/owl.carousel.css" rel="stylesheet">

<link href="../styles/owl.theme.default.css" rel="stylesheet">

<!-- Go to www.addthis.com/dashboard to customize your tools --> 

<script type="text/javascript" src="//s7.addthis.com/js/300/addthis_widget.js#pubid=ra-547f4631046d3c5c">

</script>

<script src="../js/jquery.min.js"></script>

</head>

<body>

<?php include("../includes/header.php"); ?>

<div class="container mt-5"><!-- container mt-5 Starts -->

<div class="row"><!-- row Starts  -->

<div class="col-lg-8 col-md-7 mb-3"><!-- col-lg-8 col-md-7 mb-3 Starts -->

<div class="card rounded-0 mb-3"><!-- card rounded-0 mb-3 Starts -->

<div class="card-body details"><!-- card-body details Starts -->

<div class="proposal-info"><!-- proposal-info Starts -->

<h3> <?php echo $proposal_title; ?> </h3>

<?php

for($proposal_i=0; $proposal_i<$proposal_rating; $proposal_i++){
	
	echo " <img class='rating' src='../images/user_rate_full.png' > ";
	
}

for($proposal_i=$proposal_rating; $proposal_i<5; $proposal_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank.png' > ";
	
}


?>


<span class="text-muted span"> (<?php echo $count_reviews; ?>) &nbsp;&nbsp; <?php echo $proposal_order_queue; ?> Orders In Queue </span>

<hr>

<a href="../category.php?cat_id=<?php echo $proposal_cat_id; ?>">  <?php echo $proposal_cat_title; ?> </a> 


/ 

<a href="../category.php?cat_child_id=<?php echo $proposal_child_id; ?>">
   <?php echo $proposal_child_title; ?>
</a>

</div><!-- proposal-info Ends -->

<div id="myCarousel" class="carousel slide" ><!-- carousel slide Starts --->

<ol class="carousel-indicators"><!-- carousel-indicators Starts -->

<?php if(!empty($proposal_video)){ ?>

<li data-target="#myCarousel" data-slide-to="0"  class="active"></li>

<?php } ?>

<li data-target="#myCarousel" data-slide-to="1" 

<?php

if(empty($proposal_video)){ echo "class='active'"; }

?>

></li>

<?php if(!empty($proposal_img2)){ ?>

<li data-target="#myCarousel" data-slide-to="2"></li>

<?php } ?>

<?php if(!empty($proposal_img3)){ ?>

<li data-target="#myCarousel" data-slide-to="3"></li>

<?php } ?>

<?php if(!empty($proposal_img4)){ ?>

<li data-target="#myCarousel" data-slide-to="4"></li>


<?php } ?>

</ol><!-- carousel-indicators Ends -->

<div class="carousel-inner"><!-- carousel-inner Starts  -->

<?php if(!empty($proposal_video)){ ?>

<div class="carousel-item active"><!--- carousel-item active Starts -->

<script src="https://content.jwplatform.com/libraries/IKBOrtS2.js"></script>

<div class="d-block w-100" id="player"></div>

<script>

var player = jwplayer('player');

player.setup({
	
file: "proposal_files/<?php echo $proposal_video; ?>",
	
image: "proposal_files/<?php echo $proposal_img1; ?>"
	
});

</script>

</div><!--- carousel-item active Ends -->

<?php } ?>

<div class="carousel-item

<?php

if(empty($proposal_video)){ echo "active"; }

?>

"><!-- carousel-item Starts -->

<img class="d-block w-100" src="proposal_files/<?php echo $proposal_img1; ?>">

</div><!-- carousel-item Ends -->

<?php if(!empty($proposal_img2)){ ?>

<div class="carousel-item"><!-- carousel-item Starts -->

<img class="d-block w-100" src="proposal_files/<?php echo $proposal_img2; ?>">

</div><!-- carousel-item Ends -->

<?php } ?>

<?php if(!empty($proposal_img3)){ ?>

<div class="carousel-item"><!-- carousel-item Starts -->

<img class="d-block w-100" src="proposal_files/<?php echo $proposal_img3; ?>">

</div><!-- carousel-item Ends -->

<?php } ?>

<?php if(!empty($proposal_img4)){ ?>

<div class="carousel-item"><!-- carousel-item Starts -->

<img class="d-block w-100" src="proposal_files/<?php echo $proposal_img4; ?>">

</div><!-- carousel-item Ends -->

<?php } ?>

</div><!-- carousel-inner Ends  -->

<a class="carousel-control-prev slide-nav slide-right" href="#myCarousel" data-slide="prev">

<span class="carousel-control-prev-icon carousel-icon"></span>

</a>

<a class="carousel-control-next slide-nav slide-left" href="#myCarousel" data-slide="next">

<span class="carousel-control-next-icon carousel-icon"></span>

</a>

</div><!-- carousel slide Ends --->

</div><!-- card-body details Ends -->

</div><!-- card rounded-0 mb-3 Ends -->

<div class="card rounded-0 mb-3"><!-- card rounded-0 mb-3 Starts -->

<div class="card-header"><!-- card-header Starts -->

<h4>About This Proposal</h4>

</div><!-- card-header Ends -->

<div class="card-body"><!-- card-body Starts -->

<p>

<?php echo $proposal_desc; ?>

</p>

</div><!-- card-body Ends -->

</div><!-- card rounded-0 mb-3 Ends -->


<div class="card proposal-reviews rounded-0 mb-3"><!-- card proposal-reviews rounded-0 mb-3 Starts -->

<div class="card-header"><!-- card-header Starts -->

<h4>

<span class="ml-2"> <?php echo $count_reviews; ?> Reviews </span>

<?php

for($proposal_i=0; $proposal_i<$proposal_rating; $proposal_i++){
	
	echo " <img class='rating' src='../images/user_rate_full_big.png' > ";
	
}

for($proposal_i=$proposal_rating; $proposal_i<5; $proposal_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank_big.png' > ";
	
}


?>

<span class="text-muted"> 

<?php

if($proposal_rating == "0"){
	
echo "0.0";	
	
}else{

printf("%.1f", $average_rating);
	
}


?>

</span>

<div class="dropdown float-right"><!--- dropdown float-right Starts -->

<button id="dropdown-button" class="btn btn-secondary dropdown-toggle" data-toggle="dropdown">

Most Recent

</button>

<ul class="dropdown-menu"><!-- dropdown-menu Starts -->

<li class="dropdown-item active all"> Most Recent </li>

<li class="dropdown-item good"> Positive Reviews </li>

<li class="dropdown-item bad"> Negative Reviews </li>

</ul><!-- dropdown-menu Ends -->

</div><!--- dropdown float-right Ends -->

</h4>

</div><!-- card-header Ends -->

<div class="card-body"><!-- card-body Starts -->

<article id="all" class="proposal-reviews"><!-- proposal-reviews Starts -->

<ul class="reviews-list"><!-- reviews-list Starts -->

<?php

$select_buyer_reviews = "select * from buyer_reviews where proposal_id='$proposal_id'";

$run_buyer_reviews = mysqli_query($con,$select_buyer_reviews);

$count_reviews = mysqli_num_rows($run_buyer_reviews);

if($count_reviews == 0){
	
	echo "
	
	<li>
	
	<h3 align='center'> 
This Proposal Has No Reivew, Become First To Write Reivew. 
</h3>
	
	</li>
	
	";
	
}

while($row_buyer_reviews = mysqli_fetch_array($run_buyer_reviews)){

$order_id = $row_buyer_reviews['order_id'];

$review_buyer_id = $row_buyer_reviews['review_buyer_id'];

$buyer_rating = $row_buyer_reviews['buyer_rating'];

$buyer_review = $row_buyer_reviews['buyer_review'];

$review_date = $row_buyer_reviews['review_date'];

$select_seller = "select * from sellers where seller_id='$review_buyer_id'";

$run_seller = mysqli_query($con,$select_seller);

$row_seller = mysqli_fetch_array($run_seller);

$buyer_user_name = $row_seller['seller_user_name'];

$buyer_image = $row_seller['seller_image'];

$select_seller_review = "select * from seller_reviews where order_id='$order_id'";

$run_seller_review = mysqli_query($con,$select_seller_review);

$count_seller_review = mysqli_num_rows($run_seller_review);

$row_seller_review = mysqli_fetch_array($run_seller_review);

$seller_rating = $row_seller_review['seller_rating'];

$seller_review = $row_seller_review['seller_review'];


?>

<li class="star-rating-row"><!-- star-rating-row Starts -->

<span class="user-picture"><!-- user-picture Starts -->

<?php if(!empty($buyer_image)){ ?>

<img src="../user_images/<?php echo $buyer_image; ?>" width="60" height="60">

<?php }else{ ?>

<img src="../user_images/empty-image.png" width="60" height="60">

<?php } ?>

</span><!-- user-picture Ends -->

<h4><!-- h4 Starts -->

<a href="#" class="mr-1"> <?php echo $buyer_user_name; ?> </a>

<?php

for($buyer_i=0; $buyer_i<$buyer_rating; $buyer_i++){
	
	echo " <img class='rating' src='../images/user_rate_full.png' > ";
	
}

for($buyer_i=$buyer_rating; $buyer_i<5; $buyer_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank.png' > ";
	
}


?>

</h4><!-- h4 Ends -->

<div class="msg-body"><!-- msg-body Starts -->

<?php echo $buyer_review; ?>

</div><!-- msg-body Ends -->

<span class="rating-date"> <?php echo $review_date; ?> </span>

</li><!-- star-rating-row Ends -->

<?php if(!$count_seller_review == 0){ ?>

<li class="rating-seller"><!-- rating-seller Starts -->

<h4><!-- h4 Starts -->

<span class="mr-1"> Seller's Feedback </span>

<?php

for($seller_i=0; $seller_i<$seller_rating; $seller_i++){
	
	echo " <img class='rating' src='../images/user_rate_full.png' > ";
	
}

for($seller_i=$seller_rating; $seller_i<5; $seller_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank.png' > ";
	
}


?>

</h4><!-- h4 Ends -->

<span class="user-picture"><!-- user-picture Starts -->

<?php if(!empty($proposal_seller_image)){ ?>

<img src="../user_images/<?php echo $proposal_seller_image; ?>" width="40" height="40">

<?php }else{ ?>

<img src="../user_images/empty-image.png" width="40" height="40">

<?php } ?>

</span><!-- user-picture Ends -->

<div class="msg-body"><!-- msg-body Starts -->

<?php echo $seller_review; ?>

</div><!-- msg-body Ends -->

</li><!-- rating-seller Ends -->

<?php } ?>

<hr>

<?php } ?>


</ul><!-- reviews-list Ends -->

</article><!-- proposal-reviews Ends -->


<article id="good" class="proposal-reviews"><!-- proposal-reviews Starts -->

<ul class="reviews-list"><!-- reviews-list Starts -->

<?php

$select_buyer_reviews = "select * from buyer_reviews where proposal_id='$proposal_id' AND (buyer_rating='5' or buyer_rating='4')";

$run_buyer_reviews = mysqli_query($con,$select_buyer_reviews);

$count_reviews = mysqli_num_rows($run_buyer_reviews);

if($count_reviews == 0){
	
	echo "
	
	<li>
	
	<h3 align='center'> 
There Is Currently No Positive Review Of This Proposal.
</h3>
	
	</li>
	
	";
	
}

while($row_buyer_reviews = mysqli_fetch_array($run_buyer_reviews)){

$order_id = $row_buyer_reviews['order_id'];

$review_buyer_id = $row_buyer_reviews['review_buyer_id'];

$buyer_rating = $row_buyer_reviews['buyer_rating'];

$buyer_review = $row_buyer_reviews['buyer_review'];

$review_date = $row_buyer_reviews['review_date'];

$select_seller = "select * from sellers where seller_id='$review_buyer_id'";

$run_seller = mysqli_query($con,$select_seller);

$row_seller = mysqli_fetch_array($run_seller);

$buyer_user_name = $row_seller['seller_user_name'];

$buyer_image = $row_seller['seller_image'];

$select_seller_review = "select * from seller_reviews where order_id='$order_id'";

$run_seller_review = mysqli_query($con,$select_seller_review);

$count_seller_review = mysqli_num_rows($run_seller_review);

$row_seller_review = mysqli_fetch_array($run_seller_review);

$seller_rating = $row_seller_review['seller_rating'];

$seller_review = $row_seller_review['seller_review'];


?>

<li class="star-rating-row"><!-- star-rating-row Starts -->

<span class="user-picture"><!-- user-picture Starts -->

<?php if(!empty($buyer_image)){ ?>

<img src="../user_images/<?php echo $buyer_image; ?>" width="60" height="60">

<?php }else{ ?>

<img src="../user_images/empty-image.png" width="60" height="60">

<?php } ?>

</span><!-- user-picture Ends -->

<h4><!-- h4 Starts -->

<a href="#" class="mr-1"> <?php echo $buyer_user_name; ?> </a>

<?php

for($buyer_i=0; $buyer_i<$buyer_rating; $buyer_i++){
	
	echo " <img class='rating' src='../images/user_rate_full.png' > ";
	
}

for($buyer_i=$buyer_rating; $buyer_i<5; $buyer_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank.png' > ";
	
}


?>

</h4><!-- h4 Ends -->

<div class="msg-body"><!-- msg-body Starts -->

<?php echo $buyer_review; ?>

</div><!-- msg-body Ends -->

<span class="rating-date"> <?php echo $review_date; ?> </span>

</li><!-- star-rating-row Ends -->

<?php if(!$count_seller_review == 0){ ?>

<li class="rating-seller"><!-- rating-seller Starts -->

<h4><!-- h4 Starts -->

<span class="mr-1"> Seller's Feedback </span>

<?php

for($seller_i=0; $seller_i<$seller_rating; $seller_i++){
	
	echo " <img class='rating' src='../images/user_rate_full.png' > ";
	
}

for($seller_i=$seller_rating; $seller_i<5; $seller_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank.png' > ";
	
}


?>

</h4><!-- h4 Ends -->

<span class="user-picture"><!-- user-picture Starts -->

<?php if(!empty($proposal_seller_image)){ ?>

<img src="../user_images/<?php echo $proposal_seller_image; ?>" width="40" height="40">

<?php }else{ ?>

<img src="../user_images/empty-image.png" width="40" height="40">

<?php } ?>

</span><!-- user-picture Ends -->

<div class="msg-body"><!-- msg-body Starts -->

<?php echo $seller_review; ?>

</div><!-- msg-body Ends -->

</li><!-- rating-seller Ends -->

<?php } ?>

<hr>

<?php } ?>


</ul><!-- reviews-list Ends -->

</article><!-- proposal-reviews Ends -->


<article id="bad" class="proposal-reviews"><!-- proposal-reviews Starts -->

<ul class="reviews-list"><!-- reviews-list Starts -->


<?php

$select_buyer_reviews = "select * from buyer_reviews where proposal_id='$proposal_id' AND (buyer_rating='1' or buyer_rating='2' or buyer_rating='3')";

$run_buyer_reviews = mysqli_query($con,$select_buyer_reviews);

$count_reviews = mysqli_num_rows($run_buyer_reviews);

if($count_reviews == 0){
	
	echo "
	
	<li>
	
	<h3 align='center'> 
There Is Currently No Negative Review Of This Proposal.
</h3>
	
	</li>
	
	";
	
}

while($row_buyer_reviews = mysqli_fetch_array($run_buyer_reviews)){

$order_id = $row_buyer_reviews['order_id'];

$review_buyer_id = $row_buyer_reviews['review_buyer_id'];

$buyer_rating = $row_buyer_reviews['buyer_rating'];

$buyer_review = $row_buyer_reviews['buyer_review'];

$review_date = $row_buyer_reviews['review_date'];

$select_seller = "select * from sellers where seller_id='$review_buyer_id'";

$run_seller = mysqli_query($con,$select_seller);

$row_seller = mysqli_fetch_array($run_seller);

$buyer_user_name = $row_seller['seller_user_name'];

$buyer_image = $row_seller['seller_image'];

$select_seller_review = "select * from seller_reviews where order_id='$order_id'";

$run_seller_review = mysqli_query($con,$select_seller_review);

$count_seller_review = mysqli_num_rows($run_seller_review);

$row_seller_review = mysqli_fetch_array($run_seller_review);

$seller_rating = $row_seller_review['seller_rating'];

$seller_review = $row_seller_review['seller_review'];


?>

<li class="star-rating-row"><!-- star-rating-row Starts -->

<span class="user-picture"><!-- user-picture Starts -->

<?php if(!empty($buyer_image)){ ?>

<img src="../user_images/<?php echo $buyer_image; ?>" width="60" height="60">

<?php }else{ ?>

<img src="../user_images/empty-image.png" width="60" height="60">

<?php } ?>

</span><!-- user-picture Ends -->

<h4><!-- h4 Starts -->

<a href="#" class="mr-1"> <?php echo $buyer_user_name; ?> </a>

<?php

for($buyer_i=0; $buyer_i<$buyer_rating; $buyer_i++){
	
	echo " <img class='rating' src='../images/user_rate_full.png' > ";
	
}

for($buyer_i=$buyer_rating; $buyer_i<5; $buyer_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank.png' > ";
	
}


?>

</h4><!-- h4 Ends -->

<div class="msg-body"><!-- msg-body Starts -->

<?php echo $buyer_review; ?>

</div><!-- msg-body Ends -->

<span class="rating-date"> <?php echo $review_date; ?> </span>

</li><!-- star-rating-row Ends -->

<?php if(!$count_seller_review == 0){ ?>

<li class="rating-seller"><!-- rating-seller Starts -->

<h4><!-- h4 Starts -->

<span class="mr-1"> Seller's Feedback </span>

<?php

for($seller_i=0; $seller_i<$seller_rating; $seller_i++){
	
	echo " <img class='rating' src='../images/user_rate_full.png' > ";
	
}

for($seller_i=$seller_rating; $seller_i<5; $seller_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank.png' > ";
	
}


?>

</h4><!-- h4 Ends -->

<span class="user-picture"><!-- user-picture Starts -->

<?php if(!empty($proposal_seller_image)){ ?>

<img src="../user_images/<?php echo $proposal_seller_image; ?>" width="40" height="40">

<?php }else{ ?>

<img src="../user_images/empty-image.png" width="40" height="40">

<?php } ?>

</span><!-- user-picture Ends -->

<div class="msg-body"><!-- msg-body Starts -->

<?php echo $seller_review; ?>

</div><!-- msg-body Ends -->

</li><!-- rating-seller Ends -->

<?php } ?>

<hr>

<?php } ?>

</ul><!-- reviews-list Ends -->

</article><!-- proposal-reviews Ends -->


</div><!-- card-body Ends -->

</div><!-- card proposal-reviews rounded-0 mb-3 Ends -->

<div class="proposal-tags-container mt-2"><!--- proposal-tags-container mt-2 Starts -->

<?php

$tags = explode(",", $proposal_tags);

foreach($tags as $tag){

?>

<div class="proposal-tag mb-3"> <span> <?php echo $tag; ?> </span> </div>

<?php } ?>

</div><!--- proposal-tags-container mt-2 Ends -->

</div><!-- col-lg-8 col-md-7 mb-3 Ends -->

<div class="col-lg-4 col-md-5 proposal-sidebar"><!--- col-lg-4 col-md-5 proposal-sidebar Starts -->

<div class="card mb-3 rounded-0"><!-- card mb-3 rounded-0 Starts -->

<div class="card-body"><!-- card-body Starts -->

<?php if($proposal_seller_vacation == "on"){ ?>

<?php if($proposal_seller_user_name == @$_SESSION['seller_user_name']){ ?>

<h4>

Your Vacation Mode Has Been Turned On , <br>

No One Is Able To Purchase Your Proposal

</h4>

<?php }else{ ?>

<h4>

Seller Vacation Mode Has Been Turned On,<br>
Sorry Anyone Cannot Purchase His/Her Proposal.

</h4>

<?php } ?>

<?php }elseif($proposal_seller_vacation == "off"){ ?>

<h3> <strong class="text-success"> $<?php echo $proposal_price; ?> </strong> Order Details </h3>

<h4> <i class="fa fa-clock-o"></i>&nbsp; <?php echo $delivery_proposal_title; ?> Delivery </h4>

<?php if(!isset($_SESSION['seller_user_name'])){ ?>

<button class="btn btn-lg button-lg1 btn-success" data-toggle="modal" data-target="#login-modal">

Order Now ($<?php echo $proposal_price; ?>)

</button>

<button class="btn btn-lg button-lg2 btn-success" data-toggle="modal" data-target="#login-modal">

<i class="fa fa-lg fa-shopping-cart"></i>

</button>

<hr>


<div class="form-group row"><!-- form-group row Starts -->

<label class="col-md-6 control-label"> Proposal Quantity </label>

<div class="col-md-6">

<select class="form-control" name="proposal_qty">

<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>

</select>

</div>

</div><!-- form-group row Ends -->

<?php }else{ ?>


<?php if($proposal_seller_user_name == @$_SESSION['seller_user_name']){ ?>

<a class="btn btn-lg btn-block btn-success" href="edit_proposal.php?proposal_id=<?php echo $proposal_id; ?>">

Edit Proposal

</a>

<?php }else{ ?>


<form method="post" action="../checkout.php"><!-- form Starts -->

<input type="hidden" name="proposal_id" value="<?php echo $proposal_id; ?>">

<button class="btn btn-lg button-lg1 btn-success" type="submit" name="add_order">

Order Now ($<?php echo $proposal_price; ?>)

</button>

<button class="btn btn-lg button-lg2 btn-success" type="submit" name="add_cart">

<i class="fa fa-lg fa-shopping-cart"></i>

</button>

<hr>


<div class="form-group row"><!-- form-group row Starts -->

<label class="col-md-6 control-label"> Proposal Quantity </label>

<div class="col-md-6">

<select class="form-control" name="proposal_qty">

<option>1</option>
<option>2</option>
<option>3</option>
<option>4</option>

</select>

</div>

</div><!-- form-group row Ends -->


</form><!-- form Ends -->

<?php } ?>


<?php } ?>

<?php } ?>

</div><!-- card-body Ends -->

</div><!-- card mb-3 rounded-0 Ends -->

<center class="mb-3"><!-- mb-3 Starts -->

<!-- Go to www.addthis.com/dashboard to customize your tools --> 

<div class="addthis_inline_share_toolbox_gwmz">

</div>

</center><!-- mb-3 Ends -->

<div class="card seller-bio mb-3 rounded-0"><!--- card seller-bio mb-3 rounded-0 Starts -->

<div class="card-body"><!--- card-body Starts -->



<center class="mb-4">

<?php if(!empty($proposal_seller_image)){ ?>

<img src="../user_images/<?php echo $proposal_seller_image; ?>" width="130" class="rounded-circle">

<?php }else{ ?>

<img src="../user_images/empty-image.png" width="130" class="rounded-circle">

<?php } ?>

<?php if($proposal_seller_level == 2){ ?>

<img src="../images/level_badge_1.png" width="55" class="seller_level_badge">

<?php } ?>

<?php if($proposal_seller_level == 3){ ?>

<img src="../images/level_badge_2.png" width="55" class="seller_level_badge">

<?php } ?>

<?php if($proposal_seller_level == 4){ ?>

<img src="../images/level_badge_3.png" width="55" class="seller_level_badge">

<?php } ?>

</center>

<a class="text-center" href="../<?php echo $proposal_seller_user_name; ?>"> <h3> <?php echo $proposal_seller_user_name; ?> </h3> </a>

<h4 class="text-muted text-center"> <?php echo $level_title; ?> </h4>

<hr>

<div class="row"><!--  row Starts -->

<div class="col-md-6"><!-- col-md-6 Starts -->

<p class="text-muted"> From </p>

<p> <?php echo $proposal_seller_country; ?> </p>

</div><!-- col-md-6 Ends -->

<div class="col-md-6"><!-- col-md-6 Starts -->

<p class="text-muted"> Positive Ratings </p>

<p> <?php echo $proposal_seller_rating; ?>% </p>

</div><!-- col-md-6 Ends -->


<div class="col-md-6"><!-- col-md-6 Starts -->

<p class="text-muted"> Speaks </p>

<p> 

<?php

$select_languages_relation = "select * from languages_relation where seller_id='$proposal_seller_id'";

$run_languages_relation = mysqli_query($con,$select_languages_relation);

while($row_languages_relation = mysqli_fetch_array($run_languages_relation)){
	
	$language_id = $row_languages_relation['language_id'];
	
	$get_language = "select * from seller_languages where language_id='$language_id'";
	
	$run_language = mysqli_query($con,$get_language);
	
	$row_language = mysqli_fetch_array($run_language);
	
	$language_title = $row_language['language_title'];

?>

<?php echo $language_title; ?>,


<?php } ?>

</p>

</div><!-- col-md-6 Ends -->


<div class="col-md-6"><!-- col-md-6 Starts -->

<p class="text-muted"> Recent Delivery </p>

<p> <?php echo $proposal_seller_recent_delivery; ?> </p>

</div><!-- col-md-6 Ends -->


</div><!--  row Ends -->

<hr>

<p>

<?php

echo $proposal_seller_about;

?>

</p>

<a href="../<?php echo $proposal_seller_user_name; ?>"> Read More </a>

</div><!--- card-body Ends -->

<div class="card-footer"><!-- card-footer Starts -->

<?php if($proposal_seller_status == "online"){ ?>

<p class="float-left online">

<i class="fa fa-check"></i> Online

</p>

<?php } ?>

<a class="float-right btn btn-primary" href="../conversations/message.php?seller_id=<?php echo $proposal_seller_id; ?>">

<i class="fa fa-comment-o"></i>

Contact Us

</a>

</div><!-- card-footer Ends -->

</div><!--- card seller-bio mb-3 rounded-0 Ends -->

</div><!--- col-lg-4 col-md-5 proposal-sidebar Ends -->

</div><!-- row Ends  -->

</div><!-- container mt-5 Ends -->

<div class="container-fluid bg-light"><!-- container-fluid bg-light Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-10 offset-md-1"><!--- col-md-10 offset-md-1 Starts -->

<h2 class="p-2 mt-3">

RECOMMENDED FOR YOU IN <a href="../<?php echo $proposal_seller_user_name; ?>"> <?php echo $proposal_seller_user_name; ?> </a>

</h2>


<div class="row flex-wrap mb-3"><!-- row flex-wrap mb-3 Starts -->

<?php

$get_proposals = "select * from proposals where proposal_seller_id='$proposal_seller_id' AND proposal_status='active'";

$run_proposals = mysqli_query($con,$get_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_video = $row_proposals['proposal_video'];

$proposal_seller_id = $row_proposals['proposal_seller_id'];

$proposal_rating = $row_proposals['proposal_rating'];

$proposal_url = $row_proposals['proposal_url'];

$proposal_featured = $row_proposals['proposal_featured'];

if(empty($proposal_video)){
	
	$video_class = "";
	
}else{
	
	$video_class = "video-img";
	
}

$select_seller = "select * from sellers where seller_id='$proposal_seller_id'";

$run_seller = mysqli_query($con,$select_seller);

$row_seller = mysqli_fetch_array($run_seller);

$seller_user_name = $row_seller['seller_user_name'];

$select_buyer_reviews = "select * from buyer_reviews where proposal_id='$proposal_id'";

$run_buyer_reviews = mysqli_query($con,$select_buyer_reviews);

$count_reviews = mysqli_num_rows($run_buyer_reviews);


?>

<div class="col-lg-3 col-md-6 col-sm-6"><!--- col-lg-3 col-md-6 col-sm-6 Starts -->

<div class="proposal-div"><!--- proposal-div Starts -->

<div class="proposal_nav"><!--- proposal_nav Starts -->

<span class="float-left mt-2">

<strong class="ml-2 mr-1" > By </strong> <?php echo $seller_user_name; ?>

</span>

<span class="float-right mt-2">

<?php

for($proposal_i=0; $proposal_i<$proposal_rating; $proposal_i++){
	
	echo " <img class='rating' src='../images/user_rate_full.png' > ";
	
}

for($proposal_i=$proposal_rating; $proposal_i<5; $proposal_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank.png' > ";
	
}


?>

<span class="ml-1 mr-2"> (<?php echo $count_reviews; ?>) </span>

</span>

<div class="clearfix mb-2"></div>

</div><!--- proposal_nav Ends -->

<a href="<?php echo $proposal_url; ?>">

<hr class="m-0 p-0">

<img src="proposal_files/<?php echo $proposal_img1; ?>" class="resp-img">

</a>

<div class="text"><!-- text Starts -->

<h4>

<a href="<?php echo $proposal_url; ?>" class="<?php echo $video_class; ?>">

<?php echo $proposal_title; ?>

</a>

</h4>

<hr>


<p class="buttons clearfix">

<span class="float-right"> STARTING AT <strong class="price">$<?php echo $proposal_price; ?></strong> </span>

</p>

</div><!-- text Ends -->

<?php if($proposal_featured == "yes"){ ?>

<div class="ribbon"><!-- ribbon Starts -->

<div class="theribbon"> Featured </div>

<div class="ribbon-background"></div>

</div><!-- ribbon Ends -->

<?php } ?>

</div><!--- proposal-div Ends -->

</div><!--- col-lg-3 col-md-6 col-sm-6 Ends -->

<?php } ?>

</div><!-- row flex-wrap mb-3 Ends -->


</div><!--- col-md-10 offest-md-1 Ends -->


</div><!-- row Ends -->


<?php if(isset($_SESSION['seller_user_name'])){ ?>

<div class="row"><!-- row Starts -->

<div class="col-md-10 offset-md-1"><!--- col-md-10 offset-md-1 Starts -->

<h2 class="p-2 mt-3">

Your Recently Viewed Proposals

</h2>


<div class="row flex-wrap mb-3"><!-- row flex-wrap mb-3 Starts -->

<?php

$select_recent = "select * from recent_proposals where seller_id='$login_seller_id' order by 1 DESC LIMIT 0,4";

$run_recent = mysqli_query($con,$select_recent);

while($row_recent = mysqli_fetch_array($run_recent)){

$proposal_id = $row_recent['proposal_id'];

$get_proposals = "select * from proposals where proposal_id='$proposal_id' AND proposal_status='active'";

$run_proposals = mysqli_query($con,$get_proposals);

$row_proposals = mysqli_fetch_array($run_proposals);


$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_video = $row_proposals['proposal_video'];

$proposal_seller_id = $row_proposals['proposal_seller_id'];

$proposal_rating = $row_proposals['proposal_rating'];

$proposal_url = $row_proposals['proposal_url'];

$proposal_featured = $row_proposals['proposal_featured'];

if(empty($proposal_video)){
	
	$video_class = "";
	
}else{
	
	$video_class = "video-img";
	
}

$select_seller = "select * from sellers where seller_id='$proposal_seller_id'";

$run_seller = mysqli_query($con,$select_seller);

$row_seller = mysqli_fetch_array($run_seller);

$seller_user_name = $row_seller['seller_user_name'];

$select_buyer_reviews = "select * from buyer_reviews where proposal_id='$proposal_id'";

$run_buyer_reviews = mysqli_query($con,$select_buyer_reviews);

$count_reviews = mysqli_num_rows($run_buyer_reviews);




?>

<div class="col-lg-3 col-md-6 col-sm-6"><!--- col-lg-3 col-md-6 col-sm-6 Starts -->

<div class="proposal-div"><!--- proposal-div Starts -->

<div class="proposal_nav"><!--- proposal_nav Starts -->

<span class="float-left mt-2">

<strong class="ml-2 mr-1" > By </strong> <?php echo $seller_user_name; ?>

</span>

<span class="float-right mt-2">

<?php

for($proposal_i=0; $proposal_i<$proposal_rating; $proposal_i++){
	
	echo " <img class='rating' src='../images/user_rate_full.png' > ";
	
}

for($proposal_i=$proposal_rating; $proposal_i<5; $proposal_i++){
	
	echo " <img class='rating' src='../images/user_rate_blank.png' > ";
	
}


?>

<span class="ml-1 mr-2"> (<?php echo $count_reviews; ?>) </span>

</span>

<div class="clearfix mb-2"></div>

</div><!--- proposal_nav Ends -->

<a href="proposal.php">

<hr class="m-0 p-0">

<img src="proposal_files/<?php echo $proposal_img1; ?>" class="resp-img">

</a>

<div class="text"><!-- text Starts -->

<h4>

<a href="<?php echo $proposal_url; ?>" class="<?php echo $video_class; ?>">

<?php echo $proposal_title; ?>

</a>

</h4>

<hr>


<p class="buttons clearfix">

<span class="float-right"> STARTING AT <strong class="price">$<?php echo $proposal_price; ?></strong> </span>

</p>

</div><!-- text Ends -->

<?php if($proposal_featured == "yes"){ ?>

<div class="ribbon"><!-- ribbon Starts -->

<div class="theribbon"> Featured </div>

<div class="ribbon-background"></div>

</div><!-- ribbon Ends -->

<?php } ?>

</div><!--- proposal-div Ends -->

</div><!--- col-lg-3 col-md-6 col-sm-6 Ends -->


<?php } ?>


</div><!-- row flex-wrap mb-3 Ends -->


</div><!--- col-md-10 offest-md-1 Ends -->


</div><!-- row Ends -->

<?php } ?>

</div><!-- container-fluid bg-light Endss -->

<?php include("../includes/footer.php"); ?>

<script>

$(document).ready(function(){
	
$('#good').hide();

$('#bad').hide();
	
$('.all').click(function(){
	
$("#dropdown-button").html("Most Recent");
	
$(".all").attr('class','dropdown-item all active');
	
$(".bad").attr('class','dropdown-item bad');
	
$(".good").attr('class','dropdown-item good');
	
$("#all").show();

$("#good").hide();

$("#bad").hide();
	
});	



$('.good').click(function(){
	
$("#dropdown-button").html("Positive Reviews");
	
$(".all").attr('class','dropdown-item all');
	
$(".bad").attr('class','dropdown-item bad');
	
$(".good").attr('class','dropdown-item good active');
	
$("#all").hide();

$("#good").show();

$("#bad").hide();
	
});	


$('.bad').click(function(){
	
$("#dropdown-button").html("Negative Reviews");
	
$(".all").attr('class','dropdown-item all');
	
$(".bad").attr('class','dropdown-item bad active');
	
$(".good").attr('class','dropdown-item good');
	
$("#all").hide();

$("#good").hide();

$("#bad").show();
	
});	
	
	
});


</script>

</body>

</html>