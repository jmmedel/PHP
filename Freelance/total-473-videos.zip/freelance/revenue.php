<?php


session_start();

include("includes/db.php");

if(!isset($_SESSION['seller_user_name'])){
	
echo "<script>window.open('login.php','_self')</script>";
	
}

$login_seller_user_name = $_SESSION['seller_user_name'];

$select_login_seller = "select * from sellers where seller_user_name='$login_seller_user_name'";

$run_login_seller = mysqli_query($con,$select_login_seller);

$row_login_seller = mysqli_fetch_array($run_login_seller);

$login_seller_id = $row_login_seller['seller_id'];

$login_seller_paypal_email = $row_login_seller['seller_paypal_email'];

$get_payment_settings = "select * from payment_settings";

$run_payment_setttings = mysqli_query($con,$get_payment_settings);

$row_payment_settings = mysqli_fetch_array($run_payment_setttings);

$withdrawal_limit = $row_payment_settings['withdrawal_limit'];

?>

<!DOCTYPE html>

<html>

<head>

<title> Computerfever / Revenues </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="author" content="Mohammed Tahir Ahmed">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="styles/bootstrap.min.css" rel="stylesheet">

<link href="styles/style.css" rel="stylesheet">

<link href="styles/user_nav_style.css" rel="stylesheet">

<!--- stylesheet width modifications --->

<link href="styles/custom.css" rel="stylesheet">

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

<script src="js/jquery.min.js"></script>

</head>

<body>

<?php include("includes/user_header.php"); ?>

<div class="container"><!-- container Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-12 mt-5 mb-3"><!-- col-md-12 mt-5 mb-3 Starts -->

<h1 class="pull-left"> Revenues </h1>

<?php

$get_seller_accounts = "select * from seller_accounts where seller_id='$login_seller_id'";

$run_seller_accounts = mysqli_query($con,$get_seller_accounts);

$row_seller_accounts = mysqli_fetch_array($run_seller_accounts);

$current_balance = $row_seller_accounts['current_balance'];

$used_purchases = $row_seller_accounts['used_purchases'];

$pending_clearance = $row_seller_accounts['pending_clearance'];

$withdrawn = $row_seller_accounts['withdrawn'];

?>

<p class="lead pull-right">

Available for Withdrawal: <span class="font-weight-bold"> $<?php echo $current_balance; ?> </span>

</p>

</div><!-- col-md-12 mt-5 mb-3 Ends -->

<div class="col-md-12"><!-- col-md-12 Starts -->

<div class="card mb-3 rounded-0"><!-- card mb-3 rounded-0 Starts -->

<div class="card-body"><!-- card-body Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-3 text-center border-box"><!-- col-md-3 text-center border-box Starts -->

<p> Withdrawals </p>

<h2> $<?php echo $withdrawn; ?> </h2>

</div><!-- col-md-3 text-center border-box Ends -->


<div class="col-md-3 text-center border-box"><!-- col-md-3 text-center border-box Starts -->

<p> Used To Order proposals </p>

<h2> $<?php echo $used_purchases; ?> </h2>

</div><!-- col-md-3 text-center border-box Ends -->


<div class="col-md-3 text-center border-box"><!-- col-md-3 text-center border-box Starts -->

<p> Pending Clearance </p>

<h2> $<?php echo $pending_clearance; ?> </h2>

</div><!-- col-md-3 text-center border-box Ends -->

<div class="col-md-3 text-center border-box"><!-- col-md-3 text-center border-box Starts -->

<p> Available Income </p>

<h2> $<?php echo $current_balance; ?> </h2>

</div><!-- col-md-3 text-center border-box Ends -->

</div><!-- row Ends -->

</div><!-- card-body Ends -->

</div><!-- card mb-3 rounded-0 Ends -->

<label class="lead pull-left mt-1"> Withdraw: </label>


<?php if($current_balance >= $withdrawal_limit){ ?>

<button class="btn btn-default ml-2" data-toggle="modal" data-target="#paypal_withdraw_modal">

<i class="fa fa-paypal"></i> Paypal Account

</button>

<?php }else{ ?>

<button class="btn btn-default ml-2" onclick="return alert('You Must Have Minimum $<?php echo $withdrawal_limit; ?> Available Balance To Withdraw Revenue To Your Paypal Account.');">

<i class="fa fa-paypal"></i> Paypal Account

</button>

<?php } ?>

<div class="table-responsive box-table mt-4"><!-- table-responsive box-table mt-4 Starts -->


<table class="table table-hover"><!-- table table-hover Starts -->

<thead>

<tr>

<th>Date</th>

<th>For</th>

<th>Amount</th>

</tr>

</thead>

<tbody>

<?php

$get_revenues = "select * from revenues where seller_id='$login_seller_id' order by 1 DESC";

$run_revenues = mysqli_query($con,$get_revenues);

while($row_revenues = mysqli_fetch_array($run_revenues)){

$revenue_id = $row_revenues['revenue_id'];

$order_id = $row_revenues['order_id'];

$amount = $row_revenues['amount'];

$date = $row_revenues['date'];

$status = $row_revenues['status'];

?>

<tr>

<td> <?php echo $date; ?> </td>

<td>

<?php if($status == "pending"){ ?>

Order Revenue Pending Clearance (<a href="order_deatails.php?order_id=<?php echo $order_id; ?>" target="blank" > View Order </a>) 

<?php }else{ ?>

Order Revenue (<a href="order_deatails.php?order_id=<?php echo $order_id; ?>" target="blank" > View Order </a>) 
 
<?php } ?>
 
</td>

<td class="text-success"> +$<?php echo $amount; ?>.00 </td>

</tr>

<?php } ?>

</tbody>

</table><!-- table table-hover Ends -->

</div><!-- table-responsive box-table mt-4 Ends -->

</div><!-- col-md-12 Ends -->

</div><!-- row Ends -->

</div><!-- container Ends -->

<div id="paypal_withdraw_modal" class="modal fade"><!-- paypal_withdraw_modal modal fade Starts -->

<div class="modal-dialog"><!-- modal-dialog Starts -->

<div class="modal-content"><!-- modal-content Starts -->

<div class="modal-header"><!-- modal-header Starts -->

<h5 class="modal-title"> Withdraw Revenues To Paypal Account </h5>

<button class="close" data-dismiss="modal">

<span> &times; </span>

</button>

</div><!-- modal-header Ends -->

<div class="modal-body"><!-- modal-body Starts -->

<center><!-- center Starts -->

<?php if(empty($login_seller_paypal_email)){ ?>

<p class="lead">

For Withdraw Revenues To Your PayPal Account Please Add Your PayPal Account Email In

<a href="<?php echo $site_url; ?>/settings.php?account_settings">
Setting Account Actions Tab
</a>

</p>

<?php }else{ ?>

<p class="lead">

Your Revenues Will Be Sent To Follwing PayPal Account Email:

<br> <strong> <?php echo $login_seller_paypal_email; ?> </strong>

</p>

<form action="paypal_adaptive.php" method="post"><!-- form Starts -->

<div class="form-group row"><!-- form-group row Starts -->

<label class="col-md-3 col-form-label font-weight-bold">
Enter Amount
</label>

<div class="col-md-8"><!-- col-md-8 Starts -->

<div class="input-group">

<span class="input-group-addon font-weight-bold"> $ </span>

<input type="number" name="amount" class="form-control input-lg" min="<?php echo $withdrawal_limit; ?>" max="<?php echo $current_balance; ?>" placeholder="<?php echo $withdrawal_limit; ?> Minimum" required >

</div>

</div><!-- col-md-8 Ends -->

</div><!-- form-group row Ends -->

<div class="form-group row"><!-- form-group row Starts -->

<div class="col-md-8 offset-md-3">

<input type="submit" name="withdraw" value="Withdraw" class="btn btn-success form-control" >

</div>

</div><!-- form-group row Ends -->

</form><!-- form Ends -->

<?php } ?>

</center><!-- center Ends -->

</div><!-- modal-body Ends -->

<div class="modal-footer"><!-- modal-footer Starts -->

<button class="btn btn-default" data-dismiss="modal">
Close
</button>

</div><!-- modal-footer Ends -->

</div><!-- modal-content Ends -->

</div><!-- modal-dialog Ends -->

</div><!-- paypal_withdraw_modal modal fade Ends -->

<?php include("includes/footer.php"); ?>

</body>

</html>