<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	
?>

<?php

if(isset($_GET['delete_seller_skill'])){
	
$skill_id = $_GET['delete_seller_skill'];

$delete_skills_relation = "delete from skills_relation where skill_id='$skill_id'";
	
$run_delete_skills_relation = mysqli_query($con,$delete_skills_relation);
	
	
$delete_seller_skill = "delete from seller_skills where skill_id='$skill_id'";
	
$run_delete_seller_skill = mysqli_query($con,$delete_seller_skill);
	
if($run_delete_seller_skill){
	
echo "<script>alert('One Seller Skill Has Been Deleted.');</script>";

echo "<script>window.open('index.php?view_seller_skills','_self');</script>";

	
}
	
	
}

?>

<?php } ?>