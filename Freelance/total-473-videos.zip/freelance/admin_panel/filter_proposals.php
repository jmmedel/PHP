<?php

session_start();

include("includes/db.php");

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}

if((time() - $_SESSION['loggedin_time']) > 3600){
	
echo "<script>window.open('logout.php?session_expired','_self');</script>";
	
}


$admin_email = $_SESSION['admin_email'];

$get_admin = "select * from admins where admin_email='$admin_email'";

$run_admin = mysqli_query($con,$get_admin);

$row_admin = mysqli_fetch_array($run_admin);

$admin_id = $row_admin['admin_id'];

$admin_name = $row_admin['admin_name'];

$admin_image = $row_admin['admin_image'];

$admin_country = $row_admin['admin_country'];

$admin_job = $row_admin['admin_job'];

$admin_contact = $row_admin['admin_contact'];

$admin_about = $row_admin['admin_about'];


$get_proposals = "select * from proposals where proposal_status='pending'";

$run_proposals = mysqli_query($con,$get_proposals);

$count_proposals = mysqli_num_rows($run_proposals);



$get_orders = "select * from orders where order_active='yes'";

$run_orders = mysqli_query($con,$get_orders);

$count_orders = mysqli_num_rows($run_orders);


$get_sellers = "select * from sellers";

$run_sellers = mysqli_query($con,$get_sellers);

$count_sellers = mysqli_num_rows($run_sellers);


$get_support_tickets = "select * from support_tickets where status='open'";

$run_support_tickets = mysqli_query($con,$get_support_tickets);

$count_support_tickets = mysqli_num_rows($run_support_tickets);


$get_requests = "select * from buyer_requests where request_status='pending'";

$run_requests = mysqli_query($con,$get_requests);

$count_requests = mysqli_num_rows($run_requests);


$get_referrals = "select * from referrals where status='pending'";

$run_referrals = mysqli_query($con,$get_referrals);

$count_referrals = mysqli_num_rows($run_referrals);


?>

<!DOCTYPE HTML>

<html>

<head>

<title> Freelance Admin Panel </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<link rel="stylesheet" href="css/bootstrap.min.css">

<link rel="stylesheet" href="css/style.css">

<link rel="stylesheet" href="font-awesome/css/fontawesome-all.css">

<script src="js/jquery.min.js"> </script>

</head>

<body>

<div id="wrapper"><!--- wrapper Starts --->

<?php include("includes/sidebar.php"); ?>

<div id="page-wrapper"><!--- page-wrapper Starts --->

<div class="container-fluid"><!--- container-fluid Starts --->


<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="p-3 mb-3 filter-form"><!--- p-3 mb-3 filter-form Starts --->

<h2>Filter Proposals</h2>

<form class="form-inline" method="get" action="filter_proposals.php">

<div class="form-group">

<label> Delivery Time : </label>

<select name="delivery_id" required class="form-control mb-2 mr-sm-2 mb-sm-0">

<?php

$get_delivery_id = $_GET['delivery_id'];

$get_delivery_times = "select * from delivery_times where delivery_id='$get_delivery_id'";

$run_delivery_times = mysqli_query($con,$get_delivery_times);

$row_delivery_times = mysqli_fetch_array($run_delivery_times);
	
$delivery_id = $row_delivery_times['delivery_id'];

$delivery_title= $row_delivery_times['delivery_title'];
	
echo "<option value='$delivery_id'>$delivery_title</option>";
	


$get_delivery_times = "select * from delivery_times where not delivery_id='$get_delivery_id'";

$run_delivery_times = mysqli_query($con,$get_delivery_times);

while($row_delivery_times = mysqli_fetch_array($run_delivery_times)){
	
$delivery_id = $row_delivery_times['delivery_id'];

$delivery_title= $row_delivery_times['delivery_title'];
	
echo "<option value='$delivery_id'>$delivery_title</option>";
	
}

?>

</select>

</div>


<div class="form-group">

<label> Seller Level : </label>

<select name="level_id" required class="form-control mb-2 mr-sm-2 mb-sm-0">



<?php

$get_level_id = $_GET['level_id'];

$get_seller_levels = "select * from seller_levels where level_id='$get_level_id'";

$run_seller_levels = mysqli_query($con,$get_seller_levels);

$row_seller_levels = mysqli_fetch_array($run_seller_levels);
	
$level_id = $row_seller_levels['level_id'];

$level_title = $row_seller_levels['level_title'];
	
echo "<option value='$level_id'>$level_title</option>";
	


$get_seller_levels = "select * from seller_levels where not level_id='$get_level_id'";

$run_seller_levels = mysqli_query($con,$get_seller_levels);

while($row_seller_levels = mysqli_fetch_array($run_seller_levels)){
	
$level_id = $row_seller_levels['level_id'];

$level_title = $row_seller_levels['level_title'];
	
echo "<option value='$level_id'>$level_title</option>";
	
}

?>

</select>

</div>



<div class="form-group">

<label> Category : </label>

<select name="cat_id" required class="form-control mb-2 mr-sm-2 mb-sm-0">

<?php

$get_cat_id = $_GET['cat_id'];


$get_categories = "select * from categories where cat_id='$get_cat_id'";

$run_categories = mysqli_query($con,$get_categories);

$row_categories = mysqli_fetch_array($run_categories);
	
$cat_id = $row_categories['cat_id'];

$cat_title = $row_categories['cat_title'];
	
echo "<option value='$cat_id'>$cat_title</option>";

	


$get_categories = "select * from categories where not cat_id='$get_cat_id'";

$run_categories = mysqli_query($con,$get_categories);

while($row_categories = mysqli_fetch_array($run_categories)){
	
$cat_id = $row_categories['cat_id'];

$cat_title = $row_categories['cat_title'];
	
echo "<option value='$cat_id'>$cat_title</option>";

	
}

?>

</select>

</div>

<button type="submit" class="btn btn-default"> Filter Proposals </button>

</form>

</div><!--- p-3 mb-3 filter-form Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row mt-3"><!--- 2 row mt-3 Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Proposals

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="table-responsive"><!--- table-responsive mt-4 Starts --->

<table class="table table-hover table-bordered"><!--- table table-hover table-bordered Starts --->

<thead><!--- thead Starts --->

<tr>

<th>Proposal Title</th>

<th>Proposal Image</th>

<th>Proposal Price</th>

<th>Proposal Category</th>

<th>Proposal Order Queue</th>

<th>Proposal Options</th>

</tr>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php


$get_proposals = "select * from proposals where delivery_id='$get_delivery_id' or level_id='$get_level_id' or proposal_cat_id='$get_cat_id' order by 1 DESC";

$run_proposals = mysqli_query($con,$get_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_url = $row_proposals['proposal_url'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_cat_id = $row_proposals['proposal_cat_id'];

$proposal_status = $row_proposals['proposal_status'];


$select_orders = "select * from orders where proposal_id='$proposal_id' AND NOT order_status='complete' AND proposal_id='$proposal_id' AND NOT order_status='cancelled'";

$run_orders = mysqli_query($con,$select_orders);

$count_orders = mysqli_num_rows($run_orders);

$proposal_order_queue = $count_orders;


$get_categories = "select * from categories where cat_id='$proposal_cat_id'";

$run_categories = mysqli_query($con,$get_categories);

$row_categories = mysqli_fetch_array($run_categories);

$cat_title = $row_categories['cat_title'];

?>

<tr>

<td><?php echo $proposal_title; ?></td>

<td>

<img src="../proposals/proposal_files/<?php echo $proposal_img1; ?>" width="70" height="60">

</td>

<td><?php echo $proposal_price; ?></td>

<td><?php echo $cat_title; ?></td>

<td><?php echo $proposal_order_queue; ?></td>

<?php if($proposal_status == "active"){ ?>

<td>

<a href="../proposals/<?php echo $proposal_url; ?>" target="_blank">

<i class="fa fa-eye"></i> View

</a>

|

<a href="index.php?pause_proposal=<?php echo $proposal_id; ?>">

<i class="fa fa-pause-circle"></i> Pause

</a>

|

<a href="index.php?move_to_trash=<?php echo $proposal_id; ?>">

<i class="fa fa-trash-alt"></i> Trash

</a>

</td>

<?php }elseif($proposal_status == "pause"){ ?>


<td>

<a href="../proposals/<?php echo $proposal_url; ?>" target="_blank">

<i class="fa fa-eye"></i> View

</a>

|

<a href="#" class="text-secondary">

Paused

</a>

|

<a href="index.php?move_to_trash=<?php echo $proposal_id; ?>">

<i class="fa fa-trash-alt"></i> Trash

</a>

</td>


<?php }elseif($proposal_status == "pending"){ ?>

<td>

<a href="index.php?approve_proposal=<?php echo $proposal_id; ?>">

<i class="fa fa-pencil"></i> Approve Proposal

</a>

|

<a href="index.php?submit_modification=<?php echo $proposal_id; ?>">

<i class="fa fa-pencil"></i> Submit For Modification

</a>

</td>

<?php }elseif($proposal_status == "trash"){ ?>

<td>

<a href="index.php?restore_proposal=<?php echo $proposal_id; ?>">

<i class="fa fa-eye"></i> Restore Proposal

</a>

|

<a href="index.php?delete_proposal=<?php echo $proposal_id; ?>">

<i class="fa fa-trash-alt"></i> Delete Permanently

</a>

</td>


<?php } ?>

</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-hover table-bordered Ends --->

</div><!--- table-responsive mt-4 Ends --->



</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row mt-3 Ends --->

</div><!--- container-fluid Ends --->

</div><!--- page-wrapper Ends --->

</div><!--- wrapper Ends --->

<script src="js/popper.min.js"> </script>

<script src="js/bootstrap.min.js"> </script>

</body>

</html>