<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Categories

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt"></i> View Categories

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<table class="table table-bordered table-hover"><!--- table table-bordered table-hover Starts --->

<thead>

<tr>

<th>Category Id</th>

<th>Category Title</th>

<th>Category Description</th>

<th>Category Featured</th>

<th>Delete Category</th>

<th>Edit Category</th>

</tr>

</thead>


<tbody><!--- tbody Starts --->

<?php

$i = 0;

$get_cats = "select * from categories";

$run_cats = mysqli_query($con,$get_cats);

while($row_cats = mysqli_fetch_array($run_cats)){

$cat_id = $row_cats['cat_id'];

$cat_title = $row_cats['cat_title'];

$cat_desc = $row_cats['cat_desc'];

$cat_featured = $row_cats['cat_featured'];

$i++;


?>

<tr>

<td><?php echo $i; ?></td>

<td><?php echo $cat_title; ?></td>

<td width="400"><?php echo $cat_desc; ?></td>

<td><?php echo $cat_featured; ?></td>

<td>

<a href="index.php?delete_cat=<?php echo $cat_id; ?>" onclick="return confirm('Do you really want to delete this category and its child categories permanently.');">

<i class="fa fa-trash-alt"></i> Delete

</a>

</td>

<td>

<a href="index.php?edit_cat=<?php echo $cat_id; ?>">

<i class="fa fa-pencil-alt"></i> Edit

</a>

</td>



</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-bordered table-hover Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->



<?php } ?>