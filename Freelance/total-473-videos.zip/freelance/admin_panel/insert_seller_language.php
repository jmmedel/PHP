<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Insert Seller Language

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Insert Seller Language

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Seller Language Title : </label>

<div class="col-md-6">

<input type="text" name="language_title" class="form-control" required>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="submit" class="btn btn-primary form-control" value="Insert Seller Language">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['submit'])){
	
$language_title = mysqli_real_escape_string($con,$_POST['language_title']);
	
$insert_seller_language = "insert into seller_languages (language_title) values ('$language_title')";
	
$run_seller_language = mysqli_query($con,$insert_seller_language);
	
if($run_seller_language){
	
echo "<script>alert('One Seller Language Has Been Inserted.');</script>";
	
echo "<script>window.open('index.php?view_seller_languages','_self');</script>";

	
}
	
	
}


?>


<?php } ?>