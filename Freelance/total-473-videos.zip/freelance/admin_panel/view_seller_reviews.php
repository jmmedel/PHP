<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

$get_buyer_reviews = "select * from buyer_reviews";
	
$run_buyer_reviews = mysqli_query($con,$get_buyer_reviews);
	
$count_buyer_reviews = mysqli_num_rows($run_buyer_reviews);
	

$get_seller_reviews = "select * from seller_reviews";	

$run_seller_reviews = mysqli_query($con,$get_seller_reviews);

$count_seller_reviews = mysqli_num_rows($run_seller_reviews);
	

?>


<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Seller Reviews

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt"></i> View Seller Reviews

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<a href="index.php?view_buyer_reviews" class="mr-2">

Buyer Reviews (<?php echo $count_buyer_reviews; ?>)

</a>

<span class="mr-2">|</span>

<a href="index.php?view_seller_reviews" class="text-muted mr-2">

Seller Reviews (<?php echo $count_seller_reviews; ?>)

</a>

<div class="table-responsive mt-4"><!--- table-responsive mt-4 Starts --->

<table class="table table-bordered table-hover table-striped"><!--- table table-bordered table-hover table-striped Starts --->

<thead><!--- thead Starts --->

<tr>

<th>Order</th>

<th>Seller</th>

<th>Proposal</th>

<th>Rating</th>

<th>Delete</th>

</tr>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php

$per_page = 5;

$get_seller_reviews = "select * from seller_reviews order by 1 DESC LIMIT 0,$per_page";

$run_seller_reviews = mysqli_query($con,$get_seller_reviews);

while($row_seller_reviews = mysqli_fetch_array($run_seller_reviews)){
	
$review_id = $row_seller_reviews['review_id'];

$order_id = $row_seller_reviews['order_id'];

$review_seller_id = $row_seller_reviews['review_seller_id'];

$seller_rating = $row_seller_reviews['seller_rating'];
	
	
$sel_orders = "select * from orders where order_id='$order_id'";

$run_orders = mysqli_query($con,$sel_orders);

$row_orders = mysqli_fetch_array($run_orders);

$order_number = $row_orders['order_number'];

$proposal_id = $row_orders['proposal_id'];


$get_proposals = "select * from proposals where proposal_id='$proposal_id'";

$run_proposals = mysqli_query($con,$get_proposals);

$row_proposals = mysqli_fetch_array($run_proposals);

$proposal_title = $row_proposals['proposal_title'];


$get_sellers = "select * from sellers where seller_id='$review_seller_id'";

$run_sellers = mysqli_query($con,$get_sellers);

$row_sellers = mysqli_fetch_array($run_sellers);
	
$seller_user_name = $row_sellers['seller_user_name'];


?>

<tr>

<td>

<a href="index.php?single_order=<?php echo $order_id; ?>">

#<?php echo $order_number; ?>

</a>

</td>

<td>

<a href="index.php?single_seller=<?php echo $review_seller_id; ?>">

<?php echo $seller_user_name; ?>

</a>

</td>

<td><?php echo $proposal_title; ?></td>

<td><?php echo $seller_rating; ?></td>

<td>

<a href="index.php?delete_seller_review=<?php echo $review_id; ?>" class="btn btn-danger" onclick="return confirm('Do You Really Want To Delete This Review Permanently.')">

<i class="fa fa-trash-alt"></i> Delete Review

</a>

</td>


</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-bordered table-hover table-striped Ends --->

</div><!--- table-responsive mt-4 Ends --->

<div class="d-flex justify-content-center"><!--- d-flex justify-content-center Starts --->

<ul class="pagination"><!--- pagination Starts --->

<?php

/// Now Select All Data From Table

$query = "select * from seller_reviews order by 1 DESC";

$run_query = mysqli_query($con,$query);

/// Count The Total Records 

$total_records = mysqli_num_rows($run_query);

/// Using ceil function to divide the total records on per page

$total_pages = ceil($total_records / $per_page);

echo "

<li class='page-item'>

<a href='index.php?seller_reviews_pagination=1' class='page-link'>

First Page

</a>

</li>

";

for($i=1; $i<=$total_pages; $i++){
	
echo "

<li class='page-item'>

<a href='index.php?seller_reviews_pagination=".$i."' class='page-link'>

".$i."

</a>

</li>

";
	
	
}


echo "

<li class='page-item'>

<a href='index.php?seller_reviews_pagination=$total_pages' class='page-link'>

Last Page

</a>

</li>

";




?>

</ul><!--- pagination Ends --->

</div><!--- d-flex justify-content-center Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->



<?php } ?>