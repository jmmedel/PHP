
<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>



<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Layout Settings

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4"> Footer Layout Settings </h4>

</div><!--- card-header Ends --->

<div class="card-body row"><!--- card-body row Starts --->

<div class="col-md-3 border-right"><!--- col-md-3 border-right Starts --->

<ul class="nav nav-pills flex-column"><!--- nav nav-pills flex-column Starts --->

<li class="nav-item">

<a class="nav-link active" data-toggle="pill" href="#categories">

Categories Column

</a>

</li>


<li class="nav-item">

<a class="nav-link" data-toggle="pill" href="#about">

About Column

</a>

</li>


<li class="nav-item">

<a class="nav-link" data-toggle="pill" href="#support">

Support Column

</a>

</li>


<li class="nav-item">

<a class="nav-link" data-toggle="pill" href="#follow">

Follow Us Column

</a>

</li>


</ul><!--- nav nav-pills flex-column Ends --->

</div><!--- col-md-3 border-right Ends --->


<div class="col-md-9"><!--- col-md-9 Starts --->

<div class="tab-content"><!--- tab-content Starts --->

<div id="categories" class="tab-pane fade show active"><!--- categories tab-pane fade show active Starts --->

<?php

$get_footer_links = "select * from footer_links where link_section='categories'";

$run_footer_links = mysqli_query($con,$get_footer_links);

while($row_footer_links = mysqli_fetch_array($run_footer_links)){

$link_id = $row_footer_links['link_id'];

$link_title = $row_footer_links['link_title'];

$link_section = $row_footer_links['link_section'];


?>

<div class="mb-2">

<?php echo $link_title; ?> - <span> <?php echo ucwords($link_section); ?> </span>

<a href="index.php?delete_link=<?php echo $link_id; ?>" onclick="return confirm('Do you really want to delete this link permanently.')">

<i class="fa fa-trash"></i>

</a>

</div>

<?php } ?>

<div class="bg-light p-3"><!--- bg-light p-3 Starts --->

<h4>Add New Link</h4>

<form class="form-inline" method="post">

<input type="text" name="link_title" placeholder="Link Title" class="form-control mb-3 mr-sm-2 mb-sm-0">

<input type="text" name="link_url" placeholder="Link Url" class="form-control mb-3 mr-sm-2 mb-sm-0">

<button type="submit" class="btn btn-success form-control" name="add_link_category">

Add Link

</button>

</form>

</div><!--- bg-light p-3 Ends --->

<?php

if(isset($_POST['add_link_category'])){
	
$link_title = mysqli_real_escape_string($con,$_POST['link_title']);

$link_url = mysqli_real_escape_string($con,$_POST['link_url']);
	
	
$insert_link = "insert into footer_links (link_title,link_url,link_section) values ('$link_title','$link_url','categories')";
	
$run_link = mysqli_query($con,$insert_link);
	
if($run_link){
	
echo "<script>window.open('index.php?layout_settings','_self');</script>";
	
}	
	
	
}

?>

</div><!--- categories tab-pane fade show active Ends --->


<div id="about" class="tab-pane fade in"><!--- categories tab-pane fade in Starts --->

<?php

$get_footer_links = "select * from footer_links where link_section='about'";

$run_footer_links = mysqli_query($con,$get_footer_links);

while($row_footer_links = mysqli_fetch_array($run_footer_links)){

$link_id = $row_footer_links['link_id'];

$link_title = $row_footer_links['link_title'];

$link_section = $row_footer_links['link_section'];


?>

<div class="mb-2">

<?php echo $link_title; ?> - <span> <?php echo ucwords($link_section); ?> </span>

<a href="index.php?delete_link=<?php echo $link_id; ?>" onclick="return confirm('Do you really want to delete this link permanently.')">

<i class="fa fa-trash"></i>

</a>

</div>

<?php } ?>

<div class="bg-light p-3"><!--- bg-light p-3 Starts --->

<h4>Add New Link</h4>

<form class="form-inline" method="post">

<input type="text" name="link_title" placeholder="Link Title" class="form-control mb-3 mr-sm-2 mb-sm-0">

<input type="text" name="link_url" placeholder="Link Url" class="form-control mb-3 mr-sm-2 mb-sm-0">

<button type="submit" class="btn btn-success form-control" name="add_link_about">

Add Link

</button>

</form>

</div><!--- bg-light p-3 Ends --->

<?php

if(isset($_POST['add_link_about'])){
	
$link_title = mysqli_real_escape_string($con,$_POST['link_title']);

$link_url = mysqli_real_escape_string($con,$_POST['link_url']);
	
	
$insert_link = "insert into footer_links (link_title,link_url,link_section) values ('$link_title','$link_url','about')";
	
$run_link = mysqli_query($con,$insert_link);
	
if($run_link){
	
echo "<script>window.open('index.php?layout_settings','_self');</script>";
	
}	
	
	
}

?>

</div><!--- categories tab-pane fade in Ends --->



<div id="support" class="tab-pane fade in"><!--- support tab-pane fade in Starts --->

<?php

$get_footer_links = "select * from footer_links where link_section='support'";

$run_footer_links = mysqli_query($con,$get_footer_links);

while($row_footer_links = mysqli_fetch_array($run_footer_links)){

$link_id = $row_footer_links['link_id'];

$link_title = $row_footer_links['link_title'];

$link_section = $row_footer_links['link_section'];


?>

<div class="mb-2">

<?php echo $link_title; ?> - <span> <?php echo ucwords($link_section); ?> </span>

<a href="index.php?delete_link=<?php echo $link_id; ?>" onclick="return confirm('Do you really want to delete this link permanently.')">

<i class="fa fa-trash"></i>

</a>

</div>

<?php } ?>

<div class="bg-light p-3"><!--- bg-light p-3 Starts --->

<h4>Add New Link</h4>

<form class="form-inline" method="post">

<input type="text" name="link_title" placeholder="Link Title" class="form-control mb-3 mr-sm-2 mb-sm-0">

<input type="text" name="link_url" placeholder="Link Url" class="form-control mb-3 mr-sm-2 mb-sm-0">

<button type="submit" class="btn btn-success form-control" name="add_link_support">

Add Link

</button>

</form>

</div><!--- bg-light p-3 Ends --->

<?php

if(isset($_POST['add_link_support'])){
	
$link_title = mysqli_real_escape_string($con,$_POST['link_title']);

$link_url = mysqli_real_escape_string($con,$_POST['link_url']);
	
	
$insert_link = "insert into footer_links (link_title,link_url,link_section) values ('$link_title','$link_url','support')";
	
$run_link = mysqli_query($con,$insert_link);
	
if($run_link){
	
echo "<script>window.open('index.php?layout_settings','_self');</script>";
	
}	
	
	
}

?>

</div><!--- support tab-pane fade in Ends --->



<div id="follow" class="tab-pane fade in"><!--- follow tab-pane fade in Starts --->

<?php

$get_footer_links = "select * from footer_links where link_section='follow'";

$run_footer_links = mysqli_query($con,$get_footer_links);

while($row_footer_links = mysqli_fetch_array($run_footer_links)){

$link_id = $row_footer_links['link_id'];

$link_title = $row_footer_links['link_title'];

$link_section = $row_footer_links['link_section'];


?>

<div class="mb-2">

<?php echo $link_title; ?> - <span> <?php echo ucwords($link_section); ?> </span>

<a href="index.php?delete_link=<?php echo $link_id; ?>" onclick="return confirm('Do you really want to delete this link permanently.')">

<i class="fa fa-trash"></i>

</a>

</div>

<?php } ?>

<div class="bg-light p-3"><!--- bg-light p-3 Starts --->

<h4>Add New Link</h4>

<form class="form-inline" method="post">

<input type="text" name="link_title" placeholder="Link Title" class="form-control mb-3 mr-sm-2 mb-sm-0">

<input type="text" name="link_url" placeholder="Link Url" class="form-control mb-3 mr-sm-2 mb-sm-0">

<button type="submit" class="btn btn-success form-control" name="add_link_follow">

Add Link

</button>

</form>

</div><!--- bg-light p-3 Ends --->

<?php

if(isset($_POST['add_link_follow'])){
	
$link_title = mysqli_real_escape_string($con,$_POST['link_title']);

$link_url = mysqli_real_escape_string($con,$_POST['link_url']);
	
	
$insert_link = "insert into footer_links (link_title,link_url,link_section) values ('$link_title','$link_url','follow')";
	
$run_link = mysqli_query($con,$insert_link);
	
if($run_link){
	
echo "<script>window.open('index.php?layout_settings','_self');</script>";
	
}	
	
	
}

?>

</div><!--- follow tab-pane fade in Ends --->


</div><!--- tab-content Ends --->

</div><!--- col-md-9 Ends --->


</div><!--- card-body row Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

$css_file = "../styles/custom.css";

if(file_exists($css_file)){
	
$css_file_data = file_get_contents($css_file);
	
}

?>

<div class="row mt-4"><!--- 3 row mt-4 Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4"> Custom Css </h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<p class="lead"> Enter Your Custom Modifications Css Styles Here. </p>

<form action="" method="post"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<div class="col-md-12">

<textarea name="custom_css" class="form-control" rows="23"><?php echo $css_file_data; ?></textarea>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3"></label>

<div class="col-md-9">

<input type="submit" name="save_changes" value="Save Changes" class="btn btn-success float-right">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 3 row mt-4 Ends --->

<?php

if(isset($_POST['save_changes'])){

$newData = $_POST['custom_css'];

$handle = fopen($css_file, "w");

fwrite($handle, $newData);

fclose($handle);

echo "<script>alert('Custom Css Has Been Updated Successfully.');</script>";

echo "<script>window.open('index.php?layout_settings','_self');</script>";


}

?>


<?php } ?>