
<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Inbox Conversations

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts ---> 

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Inbox Conversations

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-bordered table-hover links-table"><!--- table table-bordered table-hover links-table Starts --->

<thead>

<tr>

<th> Sender : </th>

<th> Receiver : </th>

<th> Message : </th>

<th> Attachment : </th>

<th> Updated : </th>


</tr>

</thead>


<tbody><!--- tbody Starts --->

<?php 

$per_page = 5;

$get_inbox_sellers = "select * from inbox_sellers where not message_status='empty' order by 1 DESC LIMIT 0,$per_page";

$run_inbox_sellers = mysqli_query($con,$get_inbox_sellers);

while($row_inbox_sellers = mysqli_fetch_array($run_inbox_sellers)){

$sender_id = $row_inbox_sellers['sender_id'];

$receiver_id = $row_inbox_sellers['receiver_id'];

$message_id = $row_inbox_sellers['message_id'];

$message_group_id = $row_inbox_sellers['message_group_id'];


$get_inbox_messages = "select * from inbox_messages where message_id='$message_id'";

$run_inbox_messages = mysqli_query($con,$get_inbox_messages);

$row_inbox_messages = mysqli_fetch_array($run_inbox_messages);

$message_file = $row_inbox_messages['message_file'];

$message_desc = substr($row_inbox_messages['message_desc'],0,100);

$message_date = $row_inbox_messages['message_date'];


$select_sender = "select * from sellers where seller_id='$sender_id'";

$run_sender = mysqli_query($con,$select_sender);

$row_sender = mysqli_fetch_array($run_sender);

$sender_user_name = $row_sender['seller_user_name'];


$select_receiver = "select * from sellers where seller_id='$receiver_id'";

$run_receiver = mysqli_query($con,$select_receiver);

$row_receiver = mysqli_fetch_array($run_receiver);

$receiver_user_name = $row_receiver['seller_user_name'];


?>

<tr onclick="location.href='index.php?single_inbox_message=<?php echo $message_group_id; ?>'">

<td><?php echo $sender_user_name; ?></td>

<td><?php echo $receiver_user_name; ?></td>

<td width="300"><?php echo $message_desc; ?></td>

<td>

<?php 

if(empty($message_file)){
	
echo "No File Attach";
	
}else{

?>

<a href="#">

<i class="fa fa-download"></i> <?php echo $message_file; ?>

</a>

<?php } ?>

</td>

<td><?php echo $message_date; ?></td>

</tr>

<?php } ?>

</tbody><!--- tbody Ends --->


</table><!--- table table-bordered table-hover links-table Ends --->

</div><!--- table-responsive Ends --->

<div class="d-flex justify-content-center"><!--- d-flex justify-content-center Starts --->

<ul class="pagination"><!--- pagination Starts --->

<?php 

/// Now Select All From Data From Table

$query = "select * from inbox_sellers where not message_status='empty' order by 1 DESC";

$run_query = mysqli_query($con,$query);

/// Count The Total Records 

$total_records = mysqli_num_rows($run_query);

/// Using ceil function to divide the total records on per page

$total_pages = ceil($total_records / $per_page);

echo "

<li class='page-item'>

<a href='index.php?inbox_conversations_pagination=1' class='page-link'>

First Page

</a>

</li>

";

for($i=1; $i<=$total_pages; $i++){
	
echo "

<li class='page-item'>

<a href='index.php?inbox_conversations_pagination=".$i."' class='page-link'>

".$i."

</a>

</li>

";
	
}

echo "

<li class='page-item'>

<a href='index.php?inbox_conversations_pagination=$total_pages' class='page-link'>

Last Page

</a>

</li>

";


?>

</ul><!--- pagination Ends --->

</div><!--- d-flex justify-content-center Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends ---> 

</div><!--- 2 row Ends --->


<?php } ?>