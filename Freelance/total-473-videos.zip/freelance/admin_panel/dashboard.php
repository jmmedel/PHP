
<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<h1> Dashboard </h1>

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-xl-3 col-lg-6 col-md-6"><!--- col-xl-3 col-lg-6 col-md-6 Starts --->

<div class="card text-white border-primary mb-xl-0 mb-lg-3 mb-sm-3 mb-3"><!--- card text-white border-primary mb-xl-0 mb-lg-3 mb-sm-3 mb-3 Starts --->

<div class="card-header bg-primary"><!--- card-header bg-primary Starts --->

<div class="row"><!--- row Starts --->

<div class="col-3"><!-- col-3 Starts --->

<i class="fa fa-table fa-5x"></i>

</div><!-- col-3 Ends --->

<div class="col-9 text-right"><!--- col-9 text-right Starts --->

<div class="huge"> <?php echo $count_proposals; ?> </div>

<div class="badge badge-danger"> Proposals </div> <br>

Pending Approvel

</div><!--- col-9 text-right Ends --->

</div><!--- row Ends --->

</div><!--- card-header bg-primary Ends --->


<a href="index.php?view_proposals"><!--- a Starts --->

<div class="card-footer"><!--- card-footer Starts --->

<span class="float-left"> View Details </span>

<span class="float-right"> <i class="fa fa-arrow-circle-right"></i> </span>

<div class="clearfix"></div>

</div><!--- card-footer Ends --->

</a><!--- a Ends --->


</div><!--- card text-white border-primary mb-xl-0 mb-lg-3 mb-sm-3 mb-3 Ends --->


</div><!--- col-xl-3 col-lg-6 col-md-6 Ends --->




<div class="col-xl-3 col-lg-6 col-md-6"><!--- col-xl-3 col-lg-6 col-md-6 Starts --->

<div class="card text-white border-success mb-xl-0 mb-lg-3 mb-sm-3 mb-3"><!--- card text-white border-primary mb-xl-0 mb-lg-3 mb-sm-3 mb-3 Starts --->

<div class="card-header bg-success"><!--- card-header bg-primary Starts --->

<div class="row"><!--- row Starts --->

<div class="col-3"><!-- col-3 Starts --->

<i class="fa fa-list fa-5x"></i>

</div><!-- col-3 Ends --->

<div class="col-9 text-right"><!--- col-9 text-right Starts --->

<div class="huge"> <?php echo $count_sellers; ?> </div>

<div class="text-caption"> Sellers </div>

</div><!--- col-9 text-right Ends --->

</div><!--- row Ends --->

</div><!--- card-header bg-primary Ends --->


<a href="index.php?view_sellers"><!--- a Starts --->

<div class="card-footer"><!--- card-footer Starts --->

<span class="float-left"> View Details </span>

<span class="float-right"> <i class="fa fa-arrow-circle-right"></i> </span>

<div class="clearfix"></div>

</div><!--- card-footer Ends --->

</a><!--- a Ends --->


</div><!--- card text-white border-primary mb-xl-0 mb-lg-3 mb-sm-3 mb-3 Ends --->


</div><!--- col-xl-3 col-lg-6 col-md-6 Ends --->



<div class="col-xl-3 col-lg-6 col-md-6"><!--- col-xl-3 col-lg-6 col-md-6 Starts --->

<div class="card text-white border-warning mb-xl-0 mb-lg-3 mb-sm-3 mb-3"><!--- card text-white border-primary mb-xl-0 mb-lg-3 mb-sm-3 mb-3 Starts --->

<div class="card-header bg-warning"><!--- card-header bg-primary Starts --->

<div class="row"><!--- row Starts --->

<div class="col-3"><!-- col-3 Starts --->

<i class="fa fa-plane fa-5x"></i>

</div><!-- col-3 Ends --->

<div class="col-9 text-right"><!--- col-9 text-right Starts --->

<div class="huge"> <?php echo $count_orders; ?> </div>

<div class="text-caption"> Active Orders </div>

</div><!--- col-9 text-right Ends --->

</div><!--- row Ends --->

</div><!--- card-header bg-primary Ends --->


<a href="index.php?view_orders"><!--- a Starts --->

<div class="card-footer"><!--- card-footer Starts --->

<span class="float-left"> View Details </span>

<span class="float-right"> <i class="fa fa-arrow-circle-right"></i> </span>

<div class="clearfix"></div>

</div><!--- card-footer Ends --->

</a><!--- a Ends --->


</div><!--- card text-white border-primary mb-xl-0 mb-lg-3 mb-sm-3 mb-3 Ends --->


</div><!--- col-xl-3 col-lg-6 col-md-6 Ends --->



<div class="col-xl-3 col-lg-6 col-md-6"><!--- col-xl-3 col-lg-6 col-md-6 Starts --->

<div class="card text-white border-danger mb-xl-0 mb-lg-3 mb-sm-3 mb-3"><!--- card text-white border-primary mb-xl-0 mb-lg-3 mb-sm-3 mb-3 Starts --->

<div class="card-header bg-danger"><!--- card-header bg-primary Starts --->

<div class="row"><!--- row Starts --->

<div class="col-3"><!-- col-3 Starts --->

<i class="fa fa-phone-square fa-5x"></i>

</div><!-- col-3 Ends --->

<div class="col-9 text-right"><!--- col-9 text-right Starts --->

<div class="huge"> <?php echo $count_support_tickets; ?> </div>

<div class="text-caption"> Open Support Requests </div>

</div><!--- col-9 text-right Ends --->

</div><!--- row Ends --->

</div><!--- card-header bg-primary Ends --->


<a href="index.php?view_proposals"><!--- a Starts --->

<div class="card-footer"><!--- card-footer Starts --->

<span class="float-left"> View Details </span>

<span class="float-right"> <i class="fa fa-arrow-circle-right"></i> </span>

<div class="clearfix"></div>

</div><!--- card-footer Ends --->

</a><!--- a Ends --->


</div><!--- card text-white border-primary mb-xl-0 mb-lg-3 mb-sm-3 mb-3 Ends --->


</div><!--- col-xl-3 col-lg-6 col-md-6 Ends --->



</div><!--- 2 row Ends --->



<div class="row mt-5"><!--- 3 row Starts --->

<div class="col-md-8"><!--- col-md-8 Starts --->

<div class="card mb-3"><!--- card mb-3 Starts --->

<div class="card-header"><!--- card-header Starts --->

<h5 class="h5" > <i class="fa fa-money-bill-alt fa-fw"></i>  Website Statistics </h5>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="table-responsive"><!--- table-responsive Starts ---> 

<table class="table table-bordered table-hover links-table"><!--- table table-bordered table-hover links-table Starts --->

<thead>

<tr>

<th> Summary : </th>

<th> Results : </th>

</tr>

</thead>

<tbody>

<tr onclick="location.href='index.php?view_support_rqeuests'" class="hover-blue"> 

<td> Open Support Requests </td>

<td> <?php echo $count_support_tickets; ?> </td>

</tr>

<tr onclick="location.href='index.php?view_proposals'" class="hover-blue"> 

<td> Proposals Awaiting Approvel </td>

<td> <?php echo $count_proposals; ?> </td>

</tr>


<tr onclick="location.href='index.php?buyer_requests'" class="hover-blue"> 

<td> Buyer Requests Awaiting Approvel </td>

<td> <?php echo $count_requests; ?> </td>

</tr>


<tr onclick="location.href='index.php?view_refferrals'" class="hover-blue"> 

<td>  Referrals Awaiting Approvel </td>

<td> <?php echo $count_referrals; ?> </td>

</tr>


</tbody>

</table><!--- table table-bordered table-hover links-table Ends --->

</div><!--- table-responsive Ends ---> 

</div><!--- card-body Ends --->

</div><!--- card mb-3 Ends --->

</div><!--- col-md-8 Ends --->


<div class="col-md-4"><!--- col-md-4 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-body"><!--- card-body Starts --->

<div class="admin-info mb-3"><!--- admin-info mb-3 Starts --->

<img src="admin_images/<?php echo $admin_image; ?>" class="rounded img-fluid">

<div class="admin-info-title"><!--- admin-info-title Starts --->

<div class="admin-info-inner"> <?php echo $admin_name; ?> </div>

<div class="admin-info-type"> <?php echo $admin_job; ?> </div>

</div><!--- admin-info-title Ends --->

</div><!--- admin-info mb-3 Ends --->

<div class="mb-3"><!--- mb-3 Starts --->

<div class="widget-content-expanded"><!--- widget-content-expanded Starts --->

<i class="fa fa-user"></i> <span> Email : </span> <?php echo $admin_email; ?> <br>

<i class="fa fa-user"></i> <span> Country : </span> <?php echo $admin_country; ?> <br>

<i class="fa fa-user"></i> <span> Contact : </span> <?php echo $admin_contact; ?> <br>

</div><!--- widget-content-expanded Ends --->

<hr class="dotted">

<h5 class="text-muted">About</h5>

<p>

<?php echo $admin_about; ?>

</p>

</div><!--- mb-3 Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-md-4 Ends --->


</div><!--- 3 row Ends --->



