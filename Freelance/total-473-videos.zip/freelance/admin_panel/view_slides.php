<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Slides

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4"><!--- h4 Starts --->

<i class="fa fa-money-bill-alt"></i> View Slides

</h4><!--- h4 Ends --->

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="row"><!--- row Starts --->

<?php

$get_slides = "select * from slider";

$run_slides = mysqli_query($con,$get_slides);

while($row_slides = mysqli_fetch_array($run_slides)){

$slide_id = $row_slides['slide_id'];

$slide_name = $row_slides['slide_name'];

$slide_image = $row_slides['slide_image'];


?>

<div class="col-lg-3 col-md-6 mb-lg-3 mb-3"><!--- col-lg-3 col-md-6 mb-lg-0 mb-3 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header">

<h5 class="h5 text-center"> <?php echo $slide_name; ?> </h5>

</div>

<div class="card-body"><!--- card-body Starts --->

<img src="../slides_images/<?php echo $slide_image; ?>" class="img-fluid">

</div><!--- card-body Ends --->

<div class="card-footer"><!--- card-footer Starts --->

<a href="index.php?delete_slide=<?php echo $slide_id; ?>" class="float-left">

<i class="fa fa-trash-alt"></i> Delete

</a>

<a href="index.php?edit_slide=<?php echo $slide_id; ?>" class="float-right">

<i class="fa fa-pencil-alt"></i> Edit

</a>

<div class="clearfix"></div>

</div><!--- card-footer Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-3 col-md-6 mb-lg-0 mb-3 Ends --->

<?php } ?>

</div><!--- row Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->



<?php } ?>