<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<?php

if(isset($_GET['delete_order_file'])){
	
$file = $_GET['delete_order_file'];
	
$path = "../order_files/$file";	

if(unlink($path)){
	
echo "<script>alert('Your File $file Has been Deleted.');</script>";
	
echo "<script>window.open('index.php?view_order_files','_self');</script>";

	
}

	
}

?>

<?php } ?>