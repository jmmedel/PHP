<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Insert Category

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->





<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt"></i> Insert Category

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post" enctype="multipart/form-data"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Category Title : </label>

<div class="col-md-6">

<input type="text" name="cat_title" class="form-control" required>

</div>

</div><!--- form-group row Ends --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Category Description : </label>

<div class="col-md-6">

<textarea name="cat_desc" class="form-control" required></textarea>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Show as Featured Category : </label>

<div class="col-md-6">

<input type="radio" name="cat_featured" value="yes" required>

<label> Yes </label>

<input type="radio" name="cat_featured" value="no" required>

<label> No </label>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Category Image : </label>

<div class="col-md-6">

<input type="file" name="cat_image" class="form-control">

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="submit" value="Insert Category" class="btn btn-primary form-control">

</div>

</div><!--- form-group row Ends --->



</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['submit'])){
	
$cat_title = mysqli_real_escape_string($con,$_POST['cat_title']);

$cat_desc = mysqli_real_escape_string($con,$_POST['cat_desc']);

$cat_featured = mysqli_real_escape_string($con,$_POST['cat_featured']);
	
$cat_image = $_FILES['cat_image']['name'];

$tmp_cat_image = $_FILES['cat_image']['tmp_name'];
	
move_uploaded_file($tmp_cat_image,"../cat_images/$cat_image");
	
	
$insert_cat = "insert into categories (cat_title,cat_desc,cat_image,cat_featured) values ('$cat_title','$cat_desc','$cat_image','$cat_featured')";
	
$run_cat = mysqli_query($con,$insert_cat);	

if($run_cat){
	
echo "<script>alert('One Category Has Been Inserted.');</script>";
	
echo "<script>window.open('index.php?view_cats','_self');</script>";

	
	
}
	
	
	
	
}



?>


<?php } ?>