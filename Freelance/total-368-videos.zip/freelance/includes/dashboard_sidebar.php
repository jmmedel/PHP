
<div class="card mb-3"><!--- card mb-3 Starts --->

<div class="card-header"><!--- card-header Starts --->

<h5 class="h5"> My Contacts </h5>

<ul class="nav nav-tabs card-header-tabs"><!--- nav nav-tabs card-header-tabs Starts --->

<li class="nav-item">

<a href="#my_buyers" data-toggle="tab" class="nav-link active"> My Buyers </a>

</li>

<li class="nav-item">

<a href="#my_sellers" data-toggle="tab" class="nav-link"> My Sellers </a>

</li>

</ul><!--- nav nav-tabs card-header-tabs Ends --->

</div><!--- card-header Ends --->


<div class="card-body"><!--- card-body Starts --->


<div class="tab-content"><!--- tab-content Starts --->

<div id="my_buyers" class="tab-pane fade show active"><!--- tab-pane fade show active Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-hover"><!--- table table-hover Starts --->

<thead><!--- thead Starts --->

<tr>

<th class="gray"> Buyer Names </th>

</tr>

</thead><!--- thead Ends --->


<tbody><!--- tbody Starts --->


<?php

$sel_my_buyers = "select * from my_buyers where seller_id='$login_seller_id'";

$run_my_buyers = mysqli_query($con,$sel_my_buyers);

while($row_my_buyers = mysqli_fetch_array($run_my_buyers)){

$buyer_id = $row_my_buyers['buyer_id'];

$select_buyer = "select * from sellers where seller_id='$buyer_id'";

$run_buyer = mysqli_query($con,$select_buyer);

$row_buyer = mysqli_fetch_array($run_buyer);

$buyer_id = $row_buyer['seller_id'];

$buyer_user_name = $row_buyer['seller_user_name'];

$buyer_image = $row_buyer['seller_image'];



?>

<tr>

<td>

<img src="user_images/<?php echo $buyer_image; ?>" class="rounded-circle" width="50" height="50">

<div class="contact-title"><!--- contact-title Starts --->

<h6> <?php echo $buyer_user_name; ?> </h6>

<a href="<?php echo $buyer_user_name; ?>" target="_blank"> User Profile </a>

|

<a href="conversations/message.php?seller_id=<?php echo $buyer_id; ?>" target="_blank"> History </a>

</div><!--- contact-title Ends --->

</td>

</tr>


<?php } ?>


</tbody><!--- tbody Ends --->


</table><!--- table table-hover Ends --->

</div><!--- table-responsive Ends --->

</div><!--- tab-pane fade show active Ends --->


<div id="my_sellers" class="tab-pane fade"><!--- tab-pane fade Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-hover"><!--- table table-hover Starts --->

<thead><!--- thead Starts --->

<tr>

<th class="gray"> Seller Names </th>

</tr>

</thead><!--- thead Ends --->


<tbody><!--- tbody Starts --->

<?php

$sel_my_sellers = "select * from my_sellers where buyer_id='$login_seller_id'";

$run_my_sellers = mysqli_query($con,$sel_my_sellers);

while($row_my_sellers = mysqli_fetch_array($run_my_sellers)){

$seller_id = $row_my_sellers['seller_id'];


$select_seller = "select * from sellers where seller_id='$seller_id'";

$run_seller = mysqli_query($con,$select_seller);

$row_seller = mysqli_fetch_array($run_seller);

$seller_id = $row_seller['seller_id'];

$seller_user_name = $row_seller['seller_user_name'];

$seller_image = $row_seller['seller_image'];

?>

<tr>

<td>

<img src="user_images/<?php echo $seller_image; ?>" class="rounded-circle" width="50" height="50">

<div class="contact-title"><!--- contact-title Starts --->

<h6> <?php echo $seller_user_name; ?> </h6>

<a href="<?php echo $seller_user_name; ?>" target="_blank"> User Profile </a>

|

<a href="conversations/message.php?seller_id=<?php echo $seller_id; ?>" target="_blank"> History </a>

</div><!--- contact-title Ends --->

</td>

</tr>

<?php } ?>

</tbody><!--- tbody Ends --->


</table><!--- table table-hover Ends --->

</div><!--- table-responsive Ends --->

</div><!--- tab-pane fade Ends --->


</div><!--- tab-content Ends --->


</div><!--- card-body Ends --->


</div><!--- card mb-3 Ends --->


<div class="card mt-3 mb-3"><!--- card mt-3 mb-3 Starts --->


<div class="card-body"><!--- card-body Starts --->

<h1 align="center"> Place Your Add Here </h1>

</div><!--- card-body Ends --->


</div><!--- card mt-3 mb-3 Ends --->




