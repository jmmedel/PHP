
<div class="card rounded-0 mb-3"><!--- card rounded-0 mb-3 Starts --->

<div class="card-body"><!-- card-body Starts -->

<h3> Hi, fixmywebsite </h3>

<p> Request the service you are looking for. </p>

<a class="btn btn-success btn-block" href="requests/post_request.php" target="blank">

Post A Request

</a>

</div><!-- card-body Ends -->

</div><!--- card rounded-0 mb-3 Ends --->


<div class="card rounded-0 mb-3"><!--- card rounded-0 mb-3 Starts --->

<div class="card-header"><!--- card-header Starts --->

<h5> BUY IT AGAIN </h5>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="row mb-3"><!--- row mb-3 Starts --->

<img class="col-lg-4 col-md-12 col-sm-4 col-4 img-fluid user-home-img-responsive" src="proposals/proposal_files/youtube-seo-1.jpg">

<p class="col-lg-8 col-md-12 col-sm-8 col-8 user-home-title-responsive">

<a href="proposals/proposal.php">

I Will Do Viral Youtube Seo Social Media Promotion

</a>

</p>

</div><!--- row mb-3 Ends --->


<div class="row mb-3"><!--- row mb-3 Starts --->

<img class="col-lg-4 col-md-12 col-sm-4 col-4 img-fluid user-home-img-responsive" src="proposals/proposal_files/youtube-seo-1.jpg">

<p class="col-lg-8 col-md-12 col-sm-8 col-8 user-home-title-responsive">

<a href="proposals/proposal.php">

I Will Do Viral Youtube Seo Social Media Promotion

</a>

</p>

</div><!--- row mb-3 Ends --->


<div class="row mb-3"><!--- row mb-3 Starts --->

<img class="col-lg-4 col-md-12 col-sm-4 col-4 img-fluid user-home-img-responsive" src="proposals/proposal_files/youtube-seo-1.jpg">

<p class="col-lg-8 col-md-12 col-sm-8 col-8 user-home-title-responsive">

<a href="proposals/proposal.php">

I Will Do Viral Youtube Seo Social Media Promotion

</a>

</p>

</div><!--- row mb-3 Ends --->

</div><!--- card-body Ends --->

</div><!--- card rounded-0 mb-3 Ends --->




<div class="card rounded-0 mb-3"><!--- card rounded-0 mb-3 Starts --->

<div class="card-header"><!--- card-header Starts --->

<h5> RECENTLY VIEWED </h5>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="row mb-3"><!--- row mb-3 Starts --->

<img class="col-lg-4 col-md-12 col-sm-4 col-4 img-fluid user-home-img-responsive" src="proposals/proposal_files/youtube-seo-1.jpg">

<p class="col-lg-8 col-md-12 col-sm-8 col-8 user-home-title-responsive">

<a href="proposals/proposal.php">

I Will Do Viral Youtube Seo Social Media Promotion

</a>

</p>

</div><!--- row mb-3 Ends --->


<div class="row mb-3"><!--- row mb-3 Starts --->

<img class="col-lg-4 col-md-12 col-sm-4 col-4 img-fluid user-home-img-responsive" src="proposals/proposal_files/youtube-seo-1.jpg">

<p class="col-lg-8 col-md-12 col-sm-8 col-8 user-home-title-responsive">

<a href="proposals/proposal.php">

I Will Do Viral Youtube Seo Social Media Promotion

</a>

</p>

</div><!--- row mb-3 Ends --->


<div class="row mb-3"><!--- row mb-3 Starts --->

<img class="col-lg-4 col-md-12 col-sm-4 col-4 img-fluid user-home-img-responsive" src="proposals/proposal_files/youtube-seo-1.jpg">

<p class="col-lg-8 col-md-12 col-sm-8 col-8 user-home-title-responsive">

<a href="proposals/proposal.php">

I Will Do Viral Youtube Seo Social Media Promotion

</a>

</p>

</div><!--- row mb-3 Ends --->

</div><!--- card-body Ends --->

</div><!--- card rounded-0 mb-3 Ends --->



