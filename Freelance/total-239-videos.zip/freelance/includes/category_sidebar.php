
<div class="card border-primary mb-3"><!--- card border-primary mb-3 Starts -->

<div class="card-header bg-primary"><!-- card-header bg-primary Starts -->

<h3 class="h5 text-white"> Categories </h3>

</div><!-- card-header bg-primary Ends -->

<div class="card-body"><!-- card-body Starts -->

<ul class="nav flex-column" id="proposal_category"><!--- nav flex-column Starts -->

<li class="nav-item"><!-- nav-item Starts -->

<span class="nav-link active"><!-- nav-link active Starts -->

<a href="#"> Graphic Design </a>

<a href="#" class="h5 text-success pull-right" data-toggle="collapse" data-target="#cat_1">

<i class="fa fa-arrow-circle-down"></i>

</a>

</span><!-- nav-link active Ends -->

<ul id="cat_1" class="collapse"><!-- collapse Starts -->

<li>

<a class="nav-link active" href="category.php?cat_child_id">

Logo Design

</a>

</li>

<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>


<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>


<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>

</ul><!-- collapse Ends -->

</li><!-- nav-item Ends -->


<li class="nav-item"><!-- nav-item Starts -->

<span class="nav-link"><!-- nav-link Starts -->

<a href="#"> Graphic Design </a>

<a href="#" class="h5 text-success pull-right" data-toggle="collapse" data-target="#cat_2">

<i class="fa fa-arrow-circle-down"></i>

</a>

</span><!-- nav-link Ends -->

<ul id="cat_2" class="collapse"><!-- collapse Starts -->

<li>

<a class="nav-link active" href="category.php?cat_child_id">

Logo Design

</a>

</li>

<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>


<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>


<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>

</ul><!-- collapse Ends -->

</li><!-- nav-item Ends -->


<li class="nav-item"><!-- nav-item Starts -->

<span class="nav-link"><!-- nav-link Starts -->

<a href="#"> Graphic Design </a>

<a href="#" class="h5 text-success pull-right" data-toggle="collapse" data-target="#cat_3">

<i class="fa fa-arrow-circle-down"></i>

</a>

</span><!-- nav-link Ends -->

<ul id="cat_3" class="collapse"><!-- collapse Starts -->

<li>

<a class="nav-link active" href="category.php?cat_child_id">

Logo Design

</a>

</li>

<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>


<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>


<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>

</ul><!-- collapse Ends -->

</li><!-- nav-item Ends -->


<li class="nav-item"><!-- nav-item Starts -->

<span class="nav-link"><!-- nav-link Starts -->

<a href="#"> Graphic Design </a>

<a href="#" class="h5 text-success pull-right" data-toggle="collapse" data-target="#cat_4">

<i class="fa fa-arrow-circle-down"></i>

</a>

</span><!-- nav-link Ends -->

<ul id="cat_4" class="collapse"><!-- collapse Starts -->

<li>

<a class="nav-link active" href="category.php?cat_child_id">

Logo Design

</a>

</li>

<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>


<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>


<li>

<a class="nav-link" href="category.php?cat_child_id">

Logo Design

</a>

</li>

</ul><!-- collapse Ends -->

</li><!-- nav-item Ends -->

</ul><!--- nav flex-column Ends -->

</div><!-- card-body Ends -->


</div><!--- card border-primary mb-3 Ends -->



<div class="card border-primary mb-3"><!-- card border-primary mb-3 Starts -->

<div class="card-body pb-2 pt-3"><!-- card-body pb-2 pt-3 Starts -->

<ul class="nav flex-column"><!-- nav flex-column Starts -->

<li class="nav-item checkbox checkbox-primary"><!-- nav-item checkbox checkbox-primary Starts -->

<label>

<input type="checkbox" value="1" class="get_online_sellers">

<span> Show Onlinw Sellers </span>

</label>

</li><!-- nav-item checkbox checkbox-primary Ends -->

</ul><!-- nav flex-column Ends -->

</div><!-- card-body pb-2 pt-3 Ends -->

</div><!-- card border-primary mb-3 Ends -->





<div class="card border-primary mb-3"><!-- card border-primary mb-3 Starts -->

<div class="card-header bg-primary"><!-- card-header bg-primary Starts -->

<h3 class="float-left text-white h5"> Delivery Time </h3>

<button class="btn btn-secondary btn-sm float-right clear_delivery_time clearlink" onclick="clearDelivery()">

<i class="fa fa-times-circle"></i> Clear Filter

</button>

</div><!-- card-header bg-primary Ends -->

<div class="card-body"><!-- card-body Starts -->

<ul class="nav flex-column"><!--- nav flex-column Starts -->

<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_delivery_time">

<span>Up to 24 hours</span>

</label>

</li>

<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_delivery_time">

<span>Up to 24 hours</span>

</label>

</li>


<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_delivery_time">

<span>Up to 24 hours</span>

</label>

</li>


<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_delivery_time">

<span>Up to 24 hours</span>

</label>

</li>

</ul><!--- nav flex-column Ends -->

</div><!-- card-body Ends -->


</div><!-- card border-primary mb-3 Ends -->


<div class="card border-primary mb-3"><!-- card border-primary mb-3 Starts -->

<div class="card-header bg-primary"><!-- card-header bg-primary Starts -->

<h3 class="float-left text-white h5"> Seller Level </h3>

<button class="btn btn-secondary btn-sm float-right clear_seller_level clearlink" onclick="clearLevel()">

<i class="fa fa-times-circle"></i> Clear Filter

</button>

</div><!-- card-header bg-primary Ends -->

<div class="card-body"><!-- card-body Starts -->

<ul class="nav flex-column"><!--- nav flex-column Starts -->

<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_seller_level">

<span>Level One</span>

</label>

</li>

<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_seller_level">

<span>Level One</span>

</label>

</li>


<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_seller_level">

<span>Level One</span>

</label>

</li>


<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_seller_level">

<span>Level One</span>

</label>

</li>

</ul><!--- nav flex-column Ends -->

</div><!-- card-body Ends -->


</div><!-- card border-primary mb-3 Ends -->



<div class="card border-primary mb-3"><!-- card border-primary mb-3 Starts -->

<div class="card-header bg-primary"><!-- card-header bg-primary Starts -->

<h3 class="float-left text-white h5"> Seller Language </h3>

<button class="btn btn-secondary btn-sm float-right clear_seller_language clearlink" onclick="clearLanguage()">

<i class="fa fa-times-circle"></i> Clear Filter

</button>

</div><!-- card-header bg-primary Ends -->

<div class="card-body"><!-- card-body Starts -->

<ul class="nav flex-column"><!--- nav flex-column Starts -->

<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_seller_language">

<span>English</span>

</label>

</li>

<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_seller_language">

<span>English</span>

</label>

</li>


<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_seller_language">

<span>English</span>

<label>

</li>

<li class="nav-item checkbox checkbox-primary">

<label>

<input type="checkbox" value="1" class="get_seller_language">

<span>English</span>

</label>

</li>

</ul><!--- nav flex-column Ends -->

</div><!-- card-body Ends -->


</div><!-- card border-primary mb-3 Ends -->







