<!DOCTYPE html>

<html>

<head>

<title> Computerfever - Freelance Services Marketplace </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="description" content="Computerfever is the world's largest freelance services marketplace for lean entrepreneurs to focus on growth & create a successful business at affordable costs.">

<meta name="keywords" content="freelance,freelancers,jobs,proposals,sellers,buyers">

<meta name="author" content="Mohammed Tahir Ahmed">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="styles/bootstrap.min.css" rel="stylesheet">

<link href="styles/style.css" rel="stylesheet">

<link href="styles/category_nav_style.css" rel="stylesheet">

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

<link href="styles/owl.carousel.css" rel="stylesheet">

<link href="styles/owl.theme.default.css" rel="stylesheet">

<script src="js/jquery.min.js"></script>

</head>

<body>

<?php include("includes/header.php"); ?>

<?php include("user_home.php"); ?>

<?php include("includes/footer.php"); ?>

</body>

</html>