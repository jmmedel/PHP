
<?php

if($reason == "order"){
	
	echo "has just sent you an order.";
	
}

if($reason == "order_message"){
	
	echo "send message, updated your order.";
	
}

if($reason == "order_revision"){
	
	echo "requested revision on your order.";
	
}


if($reason == "order_completed"){
	
	echo "completed your order.";
	
}


if($reason == "order_delivered"){
	
	echo "delivered your order.";
	
}


if($reason == "cancellation_request"){
	
	echo "send cancellation request,updated your order.";
	
}


if($reason == "decline_cancellation_request"){
	
	echo "has declined your cancellation request.";
	
}



if($reason == "accept_cancellation_request"){
	
	echo "has accepted your cancellation request, and order has been cancelled.";
	
}



if($reason == "cancelled_by_customer_support"){
	
	echo "website customer support has cancelled your order.";
	
}


if($reason == "buyer_order_review"){
	
	echo "updated your order. review and rate the work.";
	
}


if($reason == "seller_order_review"){
	
	echo "updated your order, and give you a review.";
	
}


if($reason == "order_cancelled"){
	
	echo "your order has been cancelled.";
	
}


?>