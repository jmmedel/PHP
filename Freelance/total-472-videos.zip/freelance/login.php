
<?php

session_start();

include("includes/db.php");

if(isset($_SESSION['seller_user_name'])){
	
	echo "<script> window.open('index.php','_self'); </script>";
	
}

?>

<!DOCTYPE html>

<html>

<head>

<title> Computerfever / Login </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="author" content="Mohammed Tahir Ahmed">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="styles/bootstrap.min.css" rel="stylesheet">

<link href="styles/style.css" rel="stylesheet">

<link href="styles/category_nav_style.css" rel="stylesheet">

<!--- stylesheet width modifications --->

<link href="styles/custom.css" rel="stylesheet">

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

<script src="js/jquery.min.js"></script>

</head>

<body>

<?php include("includes/header.php"); ?>

<div class="container mt-5"><!--- container mt-5 Starts -->

<div class="row justify-content-center"><!--- row justify-content-center Starts -->

<div class="col-lg-5 col-md-7"><!--- col-lg-5 col-md-7 Starts -->

<h2 class="text-center"> Login To Computerfever </h2>

<div class="box-login mt-4"><!--- box-login mt-4 Starts -->

<img class="logo img-fluid" src="images/logo.png">


<form action="" method="post"><!--- form Starts -->

<div class="form-group"><!--- form-group Starts -->

<input type="text" name="seller_user_name" placeholder="Username" class="form-control">

</div><!--- form-group Ends -->

<div class="form-group"><!--- form-group Starts -->

<input type="password" name="seller_pass" placeholder="Password" class="form-control">

</div><!--- form-group Ends -->

<div class="form-group"><!--- form-group Starts -->

<input type="submit" name="logged_id" class="btn btn-success btn-block" value="Login" >

</div><!--- form-group Ends -->

</form><!--- form Ends -->

<div class="text-center mt-3"><!-- text-center mt-3 Starts -->

<a href="#" data-toggle="modal" data-target="#register-modal">

Register

</a>

<span class="ml-2 mr-2"> | </span>

<a href="#" data-toggle="modal" data-target="#forgot-modal">

Forgot Password

</a>

</div><!-- text-center mt-3 Ends -->

</div><!--- box-login mt-4 Ends -->

</div><!--- col-lg-5 col-md-7 Ends -->

</div><!--- row justify-content-center Ends -->

</div><!--- container mt-5 Ends -->

<?php

if(isset($_POST['logged_id'])){
	
	$seller_user_name = mysqli_real_escape_string($con, $_POST['seller_user_name']);
	
	$seller_pass = mysqli_real_escape_string($con, $_POST['seller_pass']);
	
	$select_seller = "select * from sellers where seller_user_name='$seller_user_name' AND NOT seller_status='deactivated'";
	
	$run_seller = mysqli_query($con,$select_seller);
	
	$row_seller = mysqli_fetch_array($run_seller);
	
	$hashed_password = $row_seller['seller_pass'];
	
	$seller_status = $row_seller['seller_status'];
	
	$decrypt_password = password_verify($seller_pass, $hashed_password);
	
	if($decrypt_password == 0){
		
		echo "
		
		<script>
		
		alert('Password Or Username Is Wrong, Please Try Again.');
		
		</script>
		
		";
		
	}else{
		
		if($seller_status == "block-ban"){
			
		  echo "
			
			<script>
			
			alert('You Have Been Blocked By Admin Please Contact Customer Support.');
			window.open('$site_url/index.php','_self');
			
			</script>
			
			";
			
		}else{
		
		$select_seller = "select * from sellers where seller_user_name='$seller_user_name' AND seller_pass='$hashed_password'";
		
		$run_seller = mysqli_query($con,$select_seller);
		
		if($run_seller){
			
			$_SESSION['seller_user_name'] = $seller_user_name;
			
			$update_seller_status = "update sellers set seller_status='online',seller_ip='$ip' where seller_user_name='$seller_user_name' AND seller_pass='$hashed_password'";
			
			$run_seller_status = mysqli_query($con,$update_seller_status);
			
			echo "
			
			<script>
			
			alert('You are Logged Into Your Account.');
			window.open('$site_url/index.php','_self');
			
			</script>
			
			";
			
			
		}
		
		}
		
	}
	
	
}

?>

<?php include("includes/footer.php"); ?>

</body>

</html>