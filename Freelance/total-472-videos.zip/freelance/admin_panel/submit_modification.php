
<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	
$proposal_id = $_GET['submit_modification'];
	
$get_proposals = "select * from proposals where proposal_id='$proposal_id'";

$run_proposals = mysqli_query($con,$get_proposals);

$row_proposals = mysqli_fetch_array($run_proposals);

$proposal_title = $row_proposals['proposal_title'];

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Submit Proposal For Modification

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts ---> 

<h4 class="h4"><!--- h4 Starts --->

<i class="fa fa-money-bill-alt fa-fw"></i> Submit Proposal For Modification

</h4><!--- h4 Ends --->

</div><!--- card-header Ends ---> 

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!---  form Starts --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Proposal Title </label>

<div class="col-md-6">

<p class="mt-2"><?php echo $proposal_title; ?></p>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Describe Modification </label>

<div class="col-md-6">

<textarea name="proposal_modification" class="form-control"></textarea>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="submit" value="Submit Proposal For Modification" class="btn btn-primary form-control">

</div>

</div><!--- form-group row Ends --->


</form><!---  form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['submit'])){
	
$proposal_modification = mysqli_real_escape_string($con,$_POST['proposal_modification']);
	
$insert_modification = "insert into proposal_modifications (proposal_id,modification_message) values ('$proposal_id','$proposal_modification')";
	
$run_modification = mysqli_query($con,$insert_modification);
	
$update_proposal = "update proposals set proposal_status='modification' where proposal_id='$proposal_id'";
	
$run_proposal = mysqli_query($con,$update_proposal);	


if($run_proposal){
	
echo "<script>alert(' One Proposal Has Been Sent To Modification.');</script>";
	
echo "<script>window.open('index.php?view_proposals','_self');</script>";
	
}

	
}


?>


<?php } ?>