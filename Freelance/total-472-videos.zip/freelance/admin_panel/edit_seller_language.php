<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

if(isset($_GET['edit_seller_language'])){
		
$edit_id = $_GET['edit_seller_language'];

$edit_language = "select * from seller_languages where language_id='$edit_id'";

$run_edit = mysqli_query($con,$edit_language);
		
$row_edit = mysqli_fetch_array($run_edit);
		
$language_id = $row_edit['language_id'];

$language_title = $row_edit['language_title'];
		
		
}
	

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Edit Seller Language

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Edit Seller Language

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Seller Language Title : </label>

<div class="col-md-6">

<input type="text" name="language_title" class="form-control" value="<?php echo $language_title; ?>" required>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="update_seller_language" class="btn btn-primary form-control" value="Update Seller Language">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['update_seller_language'])){
	
$language_title = mysqli_real_escape_string($con,$_POST['language_title']);
	
$update_seller_language = "update seller_languages set language_title='$language_title' where language_id='$language_id'";
	
$run_seller_language = mysqli_query($con,$update_seller_language);
	
if($run_seller_language){
	
echo "<script>alert('One Seller Language Has Been Updated.');</script>";
	
echo "<script>window.open('index.php?view_seller_languages','_self');</script>";

	
}
	
	
}


?>


<?php } ?>