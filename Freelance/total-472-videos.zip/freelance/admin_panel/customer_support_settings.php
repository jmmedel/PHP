<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

$get_contact_support = "select * from contact_support";

$run_contact_support = mysqli_query($con,$get_contact_support);

$row_contact_support = mysqli_fetch_array($run_contact_support);

$contact_email = $row_contact_support['contact_email'];

$contact_heading = $row_contact_support['contact_heading'];

$contact_desc = $row_contact_support['contact_desc'];

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Edit Customer Support Settings

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt"></i> Edit Customer Support Settings

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> From / Reply Email : </label>

<div class="col-md-6">

<input type="text" name="contact_email" class="form-control" required value="<?php echo $contact_email; ?>">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Page Heading : </label>

<div class="col-md-6">

<input type="text" name="contact_heading" class="form-control" required value="<?php echo $contact_heading; ?>">

</div>

</div><!--- form-group row Ends --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Page Short Description : </label>

<div class="col-md-6">

<textarea name="contact_desc" class="form-control" rows="6" required><?php echo $contact_desc; ?></textarea>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="submit" class="btn btn-primary form-control" value="Update Customer Support Settings">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Edit --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['submit'])){
	
$contact_email = mysqli_real_escape_string($con,$_POST['contact_email']);

$contact_heading =  mysqli_real_escape_string($con,$_POST['contact_heading']);

$contact_desc =  mysqli_real_escape_string($con,$_POST['contact_desc']);
	
	
$update_contact_support = "update contact_support set contact_email='$contact_email',contact_heading='$contact_heading',contact_desc='$contact_desc'";
	
$run_contact_support = mysqli_query($con,$update_contact_support);
	
if($run_contact_support){
	
echo "<script>alert('Customer Support Settings Has Been Updated.');</script>";
	
echo "<script>window.open('index.php?customer_support_settings','_self');</script>";

	
}
	
	
	
}

?>


<?php } ?>