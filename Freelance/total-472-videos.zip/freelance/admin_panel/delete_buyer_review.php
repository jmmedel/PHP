<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<?php

if(isset($_GET['delete_buyer_review'])){
	
$review_id = $_GET['delete_buyer_review'];
	
$get_buyer_reviews = "select * from buyer_reviews where review_id='$review_id'";

$run_buyer_reviews = mysqli_query($con,$get_buyer_reviews);

$row_buyer_reviews = mysqli_fetch_array($run_buyer_reviews);

$seller_id = $row_buyer_reviews['review_seller_id'];

$proposal_id = $row_buyer_reviews['proposal_id'];

$buyer_rating = $row_buyer_reviews['buyer_rating'];
	
	
$get_sellers = "select * from sellers where seller_id='$seller_id'";

$run_sellers = mysqli_query($con,$get_sellers);

$row_sellers = mysqli_fetch_array($run_sellers);
	
$seller_rating = $row_sellers['seller_rating'];


if($buyer_rating == "5"){
	
$update_seller_rating = "update sellers set seller_rating=seller_rating-7 where seller_id='$seller_id'";
	
$run_update_seller_rating = mysqli_query($con,$update_seller_rating);
	
}elseif($buyer_rating == "4"){
	
$update_seller_rating = "update sellers set seller_rating=seller_rating-2 where seller_id='$seller_id'";
	
$run_update_seller_rating = mysqli_query($con,$update_seller_rating);
	
}elseif($buyer_rating == "3"){
	
if($seller_rating == "100"){
	
}else{
	
$update_seller_rating = "update sellers set seller_rating=seller_rating+3 where seller_id='$seller_id'";
	
$run_update_seller_rating = mysqli_query($con,$update_seller_rating);
		
}
	
}elseif($buyer_rating == "2"){
	
if($seller_rating == "100"){
	
}else{
	
$update_seller_rating = "update sellers set seller_rating=seller_rating+5 where seller_id='$seller_id'";
	
$run_update_seller_rating = mysqli_query($con,$update_seller_rating);
		
}
	
	
}elseif($buyer_rating == "1"){
	
if($seller_rating == "100"){
	
}else{
	
$update_seller_rating = "update sellers set seller_rating=seller_rating+7 where seller_id='$seller_id'";
	
$run_update_seller_rating = mysqli_query($con,$update_seller_rating);
		
}
	
	
}

$delete_buyer_review = "delete from buyer_reviews where review_id='$review_id'";
	
$run_delete_buyer_review = mysqli_query($con,$delete_buyer_review);
	
if($run_delete_buyer_review){
	
$ratings = array();
	
$sel_proposal_reviews = "select * from buyer_reviews where proposal_id='$proposal_id'";
	
$run_proposals_reviews = mysqli_query($con,$sel_proposal_reviews);
	
while($row_proposals_reviews = mysqli_fetch_array($run_proposals_reviews)){
	
	$proposal_buyer_rating = $row_proposals_reviews['buyer_rating'];
	
	array_push($ratings,$proposal_buyer_rating);
	
}
	
$total = array_sum($ratings);
	
$avg = $total/count($ratings);
	
$updated_propoasl_rating = substr($avg,0,1);
	
$update_proposal = "update proposals set proposal_rating='$updated_propoasl_rating' where proposal_id='$proposal_id'";

$run_update_proposal = mysqli_query($con,$update_proposal);
	
if($run_update_proposal){
	
echo "<script>alert('One Buyer Review Has been Deleted Successfully.');</script>";

echo "<script>window.open('index.php?view_buyer_reviews','_self');</script>";

	
}
	
	
	
}
	
	
}

?>

<?php } ?>