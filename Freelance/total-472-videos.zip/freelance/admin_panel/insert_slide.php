<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>


<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Insert Slide

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Insert Slide

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post" enctype="multipart/form-data"><!--- form Starts --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Slide Name : </label>

<div class="col-md-6">

<input type="text" name="slide_name" class="form-control" required>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Slide Description : </label>

<div class="col-md-6">

<textarea name="slide_desc" class="form-control" required></textarea>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Slide Image : </label>

<div class="col-md-6">

<input type="file" name="slide_image" class="form-control" required>

</div>

</div><!--- form-group row Ends --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Slide Url : </label>

<div class="col-md-6">

<input type="url" name="slide_url" class="form-control" required>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="submit" class="btn btn-primary form-control" value="Insert Slide">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['submit'])){
	
$slide_name = mysqli_real_escape_string($con,$_POST['slide_name']);

$slide_desc = mysqli_real_escape_string($con,$_POST['slide_desc']);

$slide_url = mysqli_real_escape_string($con,$_POST['slide_url']);
	
$slide_image = $_FILES['slide_image']['name'];	

$tmp_slide_image = $_FILES['slide_image']['tmp_name'];	

move_uploaded_file($tmp_slide_image,"../slides_images/$slide_image");

$insert_slide = "insert into slider (slide_name,slide_desc,slide_image,slide_url) values ('$slide_name','$slide_desc','$slide_image','$slide_url')";	

$run_slide = mysqli_query($con,$insert_slide);
	
if($run_slide){
	
echo "<script>alert('One Slide has been Inserted.');</script>";
	
echo "<script>window.open('index.php?view_slides','_self');</script>";

	
}
	
	
	
}


?>

<?php } ?>