<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>


<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Insert Delivery Time

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt"></i> Insert Delivery Time

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Delivery Time Title : </label>

<div class="col-md-6">

<input type="text" name="delivery_title" class="form-control" required>

<small class="form-text text-muted">

This delivery title will show on categories,sub categories and search pages.

</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Proposal Delivery Time Title : </label>

<div class="col-md-6">

<input type="text" name="delivery_proposal_title" class="form-control" required>

<small class="form-text text-muted">

This delivery title will show on proposals related pages.

</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="submit" value="Insert Delivery Time" class="btn btn-primary form-control">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->



<?php

if(isset($_POST['submit'])){
	
$delivery_title = mysqli_real_escape_string($con,$_POST['delivery_title']);

$delivery_proposal_title = mysqli_real_escape_string($con,$_POST['delivery_proposal_title']);
	
$insert_delivery_time = "insert into delivery_times (delivery_title,delivery_proposal_title) values ('$delivery_title','$delivery_proposal_title')";
	
$run_delivery_time = mysqli_query($con,$insert_delivery_time);
	
if($run_delivery_time){
	
echo "<script>alert('One Delivery Time Has Been Inserted.');</script>";
	
echo "<script>window.open('index.php?view_delivery_times','_self');</script>";

	
}
	
	
}


?>


<?php } ?>