<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<?php

if(isset($_GET['approve_referral'])){
	
$referral_id = $_GET['approve_referral'];

$get_referrals = "select * from referrals where referral_id='$referral_id'";

$run_referrals = mysqli_query($con,$get_referrals);

$row_referrals = mysqli_fetch_array($run_referrals);

$seller_id = $row_referrals['seller_id'];

$comission = $row_referrals['comission'];


$get_seller = "select * from sellers where seller_id='$seller_id'";
	
$run_seller = mysqli_query($con,$get_seller);
	
$row_seller = mysqli_fetch_array($run_seller);
	
$seller_user_name = $row_seller['seller_user_name'];


$update_current_balance = "update seller_accounts set current_balance=current_balance+$comission where seller_id='$seller_id'";

$run_current_balance = mysqli_query($con,$update_current_balance);
	
	
$update_referral = "update referrals set status='approved' where referral_id='$referral_id'";
	
$run_update = mysqli_query($con,$update_referral);
	
if($run_update){
	
echo "<script>alert('One Referral Has been Approed And Referral Commission Has Been Given To  $seller_user_name.');</script>";
	
echo "<script>window.open('index.php?view_referrals','_self');</script>";

	
}
	
	
}

?>

<?php } ?>