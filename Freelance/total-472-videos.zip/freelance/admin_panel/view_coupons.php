<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Coupons

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Coupons

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-bordered table-hover"><!--- table table-bordered table-hover Starts --->

<thead><!--- thead Starts --->

<th>Coupon Id</th>

<th>Coupon Title</th>

<th>Coupon Proposal</th>

<th>Coupon Code</th>

<th>Coupon Price</th>

<th>Coupon Limit</th>

<th>Coupon Used</th>

<th>Delete Coupon</th>

<th>Edit Coupon</th>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php

$i = 0;

$get_coupons = "select * from coupons order by 1 DESC";

$run_coupons = mysqli_query($con,$get_coupons);

while($row_coupons = mysqli_fetch_array($run_coupons)){

$coupon_id = $row_coupons['coupon_id'];

$coupon_title = $row_coupons['coupon_title'];

$coupon_price = $row_coupons['coupon_price'];

$coupon_code = $row_coupons['coupon_code'];

$coupon_limit = $row_coupons['coupon_limit'];

$coupon_used = $row_coupons['coupon_used'];

$proposal_id = $row_coupons['proposal_id'];


$get_proposals = "select * from proposals where proposal_id='$proposal_id'";

$run_proposals = mysqli_query($con,$get_proposals);

$row_proposals = mysqli_fetch_array($run_proposals);

$proposal_title = $row_proposals['proposal_title'];


$i++;


?>

<tr>

<td><?php echo $i; ?></td>

<td><?php echo $coupon_title; ?></td>

<td><?php echo $proposal_title; ?></td>

<td><?php echo $coupon_code; ?></td>

<td>$<?php echo $coupon_price; ?></td>

<td><?php echo $coupon_limit; ?></td>

<td><?php echo $coupon_used; ?></td>

<td>

<a href="index.php?delete_coupon=<?php echo $coupon_id; ?>">

<i class="fa fa-trash-alt"></i> Delete

</a>

</td>

<td>

<a href="index.php?edit_coupon=<?php echo $coupon_id; ?>">

<i class="fa fa-pencil-alt"></i> Edit

</a>

</td>

</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-bordered table-hover Ends --->

</div><!--- table-responsive Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php } ?>