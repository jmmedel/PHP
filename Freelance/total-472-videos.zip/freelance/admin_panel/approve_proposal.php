<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<?php

if(isset($_GET['approve_proposal'])){
	
$approve_id = $_GET['approve_proposal'];
	
$update_proposal = "update proposals set proposal_status='active' where proposal_id='$approve_id'";
	
$run_proposal = mysqli_query($con,$update_proposal);
	
if($run_proposal){
	
echo "<script>alert(' One Proposal Has Been Approved And Live To Website.');</script>";
	
echo "<script>window.open('index.php?view_proposals_active','_self');</script>";
	
}

	
}

?>

<?php } ?>