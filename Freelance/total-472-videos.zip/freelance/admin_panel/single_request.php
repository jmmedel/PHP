<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

$single_request = $_GET['single_request'];

$get_support_tickets = "select * from support_tickets where ticket_id='$single_request'";

$run_support_tickets = mysqli_query($con,$get_support_tickets);

$row_support_tickets = mysqli_fetch_array($run_support_tickets);

$ticket_id = $row_support_tickets['ticket_id'];

$sender_id = $row_support_tickets['sender_id'];

$subject = $row_support_tickets['subject'];

$status = $row_support_tickets['status'];

$enquiry_id = $row_support_tickets['enquiry_id'];

$message = $row_support_tickets['message'];

$attachment = $row_support_tickets['attachment'];

$order_number = $row_support_tickets['order_number'];

$order_rule = $row_support_tickets['order_rule'];

$date = $row_support_tickets['date'];


$select_sender = "select * from sellers where seller_id='$sender_id'";

$run_sender = mysqli_query($con,$select_sender);

$row_sender = mysqli_fetch_array($run_sender);

$sender_user_name = $row_sender['seller_user_name'];

$sender_email = $row_sender['seller_email'];


$get_enquiry_types = "select * from enquiry_types where enquiry_id='$enquiry_id'";

$run_enquiry_types = mysqli_query($con,$get_enquiry_types);

$row_enquiry_types = mysqli_fetch_array($run_enquiry_types);

$enquiry_title = $row_enquiry_types['enquiry_title'];


?>


<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Single Request

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->




<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Single Request

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<p>

<b> Enquiry Type : </b> <?php echo $enquiry_title; ?>

</p>

<p>

<b> Sender Username : </b> <?php echo $sender_user_name; ?>

</p>

<p>

<b> Sender Email Address : </b> <?php echo $sender_email; ?>

</p>

<p>

<b> Subject : </b> <?php echo $subject; ?>

</p>

<p>

<b> Message : </b> <?php echo $message; ?>

</p>

<?php if(!empty($order_rule)){ ?>

<p>

<b> Order Rule : </b> <?php echo $order_rule; ?>

</p>

<?php } ?>

<?php if(!empty($order_number)){ ?>

<p>

<b> Order Number : </b> <?php echo $order_number; ?>

</p>

<?php } ?>


<?php if(!empty($attachment)){ ?>

<p>

<b> Attachment : </b> 

<a href="../ticket_files/<?php echo $attachment; ?>" download> <?php echo $attachment; ?> </a>

</p>

<?php } ?>

<p>

<b> Request Created Date : </b> <?php echo $date; ?>

</p>


<p>

<b> Request Status : </b> <?php echo ucwords($status); ?> &nbsp;&nbsp;

<a href="#" class="btn btn-primary" data-toggle="collapse" data-target="#status">

Chage Status

</a>

</p>


<form id="status" class="collapse form-inline" method="post"><!--- collapse form-inline Starts --->

<p class="text-muted mb-3">

<span class="text-danger">!Important : </span>

If You Solve Customer Requested Problem Then Change Request Status open to closed.

</p>

<div class="form-group"><!--- form-group Starts --->

<label class="mb-2 mr-sm-2 mb-sm-0"> Change Status : </label>

<input type="text" name="status" class="form-control mb-2 mr-sm-2 mb-sm-0" value="<?php echo $status; ?>">

<input type="submit" name="update_status" class="form-control btn btn-success" value="Change Status">

</div><!--- form-group Ends --->

<?php

if(isset($_POST['update_status'])){
	
$status = $_POST['status'];
	
$update_support_ticket = "update support_tickets set status='$status' where ticket_id='$single_request'";
	
$run_update_support_ticket = mysqli_query($con,$update_support_ticket);
	
if($run_update_support_ticket){
	
echo "<script>alert('One Support Request Status Has Been Changed.');</script>";

echo "<script>window.open('index.php?view_support_requests','_self');</script>";

	
}
	
	
	
}

?>

</form><!--- collapse form-inline Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->



<?php } ?>