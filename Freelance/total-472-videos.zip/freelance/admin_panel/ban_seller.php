<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<?php

if(isset($_GET['ban_seller'])){

$seller_id = $_GET['ban_seller'];
	
$update_seller = "update sellers set seller_status='block-ban' where seller_id='$seller_id'";
	
$run_seller = mysqli_query($con,$update_seller);
	
if($run_seller){
	
echo "<script>alert('This Seller Has Been Blocked / Ban,He Never Login To His Account Anymore.');</script>";
	
echo "<script>window.open('index.php?view_sellers','_self');</script>";

	
}

	
}

?>

<?php } ?>