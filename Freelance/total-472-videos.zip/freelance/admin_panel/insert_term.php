<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>


 

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Insert Term

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Insert Term

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Term Title : </label>

<div class="col-md-6">

<input type="text" name="term_title" class="form-control" required>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Term Description : </label>

<div class="col-md-6">

<textarea class="form-control" name="term_desc" rows="7" required></textarea>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Term Link : </label>

<div class="col-md-6">

<input type="text" name="term_link" class="form-control" required>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="submit" class="btn btn-primary form-control" value="Insert Term">

</div>

</div><!--- form-group row Ends --->



</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->

<?php

if(isset($_POST['submit'])){
	
$term_title = mysqli_real_escape_string($con,$_POST['term_title']);

$term_desc = mysqli_real_escape_string($con,$_POST['term_desc']);

$term_link = mysqli_real_escape_string($con,$_POST['term_link']);
	
$insert_term = "insert into terms (term_title,term_link,term_description) values ('$term_title','$term_link','$term_desc')";
	
$run_term = mysqli_query($con,$insert_term);
	
if($run_term){
	
echo "<script>alert('One Term has been Inserted.');</script>";
	
echo "<script>window.open('index.php?view_terms','_self');</script>";
	
}
	
	
	
}


?>

<?php } ?>