<!DOCTYPE html>

<html>

<head>

<title> Computerfever - Freelance Services Marketplace </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="description" content="Computerfever is the world's largest freelance services marketplace for lean entrepreneurs to focus on growth & create a successful business at affordable costs.">

<meta name="keywords" content="freelance,freelancers,jobs,proposals,sellers,buyers">

<meta name="author" content="Mohammed Tahir Ahmed">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="styles/bootstrap.min.css" rel="stylesheet">

<link href="styles/style.css" rel="stylesheet">

<link href="styles/category_nav_style.css" rel="stylesheet">

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

<link href="styles/owl.carousel.css" rel="stylesheet">

<link href="styles/owl.theme.default.css" rel="stylesheet">



</head>

<body class="bg-white">

<?php include("includes/header.php"); ?>

<div class="container-fluid mt-5"><!-- container-fluid mt-5 Starts -->

<div class="row"><!-- row Starts -->

<div class="col-md-12"><!-- col-md-12 Starts -->

<center>

<h1> Search Results </h1>

<p class="lead"> " Youtube Video Promotion " </p>

</center>

<hr>

</div><!-- col-md-12 Ends -->

</div><!-- row Ends -->

<div class="row mt-3"><!-- row mt-3 Starts -->

<div class="col-lg-3 col-md-4 col-sm-12"><!-- col-lg-3 col-md-4 col-sm-12 Starts --> 

<?php include("includes/search_sidebar.php"); ?>

</div><!-- col-lg-3 col-md-4 col-sm-12 Ends --> 

</div><!-- row mt-3 Ends -->

</div><!-- container-fluid mt-5 Ends -->

<?php include("includes/footer.php"); ?>

</body>

</html>