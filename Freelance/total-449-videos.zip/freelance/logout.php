<?php

session_start();

include("includes/db.php");

if(!isset($_SESSION['seller_user_name'])){
	
	echo "<script> window.open('index.php','_self') </script>";
	
}


$seller_user_name = $_SESSION['seller_user_name'];

$update_seller_status = "update sellers set seller_status='away' where seller_user_name='$seller_user_name'"; 

$run_seller_status = mysqli_query($con,$update_seller_status); 

unset($_SESSION['seller_user_name']);

echo "<script> window.open('index.php','_self') </script>";

?>