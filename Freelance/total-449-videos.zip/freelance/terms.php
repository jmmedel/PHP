
<?php

session_start();

include("includes/db.php");

?>

<!DOCTYPE html>

<html>

<head>

<title> Terms and Conditions </title>

<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

<meta name="description" content="Computerfever is the world's largest freelance services marketplace for lean entrepreneurs to focus on growth & create a successful business at affordable costs.">

<meta name="keywords" content="freelance,freelancers,jobs,proposals,sellers,buyers">

<meta name="author" content="Mohammed Tahir Ahmed">

<link href="http://fonts.googleapis.com/css?family=Roboto:400,500,700,300,100" rel="stylesheet" >

<link href="styles/bootstrap.min.css" rel="stylesheet">

<link href="styles/style.css" rel="stylesheet">

<link href="styles/category_nav_style.css" rel="stylesheet">

<!--- stylesheet width modifications --->

<link href="styles/custom.css" rel="stylesheet">

<link href="font-awesome/css/font-awesome.min.css" rel="stylesheet">

<script src="js/jquery.min.js"></script>

</head>

<body>

<?php include("includes/header.php"); ?>

<div class="container-fluid mt-5 mb-5"><!--- container-fluid mt-5 mb-5 Starts -->

<div class="row mb-3"><!-- row mb-3 Starts -->

<div class="col-md-12 text-center"><!-- col-md-12 text-center Starts -->

<h1>Terms And Conditions</h1>

</div><!-- col-md-12 text-center Ends -->

</div><!-- row mb-3 Ends -->

<div class="row"><!-- row Starts -->

<div class="col-md-3 mb-3"><!-- col-md-3 mb-3 Starts -->

<div class="card"><!-- card Starts -->

<div class="card-body"><!--- card-body Starts --->

<ul class="nav nav-pills flex-column mt-2"><!--- nav nav-pills flex-column mt-2 Starts --->

<?php

$get_terms = "select * from terms LIMIT 0,1";

$run_terms = mysqli_query($con,$get_terms);

while($row_terms = mysqli_fetch_array($run_terms)){
	
	$term_title = $row_terms['term_title'];
	
	$term_link = $row_terms['term_link'];

?>

<li class="nav-item">

<a class="nav-link active" data-toggle="pill" href="#<?php echo $term_link; ?>">

<?php echo $term_title; ?>

</a>

</li>

<?php } ?>

<?php

$get_terms = "select * from terms";

$run_terms = mysqli_query($con,$get_terms);

$count_terms = mysqli_num_rows($run_terms);

$get_terms = "select * from terms LIMIT 1,$count_terms";

$run_terms = mysqli_query($con,$get_terms);

while($row_terms = mysqli_fetch_array($run_terms)){
	
	$term_title = $row_terms['term_title'];
	
	$term_link = $row_terms['term_link'];

?>

<li class="nav-item">

<a class="nav-link" data-toggle="pill" href="#<?php echo $term_link; ?>">

<?php echo $term_title; ?>

</a>

</li>

<?php } ?>

</ul><!--- nav nav-pills flex-column mt-2 Ends --->

</div><!--- card-body Ends --->

</div><!-- card Ends -->

</div><!-- col-md-3 mb-3 Ends -->

<div class="col-md-9"><!-- col-md-9 Starts -->

<div class="card"><!--- card Starts --->

<div class="card-body"><!-- card-body Starts -->

<div class="tab-content"><!-- tab-content Starts-->

<?php

$get_terms = "select * from terms LIMIT 0,1";

$run_terms = mysqli_query($con,$get_terms);

while($row_terms = mysqli_fetch_array($run_terms)){
	
	$term_title = $row_terms['term_title'];
	
	$term_link = $row_terms['term_link'];
	
	$term_description = $row_terms['term_description'];

?>

<div id="<?php echo $term_link; ?>" class="tab-pane fade show active"><!--- tab-pane fade show active Starts -->

<h1> <?php echo $term_title; ?> </h1>

<p>

<?php echo $term_description; ?>

</p>

</div><!--- tab-pane fade show active Ends -->

<?php } ?>

<?php

$get_terms = "select * from terms LIMIT 1,$count_terms";

$run_terms = mysqli_query($con,$get_terms);

while($row_terms = mysqli_fetch_array($run_terms)){
	
	$term_title = $row_terms['term_title'];
	
	$term_link = $row_terms['term_link'];
	
	$term_description = $row_terms['term_description'];

?>

<div id="<?php echo $term_link; ?>" class="tab-pane fade"><!--- tab-pane fade Starts -->

<h1> <?php echo $term_title; ?> </h1>

<p>

<?php echo $term_description; ?>

</p>

</div><!--- tab-pane fade Ends -->

<?php } ?>

</div><!-- tab-content Ends -->

</div><!-- card-body Ends -->

</div><!--- card Ends --->

</div><!-- col-md-9 Ends -->

</div><!-- row Ends -->

</div><!--- container-fluid mt-5 mb-5 Ends -->

<?php include("includes/footer.php"); ?>

</body>

</html>