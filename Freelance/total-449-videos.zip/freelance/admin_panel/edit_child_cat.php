<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

if(isset($_GET['edit_child_cat'])){
	
$edit_id = $_GET['edit_child_cat'];
	
$edit_child_cat = "select * from categories_childs where child_id='$edit_id'";

$run_edit = mysqli_query($con,$edit_child_cat);
	
$row_edit = mysqli_fetch_array($run_edit);
	
$child_id = $row_edit['child_id'];

$child_parent_id = $row_edit['child_parent_id'];

$child_title = $row_edit['child_title'];

$child_desc = $row_edit['child_desc'];

	
$get_cats = "select * from categories where cat_id='$child_parent_id'";

$run_cats = mysqli_query($con,$get_cats);

$row_cats = mysqli_fetch_array($run_cats);

$cat_title = $row_cats['cat_title'];
	
	
}
	
	
?>



<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Edit Sub Category

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Edit Sub Category

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Sub Category Title : </label>

<div class="col-md-6">

<input type="text" name="child_title" class="form-control" required value="<?php echo $child_title; ?>">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Sub Category Description : </label>

<div class="col-md-6">

<textarea name="child_desc" class="form-control" required><?php echo $child_desc; ?></textarea>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Select A Parent Category : </label>

<div class="col-md-6">

<select name="parent_cat" class="form-control" required>

<option value="<?php echo $child_parent_id; ?>"> <?php echo $cat_title; ?> </option>

<?php 

$get_cats = "select * from categories where not cat_id='$child_parent_id'";

$run_cats = mysqli_query($con,$get_cats);

while($row_cats = mysqli_fetch_array($run_cats)){

$cat_id = $row_cats['cat_id'];

$cat_title = $row_cats['cat_title'];

echo "<option value='$cat_id'>$cat_title</option>";

}

?>

</select>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="update_child_cat" value="Update Sub Category" class="btn btn-primary form-control">

</div>

</div><!--- form-group row Ends --->




</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['update_child_cat'])){
	
$child_title = mysqli_real_escape_string($con,$_POST['child_title']);

$child_desc = mysqli_real_escape_string($con,$_POST['child_desc']);

$parent_cat = mysqli_real_escape_string($con,$_POST['parent_cat']);
	
	
$update_child_cat = "update categories_childs set child_parent_id='$parent_cat',child_title='$child_title',child_desc='$child_desc' where child_id='$child_id'";
	
$run_child_cat = mysqli_query($con,$update_child_cat);
	
if($run_child_cat){
	
echo "<script>alert('One Sub Category Has Been Updated.');</script>";
	
echo "<script>window.open('index.php?view_child_cats','_self');</script>";

	
}
	
	
	
}


?>



<?php } ?>