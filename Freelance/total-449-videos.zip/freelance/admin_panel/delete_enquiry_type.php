<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>

<?php

if(isset($_GET['delete_enquiry_type'])){
	
$enquiry_id = $_GET['delete_enquiry_type'];
	
$delete_enquiry_type = "delete from enquiry_types where enquiry_id='$enquiry_id'";
	
$run_enquiry_type = mysqli_query($con,$delete_enquiry_type);
	
if($run_enquiry_type){
	
echo "<script>alert('One Enquiry Type Has been Deleted.');</script>";
	
echo "<script>window.open('index.php?view_enquiry_types','_self');</script>";

	
	
}

	
}

?>

<?php } ?>