<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<?php

if(isset($_GET['edit_coupon'])){
	
$edit_id = $_GET['edit_coupon'];

$edit_coupon = "select * from coupons where coupon_id='$edit_id'";

$run_edit = mysqli_query($con,$edit_coupon);

$row_edit = mysqli_fetch_array($run_edit);

$coupon_title = $row_edit['coupon_title'];

$coupon_price = $row_edit['coupon_price'];

$coupon_code = $row_edit['coupon_code'];

$coupon_limit = $row_edit['coupon_limit'];

$proposal_id = $row_edit['proposal_id'];



	
}

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Edit Coupon

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Edit Coupon

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Coupon Title : </label>

<div class="col-md-6">

<input type="text" name="coupon_title" class="form-control" required>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Coupon Price : </label>

<div class="col-md-6">

<input type="number" name="coupon_price" class="form-control" value="1" min="1" required>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Coupon Code : </label>

<div class="col-md-6">

<input type="text" name="coupon_code" class="form-control" required>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Coupon Limit : </label>

<div class="col-md-6">

<input type="number" name="coupon_limit" class="form-control" value="1" min="1">

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Select Coupon Proposal : </label>

<div class="col-md-6">

<select name="proposal_id" class="form-control" required>

<option value=""> Select A Coupon Proposal </option>

<?php 

$get_proposals = "select * from proposals where proposal_status='active'";

$run_proposals = mysqli_query($con,$get_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

echo "<option value='$proposal_id'>$proposal_title</option>";

}

?>

</select>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="update" class="btn btn-primary form-control" value="Update Coupon">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['submit'])){
	
$coupon_title = mysqli_real_escape_string($con,$_POST['coupon_title']);

$coupon_price = mysqli_real_escape_string($con,$_POST['coupon_price']);

$coupon_code = mysqli_real_escape_string($con,$_POST['coupon_code']);

$coupon_limit = mysqli_real_escape_string($con,$_POST['coupon_limit']);

$proposal_id = mysqli_real_escape_string($con,$_POST['proposal_id']);
	
	
$get_coupons = "select * from coupons where coupon_code='$coupon_code'";
	
$run_coupons = mysqli_query($con,$get_coupons);
	
$check_coupons = mysqli_num_rows($run_coupons);
	
if($check_coupons == 1){
	
echo "<script>alert('Coupon Code Has Been Applied Already.');</script>";
	
}else{
	
$insert_coupon = "insert into coupons (proposal_id,coupon_title,coupon_price,coupon_code,coupon_limit) values ('$proposal_id','$coupon_title','$coupon_price','$coupon_code','$coupon_limit')";
	
$run_coupon = mysqli_query($con,$insert_coupon);
	
if($run_coupon){
	
echo "<script>alert('One Coupon Code Has been Inserted.');</script>";
	
echo "<script>window.open('index.php?view_coupons','_self');</script>";
	
}
	
	
}
	
	
	
}


?>


<?php } ?>