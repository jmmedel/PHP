<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Single Conversations

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->


<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Single Conversations

</h4>

</div><!--- card-header Ends --->


<div class="card-body"><!--- card-body Starts ---> 

<?php

$single_messages_id = $_GET['single_inbox_message'];


$get_inbox_messages = "select * from inbox_messages where message_group_id='$single_messages_id'";

$run_inbox_messages = mysqli_query($con,$get_inbox_messages);

while($row_inbox_messages = mysqli_fetch_array($run_inbox_messages)){

$message_id = $row_inbox_messages['message_id'];

$message_sender = $row_inbox_messages['message_sender'];

$message_desc = $row_inbox_messages['message_desc'];

$message_date = $row_inbox_messages['message_date'];

$message_group_id = $row_inbox_messages['message_group_id'];

$message_file = $row_inbox_messages['message_file'];

$message_offer_id = $row_inbox_messages['message_offer_id'];

if(!$message_offer_id == 0){
	
$sellect_offer = "select * from messages_offers where offer_id='$message_offer_id'";	

$run_offer = mysqli_query($con,$sellect_offer);
	
$row_offer = mysqli_fetch_array($run_offer);
	
$sender_id = $row_offer['sender_id'];

$proposal_id = $row_offer['proposal_id'];

$description = $row_offer['description'];

$delivery_time = $row_offer['delivery_time'];

$amount = $row_offer['amount'];

$order_id = $row_offer['order_id'];

$offer_status = $row_offer['status'];
	
	
$get_proposals = "select * from proposals where proposal_id='$proposal_id'";

$run_proposals = mysqli_query($con,$get_proposals);

$row_proposals = mysqli_fetch_array($run_proposals);

$proposal_title = $row_proposals['proposal_title'];

$proposal_img1 = $row_proposals['proposal_img1'];
	
	
}


$select_sender = "select * from sellers where seller_id='$message_sender'";

$run_sender = mysqli_query($con,$select_sender);

$row_sender = mysqli_fetch_array($run_sender);

$sender_user_name = $row_sender['seller_user_name'];

$sender_image = $row_sender['seller_image'];



?>

<div class="message-div"><!--- message-div Starts --->

<?php 

if(!empty($sender_image)){

?>

<img src="../user_images/<?php echo $sender_image; ?>" class="message-image">

<?php }else{ ?>

<img src="../user_images/empty-image.png" class="message-image">

<?php } ?>

<h5><?php echo $sender_user_name; ?></h5>

<p class="message-desc">

<?php echo $message_desc; ?>

<?php if(!empty($message_file)){ ?>

<a href="../conversations/conversations_files/<?php echo $message_file; ?>" download class="d-block mt-2 ml-1">

<i class="fa fa-download"></i> <?php echo $message_file; ?>

</a>

<?php }else{ ?>

<?php } ?>

</p>

<?php if(!$message_offer_id == 0){ ?>

<div class="message-offer"><!--- message-offer Starts --->

<div class="row"><!--- row Starts --->

<div class="col-lg-2 col-md-3"><!--- col-lg-2 col-md-3 Starts --->

<img src="../proposals/proposal_files/<?php echo $proposal_img1; ?>" class="img-fluid">

</div><!--- col-lg-2 col-md-3 Ends --->

<div class="col-lg-10 col-md-9"><!--- col-lg-10 col-md-9 Starts --->

<h5 class="mt-md-0 mt-2">

<?php echo $proposal_title; ?>

<span class="price float-right d-sm-block d-none"> $ <?php echo $amount; ?> </span>

</h5>

<p><?php echo $description; ?></p>

<p class="d-block d-sm-none"> <b> Price / Amount : </b> $<?php echo $amount; ?> </p>

<p> <b> Delivery Time : </b> <?php echo $delivery_time; ?> </p>

<?php if($offer_status == "active"){ ?>

<button class="btn btn-success rounded-0 mt-2 float-right">

Offer Has Not Accepted

</button>

<?php }elseif($offer_status == "accepted"){ ?>

<p class="float-right">

<a class="btn" href="../order_details.php?order_id=<?php echo $order_id; ?>" target="_blank">

View Order

</a>

<button class="btn btn-success rounded-0" disabled>

Offer Accepted

</button>

</p>

<?php } ?>

</div><!--- col-lg-10 col-md-9 Ends --->

</div><!--- row Ends --->

</div><!--- message-offer Ends --->

<?php } ?>

</div><!--- message-div Ends --->

<?php } ?>

</div><!--- card-body Ends ---> 


</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php } ?>