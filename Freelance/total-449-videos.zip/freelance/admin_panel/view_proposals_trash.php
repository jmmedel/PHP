<?php


@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	
	
$get_all_proposals = "select * from proposals";
	
$run_all_proposals = mysqli_query($con,$get_all_proposals);

$count_all_proposals = mysqli_num_rows($run_all_proposals);


$get_active_proposals = "select * from proposals where proposal_status='active'";
	
$run_active_proposals = mysqli_query($con,$get_active_proposals);

$count_active_proposals = mysqli_num_rows($run_active_proposals);



$get_pending_proposals = "select * from proposals where proposal_status='pending'";
	
$run_pending_proposals = mysqli_query($con,$get_pending_proposals);

$count_pending_proposals = mysqli_num_rows($run_pending_proposals);



$get_pause_proposals = "select * from proposals where proposal_status='pause'";
	
$run_pause_proposals = mysqli_query($con,$get_pause_proposals);

$count_pause_proposals = mysqli_num_rows($run_pause_proposals);



$get_trash_proposals = "select * from proposals where proposal_status='trash'";
	
$run_trash_proposals = mysqli_query($con,$get_trash_proposals);

$count_trash_proposals = mysqli_num_rows($run_trash_proposals);




?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="p-3 mb-3 filter-form"><!--- p-3 mb-3 filter-form Starts --->

<h2>Filter Proposals</h2>

<form class="form-inline" method="get" action="filter_proposals.php">

<div class="form-group">

<label> Delivery Time : </label>

<select name="delivery_id" required class="form-control mb-2 mr-sm-2 mb-sm-0">

<option value=""> Select A Delivery Time </option>

<?php

$get_delivery_times = "select * from delivery_times";

$run_delivery_times = mysqli_query($con,$get_delivery_times);

while($row_delivery_times = mysqli_fetch_array($run_delivery_times)){
	
$delivery_id = $row_delivery_times['delivery_id'];

$delivery_title= $row_delivery_times['delivery_title'];
	
echo "<option value='$delivery_id'>$delivery_title</option>";
	
}

?>

</select>

</div>


<div class="form-group">

<label> Seller Level : </label>

<select name="level_id" required class="form-control mb-2 mr-sm-2 mb-sm-0">

<option value=""> Select A Seller Level </option>

<?php

$get_seller_levels = "select * from seller_levels";

$run_seller_levels = mysqli_query($con,$get_seller_levels);

while($row_seller_levels = mysqli_fetch_array($run_seller_levels)){
	
$level_id = $row_seller_levels['level_id'];

$level_title = $row_seller_levels['level_title'];
	
echo "<option value='$level_id'>$level_title</option>";
	
}

?>

</select>

</div>



<div class="form-group">

<label> Category : </label>

<select name="cat_id" required class="form-control mb-2 mr-sm-2 mb-sm-0">

<option value=""> Select A Category </option>

<?php

$get_categories = "select * from categories";

$run_categories = mysqli_query($con,$get_categories);

while($row_categories = mysqli_fetch_array($run_categories)){
	
$cat_id = $row_categories['cat_id'];

$cat_title = $row_categories['cat_title'];
	
echo "<option value='$cat_id'>$cat_title</option>";

	
}

?>

</select>

</div>

<button type="submit" class="btn btn-default"> Filter Proposals </button>

</form>

</div><!--- p-3 mb-3 filter-form Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row mt-3"><!--- 2 row mt-3 Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Proposals

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<a href="index.php?view_proposals" class="mr-2">

All (<?php echo $count_all_proposals; ?>)

</a>

<span class="mr-2">|</span>


<a href="index.php?view_proposals_active" class="mr-2">

Active (<?php echo $count_active_proposals; ?>)

</a>

<span class="mr-2">|</span>


<a href="index.php?view_proposals_pending" class="mr-2">

Pending Approvel (<?php echo $count_pending_proposals; ?>)

</a>

<span class="mr-2">|</span>



<a href="index.php?view_proposals_paused" class="mr-2">

Paused (<?php echo $count_pause_proposals; ?>)

</a>

<span class="mr-2">|</span>


<a href="index.php?view_proposals_trash" class="text-muted mr-2">

Trash (<?php echo $count_trash_proposals; ?>)

</a>


<div class="table-responsive mt-4"><!--- table-responsive mt-4 Starts --->

<table class="table table-hover table-bordered"><!--- table table-hover table-bordered Starts --->

<thead><!--- thead Starts --->

<tr>

<th>Proposal Title</th>

<th>Proposal Image</th>

<th>Proposal Price</th>

<th>Proposal Category</th>

<th>Proposal Order Queue</th>

<th>Proposal Options</th>

</tr>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php


$get_proposals = "select * from proposals where proposal_status='trash' order by 1 DESC";

$run_proposals = mysqli_query($con,$get_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_url = $row_proposals['proposal_url'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_cat_id = $row_proposals['proposal_cat_id'];

$proposal_status = $row_proposals['proposal_status'];


$select_orders = "select * from orders where proposal_id='$proposal_id' AND NOT order_status='complete' AND proposal_id='$proposal_id' AND NOT order_status='cancelled'";

$run_orders = mysqli_query($con,$select_orders);

$count_orders = mysqli_num_rows($run_orders);

$proposal_order_queue = $count_orders;


$get_categories = "select * from categories where cat_id='$proposal_cat_id'";

$run_categories = mysqli_query($con,$get_categories);

$row_categories = mysqli_fetch_array($run_categories);

$cat_title = $row_categories['cat_title'];

?>

<tr>

<td><?php echo $proposal_title; ?></td>

<td>

<img src="../proposals/proposal_files/<?php echo $proposal_img1; ?>" width="70" height="60">

</td>

<td><?php echo $proposal_price; ?></td>

<td><?php echo $cat_title; ?></td>

<td><?php echo $proposal_order_queue; ?></td>


<td>

<a href="index.php?restore_proposal=<?php echo $proposal_id; ?>">

<i class="fa fa-eye"></i> Restore Proposal

</a>

|

<a href="index.php?delete_proposal=<?php echo $proposal_id; ?>">

<i class="fa fa-trash-alt"></i> Delete Permanently

</a>

</td>


</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-hover table-bordered Ends --->

</div><!--- table-responsive mt-4 Ends --->



</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row mt-3 Ends --->

<?php } ?>