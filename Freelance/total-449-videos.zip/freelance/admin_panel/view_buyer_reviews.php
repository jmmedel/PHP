<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	
	
$get_buyer_reviews = "select * from buyer_reviews";
	
$run_buyer_reviews = mysqli_query($con,$get_buyer_reviews);
	
$count_buyer_reviews = mysqli_num_rows($run_buyer_reviews);
	

$get_seller_reviews = "select * from seller_reviews";	

$run_seller_reviews = mysqli_query($con,$get_seller_reviews);

$count_seller_reviews = mysqli_num_rows($run_seller_reviews);


?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Buyer Reviews

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Buyer Reviews

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<a href="index.php?view_buyer_reviews" class="text-muted mr-2">

Buyer Reviews (<?php echo $count_buyer_reviews; ?>)

</a>

<span class="mr-2">|</span>

<a href="index.php?view_seller_reviews" class="mr-2">

Seller Reviews (<?php echo $count_seller_reviews; ?>)

</a>

<div class="table-responsive mt-4"><!--- table-responsive mt-4 Starts --->

<table class="table table-bordered table-hover table-striped"><!--- table table-bordered table-hover table-striped Starts --->

<thead><!--- thead Starts --->

<tr>

<th>Order No</th>

<th>Buyer</th>

<th>Proposal</th>

<th>Rating</th>

<th>Date</th>

<th>Delete</th>

</tr>

</thead><!--- thead Ends --->

<tbody><!-- tbody Starts --->

<?php

$per_page = 7;

$get_buyer_reviews = "select * from buyer_reviews order by 1 DESC LIMIT 0,$per_page";

$run_buyer_reviews = mysqli_query($con,$get_buyer_reviews);

while($row_buyer_reviews = mysqli_fetch_array($run_buyer_reviews)){

$review_id = $row_buyer_reviews['review_id'];

$order_id = $row_buyer_reviews['order_id'];

$proposal_id = $row_buyer_reviews['proposal_id'];

$review_buyer_id = $row_buyer_reviews['review_buyer_id'];

$buyer_rating = $row_buyer_reviews['buyer_rating'];

$review_date = $row_buyer_reviews['review_date'];


$sel_orders = "select * from orders where order_id='$order_id'";

$run_orders = mysqli_query($con,$sel_orders);

$row_orders = mysqli_fetch_array($run_orders);

$order_number = $row_orders['order_number'];


$get_proposals = "select * from proposals where proposal_id='$proposal_id'";

$run_proposals = mysqli_query($con,$get_proposals);

$row_proposals = mysqli_fetch_array($run_proposals);

$proposal_title = $row_proposals['proposal_title'];


$select_buyer = "select * from sellers where seller_id='$review_buyer_id'";

$run_buyer = mysqli_query($con,$select_buyer);

$row_buyer = mysqli_fetch_array($run_buyer);

$buyer_user_name = $row_buyer['seller_user_name'];


?>


<tr>

<td>

<?php 

if($order_id == "0"){
	
echo "

Review Instered By Admin  <small class='text-primary'>No Order Number</small>

";
	
}else{
	
?>

<a href="index.php?single_order=<?php echo $order_id; ?>">
	
#<?php echo $order_number; ?>
	
</a>
	
<?php
	
}

?>

</td>

<td>

<a href="index.php?single_seller=<?php echo $review_buyer_id; ?>">
	
<?php echo $buyer_user_name; ?>
	
</a>

</td>


<td><?php echo $proposal_title; ?></td>


<td><?php echo $buyer_rating; ?></td>


<td><?php echo $review_date; ?></td>


<td>

<a href="index.php?delete_buyer_review=<?php echo $review_id; ?>" onclick="return confirm('Do You Really Want To Delete This Review After Deletion Seller Rating And His Proposal Rating Will Be Also Changed.')" class="btn btn-danger">

<i class="fa fa-trash-alt"></i> Delete Review

</a>

</td>


</tr>

<?php } ?>

</tbody><!-- tbody Ends --->

</table><!--- table table-bordered table-hover table-striped Ends --->

</div><!--- table-responsive mt-4 Ends --->

<div class="d-flex justify-content-center"><!--- d-flex justify-content-center Starts --->

<ul class="pagination"><!--- pagination Starts --->

<?php 

/// Now Select All Data From Table

$query = "select * from buyer_reviews order by 1 DESC";

$run_query = mysqli_query($con,$query);

/// Count The Total Records 

$total_records = mysqli_num_rows($run_query);

/// Using ceil function to divide the total records on per page

$total_pages = ceil($total_records / $per_page);

echo "

<li class='page-item'>

<a href='index.php?buyer_reviews_pagination=1' class='page-link'>

First Page

</a>

</li>

";


for($i=1; $i<=$total_pages; $i++){
	
echo "

<li class='page-item'>

<a href='index.php?buyer_reviews_pagination=".$i."' class='page-link'>

".$i."

</a>

</li>

";
	
	
}


echo "

<li class='page-item'>

<a href='index.php?buyer_reviews_pagination=$total_pages' class='page-link'>

Last Page

</a>

</li>

";


?>

</ul><!--- pagination Ends --->

</div><!--- d-flex justify-content-center Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->




<?php } ?>