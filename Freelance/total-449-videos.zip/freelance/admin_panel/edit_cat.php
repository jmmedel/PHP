<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{


if(isset($_GET['edit_cat'])){
	
$edit_id = $_GET['edit_cat'];
	
$edit_cat = "select * from categories where cat_id='$edit_id'";
	
$run_edit = mysqli_query($con,$edit_cat);
	
$row_edit = mysqli_fetch_array($run_edit);
	
$c_title = $row_edit['cat_title'];

$c_desc = $row_edit['cat_desc'];

$c_image = $row_edit['cat_image'];

$c_featured = $row_edit['cat_featured'];
	
	
	
}
	

?>



<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Edit Category

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->





<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt"></i> Edit Category

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post" enctype="multipart/form-data"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Category Title : </label>

<div class="col-md-6">

<input type="text" name="cat_title" class="form-control" value="<?php echo $c_title; ?>" required>

</div>

</div><!--- form-group row Ends --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Category Description : </label>

<div class="col-md-6">

<textarea name="cat_desc" class="form-control" required><?php echo $c_desc; ?></textarea>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Show as Featured Category : </label>

<div class="col-md-6">

<input type="radio" name="cat_featured" value="yes" required

<?php

if($c_featured == "yes"){
	
echo "checked='checked'";
	
}

?>

>

<label> Yes </label>

<input type="radio" name="cat_featured" value="no" required

<?php

if($c_featured == "no"){
	
echo "checked='checked'";
	
}

?>

>

<label> No </label>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Category Image : </label>

<div class="col-md-6">

<input type="file" name="cat_image" class="form-control">

<br>

<?php if(!empty($c_image)){ ?>

<img src="../cat_images/<?php echo $c_image; ?>" width="70" height="55">

<?php }else{ ?>

<img src="../cat_images/empty-image.jpg" width="70" height="55">

<?php } ?>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="update_cat" value="Update Category" class="btn btn-primary form-control">

</div>

</div><!--- form-group row Ends --->



</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<?php

if(isset($_POST['update_cat'])){
	
$cat_title = mysqli_real_escape_string($con,$_POST['cat_title']);

$cat_desc = mysqli_real_escape_string($con,$_POST['cat_desc']);

$cat_featured = mysqli_real_escape_string($con,$_POST['cat_featured']);
	
$cat_image = $_FILES['cat_image']['name'];

$tmp_cat_image = $_FILES['cat_image']['tmp_name'];
	
move_uploaded_file($tmp_cat_image,"../cat_images/$cat_image");
	
if(empty($cat_image)){
	
$cat_image = $c_image;
	
}
	
$update_cat = "update categories set cat_title='$cat_title',cat_desc='$cat_desc',cat_image='$cat_image',cat_featured='$cat_featured' where cat_id='$edit_id'";
	
$run_cat = mysqli_query($con,$update_cat);	

if($run_cat){
	
echo "<script>alert('One Category Has Been Updated.');</script>";
	
echo "<script>window.open('index.php?view_cats','_self');</script>";

	
	
}
	
	
	
	
}



?>


<?php } ?>