<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	
?>

<?php

if(isset($_GET['delete_seller_review'])){
	
$review_id = $_GET['delete_seller_review'];
	
$delete_seller_review = "delete from seller_reviews where review_id='$review_id'";
	
$run_seller_review = mysqli_query($con,$delete_seller_review);
	
if($run_seller_review){
	
echo "<script>alert('One Seller Review Has been Deleted Successfully.');</script>";
	
echo "<script>window.open('index.php?view_seller_reviews','_self');</script>";

	
}
	
	
}


?>

<?php } ?>