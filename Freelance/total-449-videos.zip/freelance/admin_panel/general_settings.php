
<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

$get_general_settings = "select * from general_settings";	

$run_general_settings = mysqli_query($con,$get_general_settings);

$row_general_settings = mysqli_fetch_array($run_general_settings);

$site_title = $row_general_settings['site_title'];

$site_desc = $row_general_settings['site_desc'];

$site_keywords = $row_general_settings['site_keywords'];

$site_author = $row_general_settings['site_author'];

$site_url = $row_general_settings['site_url'];

$site_email_address = $row_general_settings['site_email_address'];

$level_one_rating = $row_general_settings['level_one_rating'];

$level_one_orders = $row_general_settings['level_one_orders'];

$level_two_orders = $row_general_settings['level_two_orders'];

$level_two_rating = $row_general_settings['level_two_rating'];

$level_top_rating = $row_general_settings['level_top_rating'];

$level_top_orders = $row_general_settings['level_top_orders'];

$enable_referrals = $row_general_settings['enable_referrals'];

$referral_money = $row_general_settings['referral_money'];


$get_section = "select * from home_section";

$run_section = mysqli_query($con,$get_section);

$row_section = mysqli_fetch_array($run_section);

$section_id = $row_section['section_id'];

$section_title = $row_section['section_title'];

$section_short_desc = $row_section['section_short_desc'];

$section_desc = $row_section['section_desc'];

$section_button = $row_section['section_button'];

$section_button_url = $row_section['section_button_url'];

$db_section_image = $row_section['section_image'];



?>


<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / General Settings

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card mb-5"><!--- card mb-5 Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> General Settings

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form method="post" enctype="multipart/form-data"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Site Title : </label>

<div class="col-md-6">

<input type="text" name="site_title" class="form-control" value="<?php echo $site_title; ?>">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Site Description : </label>

<div class="col-md-6">

<textarea name="site_desc" class="form-control" rows="6" cols="19"><?php echo $site_desc; ?></textarea>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Site Keywords : </label>

<div class="col-md-6">

<input type="text" name="site_keywords" class="form-control" value="<?php echo $site_keywords; ?>">

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Site Author : </label>

<div class="col-md-6">

<input type="text" name="site_author" class="form-control" value="<?php echo $site_author; ?>">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Site Url : </label>

<div class="col-md-6">

<input type="text" name="site_url" class="form-control" value="<?php echo $site_url; ?>">

<small class="form-text text-muted">

<span class="text-danger">!Important</span>

Enter The Full Address Of Your Computerfever Freelancing Script Installation Directory.

</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Site Email Address : </label>

<div class="col-md-6">

<input type="text" name="site_email_address" class="form-control" value="<?php echo $site_email_address; ?>">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Level One Seller Ratings : </label>

<div class="col-md-6">

<input type="text" name="level_one_rating" class="form-control" value="<?php echo $level_one_rating; ?>">

<small class="form-text text-muted">

The Overall Positive Rating Percentage A Seller Needs To Have In Order To Become Level One

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Level One Seller Completed Orders : </label>

<div class="col-md-6">

<input type="text" name="level_one_orders" class="form-control" value="<?php echo $level_one_orders; ?>">

<small class="form-text text-muted">

 How Many Completed Orders A Seller Needs To Have In Order To Become Level One

</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Level Two Seller Ratings : </label>

<div class="col-md-6">

<input type="text" name="level_two_ratings" class="form-control" value="<?php echo $level_two_rating; ?>">

<small class="form-text text-muted">

The Overall Positive Rating Percentage A Seller Needs To Have In Order To Become Level Two

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Level Two Seller Completed Orders : </label>

<div class="col-md-6">

<input type="text" name="level_two_orders" class="form-control" value="<?php echo $level_two_orders; ?>">

<small class="form-text text-muted">

 How Many Completed Orders A Seller Needs To Have In Order To Become Level Two

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Top Rated Seller Ratings : </label>

<div class="col-md-6">

<input type="text" name="level_top_rating" class="form-control" value="<?php echo $level_top_rating; ?>">

<small class="form-text text-muted">

 The Overall Positive Rating Percentage A Seller Needs To Have In Order To Become Top Rated

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Top Rated Seller Completed Orders : </label>

<div class="col-md-6">

<input type="text" name="level_top_orders" class="form-control" value="<?php echo $level_top_orders; ?>">

<small class="form-text text-muted">

How Many Completed Orders A Seller Needs To Have In Order To Become Top Rated

</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Enable Referrals : </label>

<div class="col-md-6">

<select name="enable_referrals" class="form-control">

<?php if($enable_referrals == "yes"){ ?>

<option value="yes"> Yes </option>

<option value="no"> No </option>

<?php }elseif($enable_referrals == "no"){ ?>

<option value="no"> No </option>

<option value="yes"> Yes </option>

<?php } ?>

</select>

<small class="form-text text-muted">

ENABLE OR DISABLE THE REFERRAL SYSTEM

</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Money To Pay For Each Referral : </label>

<div class="col-md-6">

<div class="input-group"><!--- input-group Starts --->

<span class="input-group-addon">

<b>$</b>

</span>


<input type="number" name="referral_money" class="form-control" min="1" value="<?php echo $referral_money; ?>">

</div><!--- input-group Ends --->

<small class="form-text text-muted">

 THE AMOUNT OF MONEY, ENTER NUMBERS ONLY, TO PAY THE PERSON FOR EACH REFFERAL THAT SIGNS UP

</small>

</div>

</div><!--- form-group row Ends --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="general_settings_update" class="form-control btn btn-primary" value="Update General Settings">

</div>

</div><!--- form-group row Ends --->



</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card mb-5 Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<div class="row"><!--- 3 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card mb-5"><!--- card mb-5 Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-cubes fa-fw"></i> View Boxes

<small class="text-muted">

This Boxes Will Show if any visitor open website site page without login into website.

</small>

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<a class="btn btn-success btn-lg float-right" href="index.php?insert_box">

Add New Box

</a>

<div class="clearfix mb-4"></div>

<div class="row"><!-- row Starts --->

<?php

$get_boxes = "select * from section_boxes";

$run_boxes = mysqli_query($con,$get_boxes);

while($row_boxes = mysqli_fetch_array($run_boxes)){

$box_id = $row_boxes['box_id'];

$box_title = $row_boxes['box_title'];

$box_desc = $row_boxes['box_desc'];

?>

<div class="col-lg-4 col-md-6 mb-lg-0 mb-3"><!--- col-lg-4 col-md-6 mb-lg-0 mb-3 Starts --->

<div class="card mb-3"><!--- card Starts --->

<div class="card-header text-center"><!--- card-header text-center Starts --->

<h4 class="h4">

<?php echo $box_title; ?>

</h4>

</div><!--- card-header text-center Ends --->

<div class="card-body"><!--- card-body Starts --->

<p><?php echo $box_desc; ?></p>

</div><!--- card-body Ends --->

<div class="card-footer"><!--- card-footer Starts --->

<a href="index.php?delete_box=<?php echo $box_id; ?>" class="float-left">

<i class="fa fa-trash-alt"></i> Delete

</a>

<a href="index.php?edit_box=<?php echo $box_id; ?>" class="float-right">

<i class="fa fa-pencil-alt"></i> Edit

</a>

<div class="clearfix"> </div>

</div><!--- card-footer Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-4 col-md-6 mb-lg-0 mb-3 Ends --->

<?php } ?>

</div><!-- row Ends --->

</div><!--- card-body Ends --->

</div><!--- card mb-5 Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 3 row Ends --->


<div class="row"><!--- 4 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-home fa-fw"></i>  Home Page Call To Action Section

<small class="text-muted">

This Section Will Show if any visitor open website site page without login into website.

</small>

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post" enctype="multipart/form-data"><!--- form Starts --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Section Title : </label>

<div class="col-md-6">

<input type="text" name="section_title" class="form-control" value="<?php echo $section_title; ?>">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Section Short Description : </label>

<div class="col-md-6">

<input type="text" name="section_short_desc" class="form-control" value="<?php echo $section_short_desc; ?>">

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Section Description : </label>

<div class="col-md-6">

<textarea name="section_desc" class="form-control" cols="19"><?php echo $section_desc; ?></textarea>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Section Button : </label>

<div class="col-md-6">

<input type="text" name="section_button" class="form-control" value="<?php echo $section_button?>">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Section Button Url : </label>

<div class="col-md-6">

<input type="text" name="section_button_url" class="form-control" value="<?php echo $section_button_url; ?>">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Section Image : </label>

<div class="col-md-6">

<input type="file" name="section_image" class="form-control">

<br>

<img src="../images/<?php echo $db_section_image; ?>" width="60" height="60">

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="update_section" class="form-control btn btn-primary" value="Update Section">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 4 row Ends --->



<?php

if(isset($_POST['general_settings_update'])){
	
$site_title = mysqli_real_escape_string($con,$_POST['site_title']);

$site_desc = mysqli_real_escape_string($con,$_POST['site_desc']);

$site_keywords = mysqli_real_escape_string($con,$_POST['site_keywords']);

$site_author = mysqli_real_escape_string($con,$_POST['site_author']);

$site_url = mysqli_real_escape_string($con,$_POST['site_url']);

$site_email_address = mysqli_real_escape_string($con,$_POST['site_email_address']);

$level_one_rating = mysqli_real_escape_string($con,$_POST['level_one_rating']);

$level_one_orders = mysqli_real_escape_string($con,$_POST['level_one_orders']);

$level_two_rating = mysqli_real_escape_string($con,$_POST['level_two_rating']);

$level_two_orders = mysqli_real_escape_string($con,$_POST['level_two_orders']);

$level_top_rating = mysqli_real_escape_string($con,$_POST['level_top_rating']);

$level_top_orders = mysqli_real_escape_string($con,$_POST['level_top_orders']);

$enable_referrals = mysqli_real_escape_string($con,$_POST['enable_referrals']);

$referral_money = mysqli_real_escape_string($con,$_POST['referral_money']);
	
	
$update_general_settings = "update general_settings set site_title='$site_title',site_desc='$site_desc',site_keywords='$site_keywords',site_author='$site_author',site_url='$site_url',site_email_address='$site_email_address',level_one_rating='$level_one_rating',level_one_orders='$level_one_orders',level_two_rating='$level_two_rating',level_two_orders='$level_two_orders',level_top_rating='$level_top_rating',level_top_orders='$level_top_orders',enable_referrals='$enable_referrals',referral_money='$referral_money'";
	
$run_update_general_settings = mysqli_query($con,$update_general_settings);
	
if($run_update_general_settings){
	
echo "<script>alert(' General Settings Has Been Updated Successfully.');</script>";

echo "<script>window.open('index.php?general_settings','_self')</script>";

	
}
	
	
}


if(isset($_POST['update_section'])){
	
$section_title = mysqli_real_escape_string($con,$_POST['section_title']);

$section_short_desc = mysqli_real_escape_string($con,$_POST['section_short_desc']);

$section_desc = mysqli_real_escape_string($con,$_POST['section_desc']);

$section_button = mysqli_real_escape_string($con,$_POST['section_button']);

$section_button_url = mysqli_real_escape_string($con,$_POST['section_button_url']);

$section_image = $_FILES['section_image']['name'];

$section_image_tmp = $_FILES['section_image']['tmp_name'];
	
	
if(empty($section_image)){
	
$section_image = $db_section_image;
	
}
	
move_uploaded_file($section_image_tmp, "../images/$section_image");
	
$update_section = "update home_section set section_title='$section_title',section_short_desc='$section_short_desc',section_desc='$section_desc',section_button='$section_button',section_button_url='$section_button_url',section_image='$section_image' where section_id='$section_id'";
	
$run_update_section = mysqli_query($con,$update_section);
	
if($run_update_section){
	
echo "<script>alert('Home Page Call To Action Section has been updated successfully. ');</script>";

echo "<script>window.open('index.php?general_settings','_self')</script>";
	
}
	
	
	
	
}


?>



<?php } ?>