<?php 

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

?>


<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Sub Categories

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Sub Categories

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!---  card-body Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-bordered table-hover"><!--- table table-bordered table-hover Starts --->

<thead><!--- thead Starts --->

<tr>

<th>Sub Category Id</th>

<th>Sub Category Title</th>

<th>Sub Category Description</th>

<th>Parent Category Title</th>

<th>Delete Sub Category</th>

<th>Edit Sub Category</th>

</tr>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php

$i = 0;

$per_page = 10;

if(isset($_GET['child_cats_pagination'])){
	
$page = $_GET['child_cats_pagination'];
	
}else{
	
$page = 1;
	
}

/// Page will start from 0 and multiply by per page

$start_from = ($page-1) * $per_page;

$get_child_cats = "select * from categories_childs order by 1 DESC LIMIT $start_from,$per_page";

$run_child_cats = mysqli_query($con,$get_child_cats);

while($row_child_cats = mysqli_fetch_array($run_child_cats)){

$child_id = $row_child_cats['child_id'];

$child_parent_id = $row_child_cats['child_parent_id'];

$child_title = $row_child_cats['child_title'];

$child_desc = $row_child_cats['child_desc'];


$get_cats = "select * from categories where cat_id='$child_parent_id'";

$run_cats = mysqli_query($con,$get_cats);

$row_cats = mysqli_fetch_array($run_cats);

$cat_title = $row_cats['cat_title'];


$i++;

?>

<tr>

<td><?php echo $i; ?></td>

<td><?php echo $child_title; ?></td>

<td width="400"><?php echo $child_desc; ?></td>

<td><?php echo $cat_title; ?></td>

<td>

<a href="index.php?delete_child_cat=<?php echo $child_id; ?>" onclick="return confirm('Do you really want to delete this sub category permanently.');">

<i class="fa fa-trash-alt"></i> Delete

</a>

</td>


<td>

<a href="index.php?edit_child_cat=<?php echo $child_id; ?>">

<i class="fa fa-pencil-alt"></i> Edit

</a>

</td>


</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-bordered table-hover Ends --->

</div><!--- table-responsive Ends --->

<div class="d-flex justify-content-center"><!--- d-flex justify-content-center Starts --->

<ul class="pagination"><!--- pagination Starts --->

<?php

/// Now Select All Data From Table

$query = "select * from categories_childs order by 1 DESC";

$run_query = mysqli_query($con,$query);

/// Count The Total Records 

$total_records = mysqli_num_rows($run_query);

/// Using ceil function to divide the total records on per page

$total_pages = ceil($total_records / $per_page);

echo "

<li class='page-item'>

<a href='index.php?child_cats_pagination=1' class='page-link'>

First Page

</a>

</li>

";

for($i=1; $i<=$total_pages; $i++){
	
echo "

<li class='page-item";

if($i == $page){
	
echo " active ";
	
}

echo "'>

<a href='index.php?child_cats_pagination=".$i."' class='page-link'>

".$i."

</a>

</li>

";
	
	
}


echo "

<li class='page-item'>

<a href='index.php?child_cats_pagination=$total_pages' class='page-link'>

Last Page

</a>

</li>

";




?>

</ul><!--- pagination Ends --->

</div><!--- d-flex justify-content-center Ends --->


</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->




<?php } ?>