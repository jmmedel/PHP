<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{

?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / View Pending Buyer Requests

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->



<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card"><!--- card Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> View Pending Buyer Requests

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<div class="table-responsive"><!--- table-responsive Starts --->

<table class="table table-bordered table-hover"><!--- table table-bordered table-hover Starts --->

<thead><!--- thead Starts --->

<tr>

<th>BUYER </th>

<th>TITLE </th>

<th>DESCRIPTION </th>

<th>FILE </th>

<th>DURATION </th>

<th>BUDGET </th>

<th> ACTION </th>

</tr>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php

$per_page = 7;

$get_requests = "select * from buyer_requests where request_status='pending' order by 1 DESC LIMIT 0,$per_page";

$run_requests = mysqli_query($con,$get_requests);

while($row_requests = mysqli_fetch_array($run_requests)){

$request_id = $row_requests['request_id'];

$request_title = $row_requests['request_title'];

$request_description = $row_requests['request_description'];

$seller_id = $row_requests['seller_id'];

$request_budget = $row_requests['request_budget'];

$delivery_time = $row_requests['delivery_time'];

$request_file = $row_requests['request_file'];

$request_status = $row_requests['request_status'];


$get_sellers = "select * from sellers where seller_id='$seller_id'";

$run_sellers = mysqli_query($con,$get_sellers);

$row_sellers = mysqli_fetch_array($run_sellers);
	
$seller_user_name = $row_sellers['seller_user_name'];


?>

<tr>

<td><?php echo $seller_user_name; ?></td>

<td><?php echo $request_title; ?></td>

<td width="200"><?php echo $request_description; ?></td>

<td>

<?php if(!empty($request_file)){ ?>

<a href="../requests/request_files/<?php echo $request_file; ?>" download>

<i class="fa fa-download"></i> <?php echo $request_file; ?>

</a>

<?php }else{ ?>

No File Attached

<?php } ?>

</td>

<td><?php echo $delivery_time; ?></td>

<td>

<?php if(!empty($request_budget)){ ?>

$<?php echo $request_budget; ?>

<?php }else{ ?>

No Budget Set

<?php } ?>

</td>


<td>

<a href="index.php?approve_request=<?php echo $request_id; ?>" class="btn btn-primary" onclick="return confirm('Do you really want to approve this request permanently.')">

<i class="fa fa-thumbs-up"></i> Approve

</a>

<a href="index.php?unapprove_request=<?php echo $request_id; ?>" class="btn btn-primary" onclick="return confirm('Do you really want to unapprove this request permanently.')">

<i class="fa fa-thumbs-down"></i> Unapprove

</a>

</td>

</tr>

<?php } ?>

</tbody><!--- tbody Ends --->

</table><!--- table table-bordered table-hover Ends --->

</div><!--- table-responsive Ends --->

<div class="d-flex justify-content-center"><!--- d-flex justify-content-center Starts --->

<ul class="pagination"><!--- pagination Starts --->

<?php

/// Now Select All Data From Table

$query = "select * from buyer_requests where request_status='pending' order by 1 DESC";

$run_query = mysqli_query($con,$query);

/// Count The Total Records 

$total_records = mysqli_num_rows($run_query);

/// Using ceil function to divide the total records on per page

$total_pages = ceil($total_records / $per_page);

echo "

<li class='page-item'>

<a href='index.php?buyer_requests_pagination=1' class='page-link'>

First Page

</a>

</li>

";

for($i=1; $i<=$total_pages; $i++){
	
echo "

<li class='page-item'>

<a href='index.php?buyer_requests_pagination=".$i."' class='page-link'>

".$i."

</a>

</li>

";
	
	
}


echo "

<li class='page-item'>

<a href='index.php?buyer_requests_pagination=$total_pages' class='page-link'>

Last Page

</a>

</li>

";




?>

</ul><!--- pagination Ends --->

</div><!--- d-flex justify-content-center Ends --->

</div><!--- card-body Ends --->

</div><!--- card Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->



<?php } ?>