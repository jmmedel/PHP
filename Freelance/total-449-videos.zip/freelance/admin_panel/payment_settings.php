<?php

@session_start();

if(!isset($_SESSION['admin_email'])){
	
echo "<script>window.open('login.php','_self');</script>";
	
}else{
	

$get_payment_settings = "select * from payment_settings";
	
$run_payment_settings = mysqli_query($con,$get_payment_settings);

$row_payment_settings = mysqli_fetch_array($run_payment_settings);

$comission_percentage = $row_payment_settings['comission_percentage'];

$days_before_withdraw = $row_payment_settings['days_before_withdraw'];

$withdrawal_limit = $row_payment_settings['withdrawal_limit'];

$featured_fee = $row_payment_settings['featured_fee'];

$featured_duration = $row_payment_settings['featured_duration'];

$processing_fee = $row_payment_settings['processing_fee'];


$enable_paypal = $row_payment_settings['enable_paypal'];

$paypal_email = $row_payment_settings['paypal_email'];

$paypal_currency_code = $row_payment_settings['paypal_currency_code'];

$paypal_api_username = $row_payment_settings['paypal_api_username'];

$paypal_api_password = $row_payment_settings['paypal_api_password'];

$paypal_api_signature = $row_payment_settings['paypal_api_signature'];

$paypal_app_id = $row_payment_settings['paypal_app_id'];

$paypal_sandbox = $row_payment_settings['paypal_sandbox'];



$enable_stripe = $row_payment_settings['enable_stripe'];

$stripe_secret_key = $row_payment_settings['stripe_secret_key'];

$stripe_publishable_key = $row_payment_settings['stripe_publishable_key'];

$stripe_currency_code = $row_payment_settings['stripe_currency_code'];


?>

<div class="row"><!--- 1 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<ol class="breadcrumb"><!--- breadcrumb Starts --->

<li class="active">

<i class="fa fa-home"></i> Dashboard / Payment Settings

</li>

</ol><!--- breadcrumb Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 1 row Ends --->


<div class="row"><!--- 2 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card mb-5"><!--- card mb-5 Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Update General Payment Settings

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Order Comission Percentage : </label>

<div class="col-md-6">

<div class="input-group"><!--- input-group Starts --->

<input type="number" name="comission_percentage" class="form-control" value="<?php echo $comission_percentage; ?>" min="5" placeholder="5 Minimum">

<span class="input-group-addon">

<b>%</b>

</span>

</div><!--- input-group Ends --->

<small class="form-text text-muted">

PERCENTAGE COMMISSION TO TAKE FROM EACH ORDER PURCHASED

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Days Before Availble For Withdrawal : </label>

<div class="col-md-6">

<div class="input-group"><!--- input-group Starts --->

<input type="number" name="days_before_withdraw" class="form-control" value="<?php echo $days_before_withdraw; ?>" min="1" placeholder="1 Minimum">

<span class="input-group-addon">

<b>Days</b>

</span>

</div><!--- input-group Ends --->

<small class="form-text text-muted">

NUMBER OF DAYS BEFORE REVENUES FROM PROPOSALS CAN BE AVAILABLE FOR WITHDRAWAL BY SELLERS

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Minimum Withdrawal Limit : </label>

<div class="col-md-6">

<div class="input-group"><!--- input-group Starts --->

<span class="input-group-addon">

<b>$</b>

</span>

<input type="number" name="withdrawal_limit" class="form-control" value="<?php echo $withdrawal_limit; ?>" min="5" placeholder="5 Minimum">

</div><!--- input-group Ends --->

<small class="form-text text-muted">

THE MINIMUM AVAILABLE BALANCE A USER MUST HAVE TO BE ABLE TO REQUEST A WITHDRAWAL, ENTERING 5 WOULD BE A  $5.00 LIMIT

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Featured Proposal Listing Fee : </label>

<div class="col-md-6">

<div class="input-group"><!--- input-group Starts --->

<span class="input-group-addon">

<b>$</b>

</span>

<input type="number" name="featured_fee" class="form-control" value="<?php echo $featured_fee; ?>" min="5" placeholder="5 Minimum">

</div><!--- input-group Ends --->

<small class="form-text text-muted">

PRICE YOU WANT TO CHARGE SELLERS TO FEATURE A PROPOSAL

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Featured Proposal Listing Duration : </label>

<div class="col-md-6">

<div class="input-group"><!--- input-group Starts --->

<input type="number" name="featured_duration" class="form-control" value="<?php echo $featured_duration; ?>" min="1" placeholder="1 Minimum">

<span class="input-group-addon">

<b>Days</b>

</span>

</div><!--- input-group Ends --->

<small class="form-text text-muted">

NUMBER OF DAYS EACH Proposal IS FEATURED FOR AFTER PAYMENT

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Processing Fee : </label>

<div class="col-md-6">

<div class="input-group"><!--- input-group Starts --->

<span class="input-group-addon">

<b>$</b>

</span>

<input type="number" name="processing_fee" class="form-control" value="<?php echo $processing_fee; ?>" min="1" placeholder="1 Minimum">

</div><!--- input-group Ends --->

<small class="form-text text-muted">

THE PROCESSING FEE YOU WISH TO CHARGE FOR ANY PURCHASE

</small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="update_general_payment_settings" value="Update General Payment Settings" class="btn btn-primary form-control">

</div>

</div><!--- form-group row Ends --->



</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card mb-5 Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 2 row Ends --->


<div class="row"><!---  3 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card mb-5"><!--- card mb-5 Starts -->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Update Paypal Settings

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Enable Paypal : </label>

<div class="col-md-6">

<select name="enable_paypal" class="form-control">

<?php if($enable_paypal == 'yes'){ ?>

<option value="yes"> Yes </option>

<option value="no"> No </option>

<?php }elseif($enable_paypal == 'no'){ ?>

<option value="no"> No </option>

<option value="yes"> Yes </option>

<?php } ?>

</select>

<small class="form-text text-muted">ALLOW BUYERS TO PAY USING PAYPAL</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Paypal Email : </label>

<div class="col-md-6">

<input type="text" name="paypal_email" class="form-control" value="<?php echo $paypal_email; ?>">

<small class="form-text text-muted">Enter Paypal Bussiness Email For Receiving Paypal Payments And Sending Revenues To Sellers Paypal Accounts.</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Paypal Currency Code : </label>

<div class="col-md-6">

<input type="text" name="paypal_currency_code" class="form-control" value="<?php echo $paypal_currency_code; ?>">

<small class="form-text text-muted">

CURRENCY USED FOR PAYPAL PAYMENTS <a href="https://developer.paypal.com/docs/classic/api/currency_codes/" target="_blank">CLICK HERE TO GET ALL PAYPAL CURRENCY CODES</a>

</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Paypal Api Username : </label>

<div class="col-md-6">

<input type="text" name="paypal_api_username" class="form-control" value="<?php echo $paypal_api_username; ?>">


</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Paypal Api Password : </label>

<div class="col-md-6">

<input type="text" name="paypal_api_password" class="form-control" value="<?php echo $paypal_api_password; ?>">

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Paypal Api Signature : </label>

<div class="col-md-6">

<input type="text" name="paypal_api_signature" class="form-control" value="<?php echo $paypal_api_signature; ?>">

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Paypal App Id : </label>

<div class="col-md-6">

<input type="text" name="paypal_app_id" class="form-control" value="<?php echo $paypal_app_id; ?>">

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Paypal Sandbox : </label>

<div class="col-md-6">

<input type="radio" name="paypal_sandbox" value="on" required
<?php

if($paypal_sandbox == 'on'){
	
echo "checked";
	
}else{
	
	
}

?>
>

<label> On </label>

<input type="radio" name="paypal_sandbox" value="off" required
<?php

if($paypal_sandbox == 'off'){
	
echo "checked";
	
}else{
	
	
}

?>

>

<label> Off </label>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> </label>

<div class="col-md-6">

<input type="submit" name="update_paypal_settings" class="btn btn-primary form-control" value="Update Paypal Settings">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card mb-5 Ends -->

</div><!--- col-lg-12 Ends --->

</div><!---  3 row Ends --->


<div class="row"><!--- 4 row Starts --->

<div class="col-lg-12"><!--- col-lg-12 Starts --->

<div class="card mb-5"><!--- card mb-5 Starts --->

<div class="card-header"><!--- card-header Starts --->

<h4 class="h4">

<i class="fa fa-money-bill-alt fa-fw"></i> Update Stripe Settings

</h4>

</div><!--- card-header Ends --->

<div class="card-body"><!--- card-body Starts --->

<form action="" method="post"><!--- form Starts --->

<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Enable Stripe : </label>

<div class="col-md-6">

<select name="enable_stripe" class="form-control">

<?php if($enable_stripe == "yes"){ ?>

<option value="yes"> Yes </option>

<option value="no"> No </option>

<?php }elseif($enable_stripe == "no"){ ?>

<option value="no"> No </option>

<option value="yes"> Yes </option>

<?php } ?>

</select>

<small class="form-text text-muted">ALLOW BUYERS TO PAY USING STRIPE</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Stripe Secret Key : </label>

<div class="col-md-6">

<input type="text" name="stripe_secret_key" class="form-control" value="<?php echo $stripe_secret_key; ?>">

<small class="form-text text-muted">YOUR STRIPE SECRET KEY ASSIGNED TO YOU</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Stripe Publishable Key : </label>

<div class="col-md-6">

<input type="text" name="stripe_publishable_key" class="form-control" value="<?php echo $stripe_publishable_key; ?>">

<small class="form-text text-muted">YOUR STRIPE PUBLISHABLE KEY ASSIGNED TO YOU</small>

</div>

</div><!--- form-group row Ends --->


<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"> Stripe Currency Code : </label>

<div class="col-md-6">

<input type="text" name="stripe_currency_code" class="form-control" value="<?php echo $stripe_currency_code; ?>">

<small class="form-text text-muted">CURRENCY USED FOR STRIPE PAYMENTS <a href="https://stripe.com/docs/currencies" target="_blank"> CLICK HERE TO GET ALL STRIPE CURRENCY ISO CODES </a> </small>

</div>

</div><!--- form-group row Ends --->



<div class="form-group row"><!--- form-group row Starts --->

<label class="col-md-3 control-label"></label>

<div class="col-md-6">

<input type="submit" name="update_stripe_settings" class="btn btn-primary form-control" value="Update Stripe Settings">

</div>

</div><!--- form-group row Ends --->


</form><!--- form Ends --->

</div><!--- card-body Ends --->

</div><!--- card mb-5 Ends --->

</div><!--- col-lg-12 Ends --->

</div><!--- 4 row Ends --->


<?php

if(isset($_POST['update_general_payment_settings'])){
	
$comission_percentage = mysqli_real_escape_string($con,$_POST['comission_percentage']);

$days_before_withdraw = mysqli_real_escape_string($con,$_POST['days_before_withdraw']);

$withdrawal_limit = mysqli_real_escape_string($con,$_POST['withdrawal_limit']);

$featured_fee = mysqli_real_escape_string($con,$_POST['featured_fee']);

$featured_duration = mysqli_real_escape_string($con,$_POST['featured_duration']);

$processing_fee = mysqli_real_escape_string($con,$_POST['processing_fee']);
	
$update_general_payment_settings = "update payment_settings set featured_fee='$featured_fee',comission_percentage='$comission_percentage',days_before_withdraw='$days_before_withdraw',withdrawal_limit='$withdrawal_limit',processing_fee='$processing_fee',featured_duration='$featured_duration'";
	
$run_general_payment_settings = mysqli_query($con,$update_general_payment_settings);
	
if($run_general_payment_settings){
	
echo "<script>alert('General Payment Settings Has Been Updated Successfully.');</script>";	

echo "<script>window.open('index.php?payment_settings','_self');</script>";

	
}
	
	
}


if(isset($_POST['update_paypal_settings'])){
	
$enable_paypal = mysqli_real_escape_string($con,$_POST['enable_paypal']);

$paypal_email = mysqli_real_escape_string($con,$_POST['paypal_email']);

$paypal_currency_code = mysqli_real_escape_string($con,$_POST['paypal_currency_code']);

$paypal_api_username = mysqli_real_escape_string($con,$_POST['paypal_api_username']);

$paypal_api_password = mysqli_real_escape_string($con,$_POST['paypal_api_password']);

$paypal_api_signature = mysqli_real_escape_string($con,$_POST['paypal_api_signature']);

$paypal_app_id = mysqli_real_escape_string($con,$_POST['paypal_app_id']);

$paypal_sandbox = mysqli_real_escape_string($con,$_POST['paypal_sandbox']);
	
$update_paypal_settings = "update payment_settings set enable_paypal='$enable_paypal',paypal_email='$paypal_email',paypal_currency_code='$paypal_currency_code',paypal_api_username='$paypal_api_username',paypal_api_password='$paypal_api_password',paypal_api_signature='$paypal_api_signature',paypal_app_id='$paypal_app_id',paypal_sandbox='$paypal_sandbox'";
	
$run_paypal_settings = mysqli_query($con,$update_paypal_settings);
	
if($run_paypal_settings){
	
echo "<script>alert('Paypal Settings Have Been Updated Successfully.');</script>";	

echo "<script>window.open('index.php?payment_settings','_self');</script>";

	
}
	
	
}


if(isset($_POST['update_stripe_settings'])){
	
$enable_stripe = mysqli_real_escape_string($con,$_POST['enable_stripe']);

$stripe_secret_key = mysqli_real_escape_string($con,$_POST['stripe_secret_key']);

$stripe_publishable_key = mysqli_real_escape_string($con,$_POST['stripe_publishable_key']);

$stripe_currency_code = mysqli_real_escape_string($con,$_POST['stripe_currency_code']);
	
	
$update_stripe_settings = "update payment_settings set enable_stripe='$enable_stripe',stripe_secret_key='$stripe_secret_key',stripe_publishable_key='$stripe_publishable_key',stripe_currency_code='$stripe_currency_code'";
	
$run_stripe_settings = mysqli_query($con,$update_stripe_settings);
	
if($run_stripe_settings){
	
		
echo "<script>alert('Stripe Settings Have Been Updated Successfully.');</script>";	

echo "<script>window.open('index.php?payment_settings','_self');</script>";

	
}
	
	
}


?>


<?php } ?>