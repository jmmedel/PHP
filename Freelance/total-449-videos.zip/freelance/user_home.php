
<?php

$login_seller_user_name = $_SESSION['seller_user_name'];

$select_login_seller = "select * from sellers where seller_user_name='$login_seller_user_name'";

$run_login_seller = mysqli_query($con,$select_login_seller);

$row_login_seller = mysqli_fetch_array($run_login_seller);

$login_seller_id = $row_login_seller['seller_id'];

$login_seller_name = $row_login_seller['seller_name'];

$login_seller_offers = $row_login_seller['seller_offers'];

?>

<div id="myCarousel" class="carousel slide"><!--- carousel slide Starts --->

<ol class="carousel-indicators"><!--- carousel-indicators Starts --->

<li data-target="#myCarousel" data-slide-to="0" class="active"></li>

<?php

$get_slides = "select * from slider";

$run_slides = mysqli_query($con,$get_slides);

$count_slides = mysqli_num_rows($run_slides);

$i = 0;

$get_slides = "select * from slider LIMIT 1,$count_slides";

$run_slides = mysqli_query($con,$get_slides);

while($row_slides = mysqli_fetch_array($run_slides)){

$i++;

?>

<li data-target="#myCarousel" data-slide-to="<?php echo $i; ?>"></li>

<?php } ?>

</ol><!--- carousel-indicators Ends --->

<div class="carousel-inner"><!--- carousel-inner Starts -->

<?php

$get_slides = "select * from slider LIMIT 0,1";

$run_slides = mysqli_query($con,$get_slides);

while($row_slides = mysqli_fetch_array($run_slides)){

$slide_image = $row_slides['slide_image'];

$slide_name = $row_slides['slide_name'];

$slide_desc = $row_slides['slide_desc'];

$slide_url = $row_slides['slide_url'];

?>

<div class="carousel-item active"><!--- carousel-item active Starts -->

<a href="<?php echo $slide_url; ?>"><!--- a Starts --->

<img src="slides_images/<?php echo $slide_image; ?>" class="d-block w-100">

<div class="carousel-caption"><!--- carousel-caption Starts --->

<h3 class="d-lg-block d-md-block d-none"> <?php echo $slide_name; ?> </h3>

<p class="d-lg-block d-md-block d-none">

<?php echo $slide_desc; ?> 

</p>

</div><!--- carousel-caption Ends --->

</a><!--- a Ends --->

</div><!--- carousel-item active Ends -->

<?php } ?>



<?php

$get_slides = "select * from slider LIMIT 1,$count_slides";

$run_slides = mysqli_query($con,$get_slides);

while($row_slides = mysqli_fetch_array($run_slides)){

$slide_image = $row_slides['slide_image'];

$slide_name = $row_slides['slide_name'];

$slide_desc = $row_slides['slide_desc'];

$slide_url = $row_slides['slide_url'];

?>

<div class="carousel-item"><!--- carousel-item Starts -->

<a href="<?php echo $slide_url; ?>"><!--- a Starts --->

<img src="slides_images/<?php echo $slide_image; ?>" class="d-block w-100">

<div class="carousel-caption"><!--- carousel-caption Starts --->

<h3 class="d-lg-block d-md-block d-none"> <?php echo $slide_name; ?> </h3>

<p class="d-lg-block d-md-block d-none">

<?php echo $slide_desc; ?> 

</p>

</div><!--- carousel-caption Ends --->

</a><!--- a Ends --->

</div><!--- carousel-item Ends -->

<?php } ?>

</div><!--- carousel-inner Ends -->

<a class="carousel-control-prev" href="#myCarousel" data-slide="prev"><!--- carousel-control-prev Starts -->

<span class="carousel-control-prev-icon"></span>

</a><!--- carousel-control-prev Ends -->


<a class="carousel-control-next" href="#myCarousel" data-slide="next"><!--- carousel-control-next Starts -->

<span class="carousel-control-next-icon"></span>

</a><!--- carousel-control-next Ends -->


</div><!--- carousel slide Ends --->



<div class="container-fluid mt-5"><!--- container-fluid mt-5 Starts --->

<div class="row"><!--- row Starts --->

<div class="col-md-3"><!--- col-md-3 Starts --->

<?php include("includes/user_home_sidebar.php"); ?>

</div><!--- col-md-3 Ends --->

<div class="col-md-9"><!--- col-md-9 Starts --->

<div class="row"><!--- row Starts --->

<div class="col-md-12"><!--- col-md-12 Starts --->

<h2> Featuerd Proposals </h2>

</div><!--- col-md-12 Ends --->

</div><!--- row Ends --->

<div class="row"><!--- row Starts --->

<div class="col-md-12 flex-wrap"><!--- col-md-12 flex-wrap Starts --->

<div class="owl-carousel user-home-featured-carousel owl-theme"><!--- owl-carousel user-home-featured-carousel owl-theme Starts --->

<?php

$get_proposals = "select * from proposals where proposal_featured='yes' AND proposal_status='active'";

$run_proposals = mysqli_query($con,$get_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_video = $row_proposals['proposal_video'];

$proposal_seller_id = $row_proposals['proposal_seller_id'];

$proposal_rating = $row_proposals['proposal_rating'];

$proposal_url = $row_proposals['proposal_url'];

if(empty($proposal_video)){
	
	$video_class = "";
	
}else{
	
	$video_class = "video-img";
	
}

$select_seller = "select * from sellers where seller_id='$proposal_seller_id'";

$run_seller = mysqli_query($con,$select_seller);

$row_seller = mysqli_fetch_array($run_seller);

$seller_user_name = $row_seller['seller_user_name'];

$select_buyer_reviews = "select * from buyer_reviews where proposal_id='$proposal_id'";

$run_buyer_reviews = mysqli_query($con,$select_buyer_reviews);

$count_reviews = mysqli_num_rows($run_buyer_reviews);

$select_favorites = "select * from favorites where proposal_id='$proposal_id' AND seller_id='$login_seller_id'";

$run_favorites = mysqli_query($con,$select_favorites);

$count_favorites = mysqli_num_rows($run_favorites);

if($count_favorites == 0){
	
	$show_favorite_id = "favorite_$proposal_id";
	
	$show_favorite_class = "favorite";
	
}else{

	$show_favorite_id = "unfavorite_$proposal_id";
	
	$show_favorite_class = "favorited";
	
}

?>

<div class="proposal-div"><!--- proposal-div Starts --->

<div class="proposal_nav"><!--- proposal_nav Starts --->

<span class="float-left mt-2"><!--- float-left mt-2 Starts --->

<strong class="ml-2 mr-1"> By </strong> <?php echo $seller_user_name; ?>

</span><!--- float-left mt-2 Ends --->

<span class="float-right mt-2"><!--- float-right mt-2 Starts --->

<?php

for($proposal_i=0; $proposal_i<$proposal_rating; $proposal_i++){
	
	echo " <img class='rating' src='images/user_rate_full.png' > ";
	
}

for($proposal_i=$proposal_rating; $proposal_i<5; $proposal_i++){
	
	echo " <img class='rating' src='images/user_rate_blank.png' > ";
	
}


?>

<span class="ml-1 mr-2">(<?php echo $count_reviews; ?>)</span>

</span><!--- float-right mt-2 Ends --->

<div class="clearfix mb-2"> </div>

</div><!--- proposal_nav Ends --->

<a href="proposals/<?php echo $proposal_url; ?>">

<hr class="m-0 p-0">

<img src="proposals/proposal_files/<?php echo $proposal_img1; ?>" class="resp-img">

</a>

<div class="text"><!--- text Starts --->

<h4>

<a href="proposals/<?php echo $proposal_url; ?>" class="<?php echo $video_class; ?>">

<?php echo $proposal_title; ?>

</a>

</h4>

<hr>


<p class="buttons clearfix"><!--- buttons clearfix Starts --->

<a href="#" id="<?php echo $show_favorite_id; ?>" class="<?php echo $show_favorite_class; ?> mt-2 float-left" data-toggle="tooltip" title="Add To Favorites">

<i class="fa fa-heart fa-lg"></i>

</a>


<span class="float-right"> STARTING AT <strong class="price"> $<?php echo $proposal_price; ?> </strong> </span>

</p><!--- buttons clearfix Ends --->


</div><!--- text Ends --->

<div class="ribbon"><!--- ribbon Starts --->

<div class="theribbon"> Featuerd </div>

<div class="ribbon-background"></div>

</div><!--- ribbon Ends --->

<script>

$(document).on("click", "#favorite_<?php echo $proposal_id; ?>", function(event){
	
event.preventDefault();	

var seller_id = "<?php echo $login_seller_id; ?>";

var proposal_id = "<?php echo $proposal_id; ?>";

$.ajax({
	
	type: "POST",
	url: "includes/add_delete_favorite.php",
	data: { seller_id: seller_id, proposal_id: proposal_id, favorite: "add_favorite" },
	success: function(){
		
	$("#favorite_<?php echo $proposal_id; ?>").attr({
		
		id: "unfavorite_<?php echo $proposal_id; ?>", class: "favorited mt-2 float-left"
		
		
	});
		
	}
	
	
	
});
	
	
});

$(document).on("click", "#unfavorite_<?php echo $proposal_id; ?>", function(event){
	
event.preventDefault();	

var seller_id = "<?php echo $login_seller_id; ?>";

var proposal_id = "<?php echo $proposal_id; ?>";

$.ajax({
	
	type: "POST",
	url: "includes/add_delete_favorite.php",
	data: { seller_id: seller_id, proposal_id: proposal_id, favorite: "delete_favorite" },
	success: function(){
		
	$("#unfavorite_<?php echo $proposal_id; ?>").attr({
		
		id: "favorite_<?php echo $proposal_id; ?>", class: "favorite mt-2 float-left"
		
		
	});
		
	}
	
	
	
});
	
	
});

</script>

</div><!--- proposal-div Ends --->


<?php } ?>


</div><!--- owl-carousel user-home-featured-carousel owl-theme Ends --->

</div><!--- col-md-12 flex-wrap Ends --->

</div><!--- row Ends --->


<div class="row"><!--- row Starts --->

<div class="col-md-12"><!--- col-md-12 Starts --->

<h2> Recent Buyer Requests </h2>

</div><!--- col-md-12 Ends --->

</div><!--- row Ends --->


<div class="row buyer-requests"><!--- row buyer-requests Starts --->

<div class="col-md-12"><!--- col-md-12 Starts -->

<div class="table-responsive box-table"><!--- table-responsive box-table Starts --->

<table class="table table-hover"><!--- table table-hover Starts --->

<thead><!--- thead Starts --->

<tr>

<th>Request</th>

<th>Offers</th>

<th>Duration</th>

<th>Budget</th>

</tr>

</thead><!--- thead Ends --->

<tbody><!--- tbody Starts --->

<?php

$request_child_ids = array();

$select_proposals = "select DISTINCT proposal_child_id from proposals where proposal_seller_id='$login_seller_id'";

$run_proposals = mysqli_query($con,$select_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){
	
	$proposal_child_id = $row_proposals['proposal_child_id'];
	
	array_push($request_child_ids, $proposal_child_id);
	
}

$where_child_id = array();

foreach($request_child_ids as $child_id){
	
	$where_child_id[] = "child_id=" . $child_id; 
	
}

if(count($where_child_id) > 0){
	
	$query_where = " and (" . implode(" or ", $where_child_id) . ")";
	
}

if(!empty($query_where)){
	
$select_requests = "select * from buyer_requests where request_status='active'" . $query_where . " AND NOT seller_id='$login_seller_id' order by 1 DESC LIMIT 0,4";

$run_requests = mysqli_query($con,$select_requests);

while($row_requests = mysqli_fetch_array($run_requests)){
	
$request_id = $row_requests['request_id'];

$seller_id = $row_requests['seller_id'];

$request_title = $row_requests['request_title'];

$request_description = $row_requests['request_description'];

$delivery_time = $row_requests['delivery_time'];

$request_budget = $row_requests['request_budget'];

$request_file = $row_requests['request_file'];

$select_request_seller = "select * from sellers where seller_id='$seller_id'";

$run_request_seller = mysqli_query($con,$select_request_seller);

$row_request_seller = mysqli_fetch_array($run_request_seller);

$request_seller_user_name = $row_request_seller['seller_user_name'];

$request_seller_image = $row_request_seller['seller_image'];

$select_send_offers = "select * from send_offers where request_id='$request_id'";

$run_send_offers = mysqli_query($con,$select_send_offers);

$count_send_offers = mysqli_num_rows($run_send_offers);

$select_offers = "select * from send_offers where request_id='$request_id' AND sender_id='$login_seller_id'";

$run_offers = mysqli_query($con,$select_offers);

$count_offers = mysqli_num_rows($run_offers);

if($count_offers == 0){

?>

<tr id="request_tr_<?php echo $request_id; ?>"><!--- request_tr_1 id Starts --->

<td>

<?php if(!empty($request_seller_image)){ ?>

<img src="user_images/<?php echo $request_seller_image; ?>" class="request-img rounded-circle">

<?php }else{ ?>

<img src="user_images/empty-image.png" class="request-img rounded-circle">

<?php } ?>

<div class="request-description"><!--- request-description Starts --->

<h6><?php echo $request_seller_user_name; ?></h6>

<h6 class="text-primary"> <?php echo $request_title; ?> </h6>

<p class="lead"> <?php echo $request_description; ?> </p>

<?php if(!empty($request_file)){ ?>

<a href="request_files/<?php echo $request_file; ?>" download>

<i class="fa fa-arrow-circle-down"> </i> <?php echo $request_file; ?>

</a>

<?php } ?>

</div><!--- request-description Ends --->

</td>

<td><?php echo $count_send_offers; ?></td>

<td><?php echo $delivery_time; ?></td>

<td class="text-success">

<?php if(!empty($request_budget)){ ?>

$<?php echo $request_budget; ?>

<?php }else{ ?>

---

<?php } ?>

<br>

<?php if($login_seller_offers == "0"){ ?>

<button class="btn btn-success btn-sm mt-4 send_button_<?php echo $request_id; ?>" data-toggle="modal" data-target="#quota-finish">

Send Offer

</button>

<?php }else{ ?>

<button class="btn btn-success btn-sm mt-4 send_button_<?php echo $request_id; ?>">

Send Offer

</button>

<?php } ?>

</td>

<script>

$(".send_button_<?php echo $request_id; ?>").css("visibility","hidden");

$(document).on("mouseenter", "#request_tr_<?php echo $request_id; ?>", function(){
	
	$(".send_button_<?php echo $request_id; ?>").css("visibility","visible");
	
});

$(document).on("mouseleave", "#request_tr_<?php echo $request_id; ?>", function(){
	
	$(".send_button_<?php echo $request_id; ?>").css("visibility","hidden");
	
});

<?php if($login_seller_offers == "0"){ ?>


<?php }else{ ?>

$(".send_button_<?php echo $request_id; ?>").click(function(){
	
request_id = "<?php echo $request_id; ?>";
	
$.ajax({
	
method: "POST",
url: "requests/send_offer_modal.php",
data: {request_id: request_id}
})
.done(function(data){
	
$(".append-modal").html(data);
	
});
	
});

<?php } ?>

</script>

</tr><!--- request_tr_1 id Ends --->

<?php

}

}

}

?>


</tbody><!--- tbody Ends --->

</table><!--- table table-hover Ends --->

<hr>

<center>

<a href="requests/buyer_requests.php" class="btn btn-success btn-lg mb-3"> 

Load More

</a>

</center>

</div><!--- table-responsive box-table Ends --->

</div><!--- col-md-12 Ends -->

</div><!--- row buyer-requests Ends --->


</div><!--- col-md-9 Ends --->

</div><!--- row Ends --->



<div class="row"><!--- row Starts --->

<div class="col-md-6"><!--- col-md-6 Starts --->

<div class="card border-primary mb-3"><!--- card border-primary mb-3 Starts --->

<div class="card-header bg-primary"><!--- card-header bg-primary Starts --->

<h5 class="h5 text-white"> Random Proposals </h5>

</div><!--- card-header bg-primary Ends --->

<div class="card-body vertical-proposals"><!--- card-body vertical-proposals Starts --->

<?php

$per_page = 4;

if(isset($_GET['random_proposals_page'])){
	
$page = $_GET['random_proposals_page'];

}else{
	
$page = 1;
	
}

/// Page Will Start From 0 and Multiply By Per Page


$start_from = ($page-1) * $per_page;

/// Selecting The Data From Table With Limits

$select_proposals = "select * from proposals where proposal_status='active' order by rand() LIMIT $start_from, $per_page";

$run_proposals = mysqli_query($con,$select_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_video = $row_proposals['proposal_video'];

$proposal_seller_id = $row_proposals['proposal_seller_id'];

$proposal_rating = $row_proposals['proposal_rating'];

$proposal_url = $row_proposals['proposal_url'];

$proposal_desc = substr(strip_tags($row_proposals['proposal_desc']),0,200);

if(empty($proposal_video)){
	
	$video_class = "";
	
}else{
	
	$video_class = "video-img";
	
}

$select_seller = "select * from sellers where seller_id='$proposal_seller_id'";

$run_seller = mysqli_query($con,$select_seller);

$row_seller = mysqli_fetch_array($run_seller);

$seller_user_name = $row_seller['seller_user_name'];

$select_buyer_reviews = "select * from buyer_reviews where proposal_id='$proposal_id'";

$run_buyer_reviews = mysqli_query($con,$select_buyer_reviews);

$count_reviews = mysqli_num_rows($run_buyer_reviews);

?>

<div class="row mb-3"><!--- row mb-3 Starts --->

<div class="col-md-3"><!--- col-md-3 Starts --->

<a href="proposals/<?php echo $proposal_url; ?>" class="<?php echo $video_class; ?>">

<img src="proposals/proposal_files/<?php echo $proposal_img1; ?>" class="vertical-proposal-img">

</a>

</div><!--- col-md-3 Ends --->

<div class="col-md-9"><!--- col-md-9 Starts --->

<div class="text"><!--- text Starts --->

<h6>

<a href="proposals/<?php echo $proposal_url; ?>"> <?php echo $proposal_title; ?> </a>

<span class="text-success"> $<?php echo $proposal_price; ?> </span>

</h6>

<p>

<?php echo $proposal_desc; ?> .. &nbsp;

<a href="proposals/<?php echo $proposal_url; ?>"> Read More </a>

</p>

<hr>

<span class="float-left">

<strong class="ml-2 mr-1"> By </strong> <?php echo $seller_user_name; ?>

</span>

<span class="float-right">

<?php

for($proposal_i=0; $proposal_i<$proposal_rating; $proposal_i++){
	
	echo " <img class='rating' src='images/user_rate_full.png' > ";
	
}

for($proposal_i=$proposal_rating; $proposal_i<5; $proposal_i++){
	
	echo " <img class='rating' src='images/user_rate_blank.png' > ";
	
}


?>

<span class="ml-1 mr-2"> (<?php echo $count_reviews; ?>) </span>

</span>

</div><!--- text Ends --->

</div><!--- col-md-9 Ends --->

</div><!--- row mb-3 Ends --->

<?php } ?>

<ul class="pagination justify-content-center"><!--- pagination justify-content-center Starts --->

<?php

$select_proposals = "select * from proposals where proposal_status='active' order by rand() LIMIT 0,16";

$run_proposals = mysqli_query($con, $select_proposals);

$count_proposals = mysqli_num_rows($run_proposals);

$total_pages = ceil($count_proposals / $per_page);

if(isset($_GET['top_proposals_page'])){
	
	$top_proposals_page = $_GET['top_proposals_page'];
	
}else{
	
	$top_proposals_page = 1;
	
}





?>

<li class="page-item">

<a href="index.php?random_proposals_page=1&top_proposals_page=<?php echo $top_proposals_page; ?>" class="page-link">

First Page

</a>

</li>

<?php

for($i= 1; $i<= $total_pages; $i++){
	
if($i == $page){
	
$active = "active";
	
}else{
	
$active = "";
	
}	

 ?>

<li class="page-item <?php echo $active; ?>">

<a href="index.php?random_proposals_page=<?php echo $i; ?>&top_proposals_page=<?php echo $top_proposals_page; ?>" class="page-link">

<?php echo $i; ?>

</a>

</li>

<?php

}

?>

<li class="page-item">

<a href="index.php?random_proposals_page=<?php echo $total_pages; ?>&top_proposals_page=<?php echo $top_proposals_page; ?>" class="page-link">

Last Page

</a>

</li>

</ul><!--- pagination justify-content-center Ends --->

</div><!--- card-body vertical-proposals Ends --->

</div><!--- card border-primary mb-3 Ends --->

</div><!--- col-md-6 Ends --->


<div class="col-md-6"><!--- col-md-6 Starts --->

<div class="card border-primary mb-3"><!--- card border-primary mb-3 Starts --->

<div class="card-header bg-primary"><!--- card-header bg-primary Starts --->

<h5 class="h5 text-white"> Top Rated Proposals </h5>

</div><!--- card-header bg-primary Ends --->

<div class="card-body vertical-proposals"><!--- card-body vertical-proposals Starts --->

<?php

$per_page = 4;

if(isset($_GET['top_proposals_page'])){
	
$page = $_GET['top_proposals_page'];

}else{
	
$page = 1;
	
}

/// Page Will Start From 0 and Multiply By Per Page


$start_from = ($page-1) * $per_page;

/// Selecting The Data From Table With Limits

$select_proposals = "select * from proposals where proposal_status='active' and proposal_rating='5' LIMIT $start_from, $per_page";

$run_proposals = mysqli_query($con,$select_proposals);

while($row_proposals = mysqli_fetch_array($run_proposals)){

$proposal_id = $row_proposals['proposal_id'];

$proposal_title = $row_proposals['proposal_title'];

$proposal_price = $row_proposals['proposal_price'];

$proposal_img1 = $row_proposals['proposal_img1'];

$proposal_video = $row_proposals['proposal_video'];

$proposal_seller_id = $row_proposals['proposal_seller_id'];

$proposal_rating = $row_proposals['proposal_rating'];

$proposal_url = $row_proposals['proposal_url'];

$proposal_desc = substr(strip_tags($row_proposals['proposal_desc']),0,200);

if(empty($proposal_video)){
	
	$video_class = "";
	
}else{
	
	$video_class = "video-img";
	
}

$select_seller = "select * from sellers where seller_id='$proposal_seller_id'";

$run_seller = mysqli_query($con,$select_seller);

$row_seller = mysqli_fetch_array($run_seller);

$seller_user_name = $row_seller['seller_user_name'];

$select_buyer_reviews = "select * from buyer_reviews where proposal_id='$proposal_id'";

$run_buyer_reviews = mysqli_query($con,$select_buyer_reviews);

$count_reviews = mysqli_num_rows($run_buyer_reviews);

?>

<div class="row mb-3"><!--- row mb-3 Starts --->

<div class="col-md-3"><!--- col-md-3 Starts --->

<a href="proposals/<?php echo $proposal_url; ?>" class="<?php echo $video_class; ?>">

<img src="proposals/proposal_files/<?php echo $proposal_img1; ?>" class="vertical-proposal-img">

</a>

</div><!--- col-md-3 Ends --->

<div class="col-md-9"><!--- col-md-9 Starts --->

<div class="text"><!--- text Starts --->

<h6>

<a href="proposals/<?php echo $proposal_url; ?>"> <?php echo $proposal_title; ?> </a>

<span class="text-success"> $<?php echo $proposal_price; ?> </span>

</h6>

<p>

<?php echo $proposal_desc; ?> .. &nbsp;

<a href="proposals/<?php echo $proposal_url; ?>"> Read More </a>

</p>

<hr>

<span class="float-left">

<strong class="ml-2 mr-1"> By </strong> <?php echo $seller_user_name; ?>

</span>

<span class="float-right">

<?php

for($proposal_i=0; $proposal_i<$proposal_rating; $proposal_i++){
	
	echo " <img class='rating' src='images/user_rate_full.png' > ";
	
}

for($proposal_i=$proposal_rating; $proposal_i<5; $proposal_i++){
	
	echo " <img class='rating' src='images/user_rate_blank.png' > ";
	
}


?>

<span class="ml-1 mr-2"> (<?php echo $count_reviews; ?>) </span>

</span>

</div><!--- text Ends --->

</div><!--- col-md-9 Ends --->

</div><!--- row mb-3 Ends --->

<?php } ?>


<ul class="pagination justify-content-center"><!--- pagination justify-content-center Starts --->

<?php

$select_proposals = "select * from proposals where proposal_status='active' and proposal_rating='5' LIMIT 0,16";

$run_proposals = mysqli_query($con, $select_proposals);

$count_proposals = mysqli_num_rows($run_proposals);

$total_pages = ceil($count_proposals / $per_page);

if(isset($_GET['random_proposals_page'])){
	
	$random_proposals_page = $_GET['random_proposals_page'];
	
}else{
	
	$random_proposals_page = 1;
	
}





?>

<li class="page-item">

<a href="index.php?random_proposals_page=<?php echo $random_proposals_page; ?>&top_proposals_page=1" class="page-link">

First Page

</a>

</li>

<?php

for($i= 1; $i<= $total_pages; $i++){
	
if($i == $page){
	
$active = "active";
	
}else{
	
$active = "";
	
}	

 ?>

<li class="page-item <?php echo $active; ?> ">

<a href="index.php?random_proposals_page=<?php echo $random_proposals_page; ?>&top_proposals_page=<?php echo $i; ?>" class="page-link">

<?php echo $i; ?>

</a>

</li>

<?php } ?>

<li class="page-item">

<a href="index.php?random_proposals_page=<?php echo $random_proposals_page; ?>&top_proposals_page=<?php echo $total_pages; ?>" class="page-link">

Last Page

</a>

</li>

</ul><!--- pagination justify-content-center Ends --->

</div><!--- card-body vertical-proposals Ends --->

</div><!--- card border-primary mb-3 Ends --->

</div><!--- col-md-6 Ends --->


</div><!--- row Ends --->


</div><!--- container-fluid mt-5 Ends --->

<div class="append-modal"> </div>


<div id="quota-finish" class="modal fade"><!--- quota-finish modal fade Starts --->

<div class="modal-dialog"><!--- modal-dialog Starts --->

<div class="modal-content"><!--- modal-content Starts --->

<div class="modal-header"><!--- modal-header Starts --->

<h5 class="modal-title h5"> Request Quota Finished </h5>

<button class="close" data-dismiss="modal"> &times; </button>

</div><!--- modal-header Ends --->

<div class="modal-body"><!--- modal-body Starts --->

<center>

<h3> You Have Already Sent 10 Offers Today, Quota Finish </h3>

</center>

</div><!--- modal-body Ends --->

<div class="modal-footer"><!--- modal-footer Starts --->

<button class="btn btn-secondary" data-dismiss="modal">

Close

</button>

</div><!--- modal-footer Ends --->

</div><!--- modal-content Ends --->

</div><!--- modal-dialog Ends --->

</div><!--- quota-finish modal fade Ends --->


