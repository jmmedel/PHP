
<div class="mp-box mp-box-white notop d-lg-block d-none"><!--- mp-box mp-box-white notop d-lg-block d-none Starts --->

<div class="box-row"><!--- box-row Starts --->

<ul class="main-cat-list active"><!--- main-cat-list active Starts --->

<li><!--- main li Starts --->

<a href="http://localhost/freelance/dashboard.php">

Dashboard

</a>

</li><!--- main li Ends --->


<li><!--- main li Starts --->

<a href="#">

Selling <i class="fa fa-fw fa-caret-down"></i>

</a>


<div class="menu-cont"><!--- menu-cont Starts --->

<ul><!--- ul Starts --->

<li>

<a href="http://localhost/freelance/selling_orders.php">

Orders

</a>

</li>


<li>

<a href="http://localhost/freelance/proposals/view_proposals.php">

View Proposals

</a>

</li>


<li>

<a href="http://localhost/freelance/requests/buyer_requests.php">

Buyer Requests

</a>

</li>


<li>

<a href="http://localhost/freelance/revenue.php">

Revenues

</a>

</li>

</ul><!--- ul Ends --->

</div><!--- menu-cont Ends --->


</li><!--- main li Ends --->


<li><!--- main li Starts --->

<a href="#">

Buying <i class="fa fa-fw fa-caret-down"></i>

</a>


<div class="menu-cont"><!--- menu-cont Starts --->

<ul><!--- ul Starts --->

<li>

<a href="http://localhost/freelance/buying_orders.php">

Orders

</a>

</li>


<li>

<a href="http://localhost/freelance/proposals/purchases.php">

Payments

</a>

</li>


<li>

<a href="http://localhost/freelance/requests/favourites.php">

Favourites

</a>

</li>


</ul><!--- ul Ends --->

</div><!--- menu-cont Ends --->


</li><!--- main li Ends --->


<li><!--- main li Starts --->

<a href="#">

Requests <i class="fa fa-fw fa-caret-down"></i>

</a>


<div class="menu-cont"><!--- menu-cont Starts --->

<ul><!--- ul Starts --->

<li>

<a href="http://localhost/freelance/requests/manage_requests.php">

Manage Requests

</a>

</li>


<li>

<a href="http://localhost/freelance/requests/post_request.php">

Post A Request

</a>

</li>



</ul><!--- ul Ends --->

</div><!--- menu-cont Ends --->


</li><!--- main li Ends --->


<li><!--- main li Starts --->

<a href="#">

Contacts <i class="fa fa-fw fa-caret-down"></i>

</a>


<div class="menu-cont"><!--- menu-cont Starts --->

<ul><!--- ul Starts --->

<li>

<a href="http://localhost/freelance/manage_contacts.php?my_buyers">

My Buyers

</a>

</li>


<li>

<a href="http://localhost/freelance/proposals/manage_contacts.php?my_sellers">

My Sellers

</a>

</li>


</ul><!--- ul Ends --->

</div><!--- menu-cont Ends --->


</li><!--- main li Ends --->


<li><!--- main li Starts --->

<a href="http://localhost/freelance/my_referrals.php">

My Referrals

</a>

</li><!--- main li Ends --->


<li><!--- main li Starts --->

<a href="http://localhost/freelance/conversations.php/inbox.php">

Inbox

</a>

</li><!--- main li Ends --->


<li><!--- main li Starts --->

<a href="http://localhost/freelance/user.php">

My Profile

</a>

</li><!--- main li Ends --->


<li><!--- main li Starts --->

<a href="http://localhost/freelance/settings.php">

Settings

</a>

</li><!--- main li Ends --->


</ul><!--- main-cat-list active Ends --->

</div><!--- box-row Ends --->


</div><!--- mp-box mp-box-white notop d-lg-block d-none Ends --->


<div class="d-lg-none d-block mt-5">

&nbsp;

</div>

